<?php
include 'ASEngine/AS.php';
if(!$login->isLoggedIn())
    header("Location: login.php");
$user = new ASUser(ASSession::get("user_id"));
$userInfo = $user->getInfo();
$roleuser = $userInfo['user_role'];
$user_id = $userInfo['user_id'];
$_SESSION['roleuser'] = $roleuser;
$nav = 'dashboard';
//DATA
$todaybooking = date("Y-m-d");
$monthbooking = date("m");
$yearbooking = date("Y");
$datetimebooking = $todaybooking.' 00:00:00';
$datemonthbooking = $yearbooking.'-'.$monthbooking.'-01 00:00:00';
$dateyearbooking = $yearbooking.'-01-01 00:00:00';
//basic include files
require_once("../db.php");
//require_once("../inc/news.php");
//obtener el ID del hotel
$customhotel = mysqli_query($conn, "SELECT * FROM hotels WHERE deleted = 0 AND account_id ='$user_id' ");
$customhotelData = mysqli_fetch_array($customhotel);
$_SESSION['hotelid'] = $customhotelData['hotel_id'];
$queryadd = "";
$queryaddreview = "";
if($_SESSION['roleuser'] == 4) {
	if($customhotelData['hotel_id'] > 0) {
	 $queryadd = 'AND hotel_id ='.$_SESSION['hotelid'];
	 $queryaddreview = 'AND hotelid ='.$_SESSION['hotelid'];
	} else {
	 $queryadd = "AND hotel_id = '-1' ";
	 $queryaddreview = "AND hotelid = '-1' ";
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo WEBSITE_NAME; ?></title>
    <meta name="author" content="Bookingo" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="application-name" content="Bookingo" />

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- Force IE9 to render in normla mode -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- Le styles -->
    <!-- Use new way for google web fonts 
    http://www.smashingmagazine.com/2012/07/11/avoiding-faux-weights-styles-google-web-fonts -->
    <!-- Headings -->
    <!-- <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css' />  -->
    <!-- Text -->
    <!-- <link href='http://fonts.googleapis.com/css?family=Droid+Sans:400,700' rel='stylesheet' type='text/css' /> --> 
    <!--[if lt IE 9]>
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:700" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=Droid+Sans:400" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=Droid+Sans:700" rel="stylesheet" type="text/css" />
    <![endif]-->

    <!-- Core stylesheets do not remove -->
    <link id="bootstrap" href="<?php echo SITE_URL; ?>css/bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link id="bootstrap-responsive" href="<?php echo SITE_URL; ?>css/bootstrap/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo SITE_URL; ?>css/supr-theme/jquery.ui.supr.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo SITE_URL; ?>css/icons.css" rel="stylesheet" type="text/css" />

    <!-- Plugin stylesheets -->
    <link href="<?php echo SITE_URL; ?>plugins/misc/qtip/jquery.qtip.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo SITE_URL; ?>plugins/misc/fullcalendar/fullcalendar.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo SITE_URL; ?>plugins/misc/search/tipuesearch.css" type="text/css" rel="stylesheet" />
    <link href="<?php echo SITE_URL; ?>plugins/forms/uniform/uniform.default.css" type="text/css" rel="stylesheet" />
    

   


    <!-- Main stylesheets -->
    <link href="<?php echo SITE_URL; ?>css/main.css" rel="stylesheet" type="text/css" /> 

    <!-- Custom stylesheets ( Put your own changes here ) -->
    <link href="<?php echo SITE_URL; ?>css/custom.css" rel="stylesheet" type="text/css" /> 

    <!--[if IE 8]><link href="css/ie8.css" rel="stylesheet" type="text/css" /><![endif]-->

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script type="text/javascript" src="js/libs/excanvas.min.js"></script>
      <script type="text/javascript" src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <script type="text/javascript" src="js/libs/respond.min.js"></script>
    <![endif]-->

    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="<?php echo SITE_URL; ?>images/favicon.ico" />
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo SITE_URL; ?>images/apple-touch-icon-144-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo SITE_URL; ?>images/apple-touch-icon-114-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo SITE_URL; ?>images/apple-touch-icon-72-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" href="<?php echo SITE_URL; ?>images/apple-touch-icon-57-precomposed.png" />
    
    <!-- Windows8 touch icon ( http://www.buildmypinnedsite.com/ )-->
    <meta name="msapplication-TileColor" content="#3399cc"/> 

    <!-- Load modernizr first -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/libs/modernizr.js"></script>
	<?php //include 'ASEngine/ASNews.php'; ?>
    </head>
      
    <body>
    <!-- loading animation -->
    <div id="qLoverlay"></div>
    <div id="qLbar"></div>
    
    <div id="header" class="fixed">

        <?php include 'inc/header.php'; ?><!-- /navbar --> 

    </div><!-- End #header -->

    <div id="wrapper">

        <!--Responsive navigation button-->  
        <div class="resBtn">
            <a href="#"><span class="icon16 minia-icon-list-3"></span></a>
        </div>
        
        <!--Sidebar collapse button-->  
        <div class="collapseBtn leftbar">
             <a href="#" class="tipR" title="Hide sidebar"><span class="icon12 minia-icon-layout"></span></a>
        </div>

        <!--Sidebar background-->
        <div id="sidebarbg"></div>
        <!--Sidebar content-->
        <div id="sidebar">
			<?php include 'inc/sidebar.php'; ?><!-- /sidebar -->
        </div><!-- End #sidebar -->

        <!--Body content-->
        <div id="content" class="clearfix">
            <div class="contentwrapper"><!--Content wrapper-->

                <div class="heading">
				<!--Content Title-->
                    <h3>Dashboard</h3>                    

                    <div class="resBtnSearch">
                        <a href="#"><span class="icon16 icomoon-icon-search-3"></span></a>
                    </div>

                    <ul class="breadcrumb">
                        <li>
                            <a href="./" class="tip" title="back to dashboard">
                                <span class="icon16 icomoon-icon-screen-2"></span>
                            </a> 
                            <span class="divider">
                                <span class="icon16 icomoon-icon-arrow-right-3"></span>
                            </span>
                        </li>
                        <li class="active"><a href="javascript: history.go(-1)">Go Back</a></li>
                    </ul>

                </div><!-- End .heading-->


                <!-- Build page from here: -->
                <div class="row-fluid">
                    <?php include 'transql/sels/total-dashboard.php'; ?><!-- /navbar --> 
                    <div class="span12">
                        <div class="centerContent">
                  
                            <ul class="bigBtnIcon">
                                <?php
								if($roleuser == 3){
                                echo"<li>
                                    <a href='microsite.php' >
                                        <span class='icon icomoon-icon-certificate'></span>
                                        <span class='txt'>Inventories</span>
                                        <span class='notification'>$custominventtotal</span>
                                    </a>
                                </li>";
								}
                                ?>
                                <li>
                                    <a href="hotels.php">
                                        <span class="icon icomoon-icon-bed"></span>
                                        <span class="txt">Hotels</span>
                                        <span class="notification blue"><?php echo $customhoteltotal;?></span>
                                    </a>
                                </li>
                                <?php
								if($roleuser == 3){
                                echo"<li>
                                    <a href='cities.php' >
                                        <span class='icon icomoon-icon-earth'></span>
                                        <span class='txt'>Cities</span>
                                        <span class='notification green'>$customcitytotal</span>
                                    </a>
                                </li>";
								}
                                ?>
                                <li>
                                    <a href="bookings-records.php">
                                        <span class="icon icomoon-icon-calendar"></span>
                                        <span class="txt">Bookings</span>
                                        <span class="notification"><?php echo $custombookingtotal;?></span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <span class="icon icomoon-icon-bubbles-2"></span>
                                        <span class="txt">Reviews</span>
                                        <span class="notification"><?php echo $customreviewtotal;?></span>
                                    </a>
                                </li>                                
                            </ul>
                        </div>
                    </div><!-- End .span8 -->
                </div><!-- End .row-fluid -->
                
                <?php //include 'inc/news.php'; ?>

                <div class="row-fluid">

                    <div class="span4">

                        <div class="sparkStats">
                            <?php
                            if($roleuser == 3){
								$salestitle = 'Microsite Sales';
							}elseif($roleuser == 4){
								$salestitle = 'Hotel Sales';
							}
                            echo"<h4>$salestitle</h4>";
							?>
                            <ul class="unstyled">
                                <li>
                                    <span class="sparkLine1"></span> 
                                    Sales Today: 
                                    <span class="number">$ <?php echo $customsalestodayData['totalhoy'] ?></span>
                                </li>
                                <li>
                                    <span class="sparkLine2"></span>
                                    Sales Month: 
                                    <span class="number">$ <?php echo $customsalesmonthData['totalhoy'] ?></span>
                                </li>
                                <li><span class="sparkLine3"></span> 
                                    Sales Year: 
                                    <span class="number">$ <?php echo $customsalesyearData['totalhoy'] ?></span>
                                </li>                                
                            </ul>
                           
                        </div><!-- End .sparkStats -->
                        

                    </div><!-- End .span4 -->
                    <div class="span4">

                        <div class="reminder">
                            <h4>Latest Check Ins</h4>
                            <ul>
                            <?php
							if($customcheckinstotal > 0){
								while($customcheckinsData = mysqli_fetch_array($customcheckins)) {
								//fechacorregida
								$checkinbooking = date("d/m/Y", strtotime($customcheckinsData['check_in_date']));
								
                                echo"<li class='clearfix'>
                                    <div class='icon'>
                                        <span class='icon32 icomoon-icon-calendar gray'></span>
                                    </div>
                                    <span class='number'>$checkinbooking</span> 
                                    <span class='txt'>$customcheckinsData[first_name_owner] $customcheckinsData[last_name_owner]</span>
                                    <a class='btn btn-warning' href='manage-bookings.php?booking_id=$customcheckinsData[booking_id]'>go</a>
                                </li>";
								}
							}
                            ?>                                 
                            </ul>
                        </div><!-- End .reminder -->

                    </div><!-- End .span4 -->
                    <div class="span4">

                        <div class="reminder">
                            <h4>Latest Check Outs</h4>
                            <ul>
                             <?php
							if($customcheckoutstotal > 0){
								while($customcheckoutsData = mysqli_fetch_array($customcheckouts)) {
								$checkoutbooking = date("d/m/Y", strtotime($customcheckoutsData['check_out_date']));
								
                                echo"<li class='clearfix'>
                                    <div class='icon'>
                                        <span class='icon32 icomoon-icon-calendar gray'></span>
                                    </div>
                                    <span class='number'>$checkoutbooking</span> 
                                    <span class='txt'>$customcheckoutsData[first_name_owner] $customcheckoutsData[last_name_owner]</span>
                                    <a class='btn btn-warning' href='manage-bookings.php?booking_id=$customcheckoutsData[booking_id]'>go</a>
                                </li>";
								}
							}
                            ?>                                  
                            </ul>
                        </div><!-- End .reminder -->

                    </div><!-- End .span4 -->
                </div><!-- End .row-fluid -->

               
                <div class="modal fade hide" id="myModal1">
                  
                  
                    <div class="modal-footer">
                        <a href="#" class="btn" data-dismiss="modal">Close</a>
                    </div>
                </div>
                <!-- End .row-fluid -->
                <!--End page -->
                
                
            </div><!-- End contentwrapper -->
        </div><!-- End #content -->
           
    <footer>
    	<?php include 'inc/footer.php'; ?><!-- /footer -->
    </footer>
    
    </div><!-- End #wrapper -->
    
    <!-- Le javascript
    ================================================== -->
    <!-- Important plugins put in all pages -->
    <script  type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.2/jquery-ui.min.js"></script>
    <script type="text/javascript" src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/bootstrap/bootstrap.js"></script>  
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/jquery.mousewheel.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/libs/jRespond.min.js"></script>
    
    <!-- Charts plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/charts/flot/jquery.flot.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/charts/flot/jquery.flot.grow.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/charts/flot/jquery.flot.pie.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/charts/flot/jquery.flot.resize.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/charts/flot/jquery.flot.tooltip_0.4.4.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/charts/flot/jquery.flot.orderBars.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/charts/sparkline/jquery.sparkline.min.js"></script><!-- Sparkline plugin -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/charts/knob/jquery.knob.js"></script><!-- Circular sliders and stats -->
     
    <!-- Misc plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/misc/fullcalendar/fullcalendar.min.js"></script><!-- Calendar plugin -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/misc/qtip/jquery.qtip.min.js"></script><!-- Custom tooltip plugin -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/misc/totop/jquery.ui.totop.min.js"></script> <!-- Back to top plugin -->
    
    <!-- Search plugin -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/misc/search/tipuesearch_set.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/misc/search/tipuesearch_data.js"></script><!-- JSON for searched results -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/misc/search/tipuesearch.js"></script>

    <!-- Form plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/uniform/jquery.uniform.min.js"></script>
    
    <!-- Init plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/main.js"></script><!-- Core js functions -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/dashboard.js"></script><!-- Init plugins only for page -->
    
  	<script src="<?php echo SITE_URL; ?>ASLibrary/js/asengine.js" type="text/javascript" charset="utf-8"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>ASLibrary/js/index.js" charset="utf-8"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>ASLibrary/js/logout.js" charset="utf-8"></script>
    
    </body>
</html>