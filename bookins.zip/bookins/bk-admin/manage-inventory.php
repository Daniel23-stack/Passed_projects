<?php
$pageorigin = 'manage-inventory.php';
include 'ASEngine/AS.php';
if(!$login->isLoggedIn())
    header("Location: login.php");
$user = new ASUser(ASSession::get("user_id"));
$userInfo = $user->getInfo();

//basic include files
require_once("../db.php");

$nav = 'microsite';

//Active Inventory
$inventory_id = $_GET['inventoryid'];
$inventory_name = $_GET['inventoryname'];

//Messages
include 'inc/messages.php';

//Current Tab Active
	$label1 = '';
	$tab1 = '';
	$label2 = '';
	$tab2 = '';
	$label3 = '';
	$tab3 = '';
	$label4 = '';
	$tab4 = '';
if(isset($_GET['tab'])) {
	if($_GET['tab'] == '2') {
	$label2 = 'class="active"';
	$tab2 = 'in active';
	} elseif($_GET['tab'] == '3') {
	$label3 = 'class="active"';
	$tab3 = 'in active';
	} elseif($_GET['tab'] == '4') {
	$label4 = 'class="active"';
	$tab4 = 'in active';
	}
} else {
	$label1 = 'class="active"';
	$tab1 = 'in active';
}

//Inventory Data
$inventarioactivo = mysqli_query($conn, "SELECT * FROM inventory WHERE inventory_id = '$inventory_id' LIMIT 1 ");
$inventarioactivototal = mysqli_num_rows($inventarioactivo);
$inventarioactivoData = mysqli_fetch_array($inventarioactivo);
//$codeinventario = $inventarioactivoData['inve_code'];
$codeinventario = $inventory_id;
$custom = mysqli_query($conn, "SELECT * FROM approved_inventory WHERE microsite_inventory_code = '$codeinventario' AND deleted = '0' ");
$customtotal = mysqli_num_rows($custom);
$customcity = mysqli_query($conn, "SELECT * FROM cities AS cit
LEFT OUTER JOIN (SELECT element_id FROM approved_inventory WHERE microsite_inventory_code = '$codeinventario' AND element_type = '2' AND top_destination = '0' AND deleted = '0' ) AS ele
ON cit.city_id = ele.element_id
WHERE cit.city_deleted = 0 AND ele.element_id IS NULL ");
$customcitytotal = mysqli_num_rows($customcity);

$customcitytop = mysqli_query($conn, "SELECT * FROM approved_inventory WHERE microsite_inventory_code = '$codeinventario' AND element_type = '2' AND top_destination = '1' AND deleted = '0' ");
$customcitytoptotal = mysqli_num_rows($customcitytop);

$customhotel = mysqli_query($conn, "SELECT * FROM hotels AS hot
LEFT OUTER JOIN (SELECT element_id FROM approved_inventory WHERE microsite_inventory_code = '$codeinventario' AND element_type = '1' AND deleted = '0' ) AS ele
ON hot.hotel_id = ele.element_id
WHERE hot.deleted = 0 AND ele.element_id IS NULL ");
$customhoteltotal = mysqli_num_rows($customhotel);

mysqli_free_result($inventarioactivo);
mysqli_close($conn);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo WEBSITE_NAME; ?></title>
    <meta name="author" content="Bookingo" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="application-name" content="Bookingo" />

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- Force IE9 to render in normla mode -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- Le styles -->
    <!-- Use new way for google web fonts 
    http://www.smashingmagazine.com/2012/07/11/avoiding-faux-weights-styles-google-web-fonts -->
    <!-- Headings -->
    <!-- <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css' />  -->
    <!-- Text -->
    <!-- <link href='http://fonts.googleapis.com/css?family=Droid+Sans:400,700' rel='stylesheet' type='text/css' /> --> 
    <!--[if lt IE 9]>
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:700" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=Droid+Sans:400" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=Droid+Sans:700" rel="stylesheet" type="text/css" />
    <![endif]-->

    <!-- Core stylesheets do not remove -->
    <link id="bootstrap" href="<?php echo SITE_URL; ?>css/bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link id="bootstrap-responsive" href="<?php echo SITE_URL; ?>css/bootstrap/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo SITE_URL; ?>css/supr-theme/jquery.ui.supr.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo SITE_URL; ?>css/icons.css" rel="stylesheet" type="text/css" />

    <!-- Plugin stylesheets -->
    <link href="<?php echo SITE_URL; ?>plugins/misc/qtip/jquery.qtip.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo SITE_URL; ?>plugins/forms/uniform/uniform.default.css" type="text/css" rel="stylesheet" />        
    <link href="<?php echo SITE_URL; ?>plugins/tables/dataTables/jquery.dataTables.css" type="text/css" rel="stylesheet" />
    <link href="<?php echo SITE_URL; ?>plugins/tables/dataTables/TableTools.css" type="text/css" rel="stylesheet" />

    <!-- Main stylesheets -->
    <link href="<?php echo SITE_URL; ?>css/main.css" rel="stylesheet" type="text/css" /> 

    <!-- Custom stylesheets ( Put your own changes here ) -->
    <link href="<?php echo SITE_URL; ?>css/custom.css" rel="stylesheet" type="text/css" /> 

    <!--[if IE 8]><link href="css/ie8.css" rel="stylesheet" type="text/css" /><![endif]-->

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script type="text/javascript" src="js/libs/excanvas.min.js"></script>
      <script type="text/javascript" src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <script type="text/javascript" src="js/libs/respond.min.js"></script>
    <![endif]-->

    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="<?php echo SITE_URL; ?>images/favicon.ico" />
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo SITE_URL; ?>images/apple-touch-icon-144-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo SITE_URL; ?>images/apple-touch-icon-114-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo SITE_URL; ?>images/apple-touch-icon-72-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" href="<?php echo SITE_URL; ?>images/apple-touch-icon-57-precomposed.png" />
    
    <!-- Windows8 touch icon ( http://www.buildmypinnedsite.com/ )-->
    <meta name="msapplication-TileColor" content="#3399cc"/> 

    <!-- Load modernizr first -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/libs/modernizr.js"></script>
	
    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
    <![endif]-->
    
    </head>
      
    <body>
    <!-- loading animation -->
    <div id="qLoverlay"></div>
    <div id="qLbar"></div>
    
    <div id="header" class="fixed">

        <?php include 'inc/header.php'; ?><!-- /navbar --> 

    </div><!-- End #header -->

    <div id="wrapper">

        <!--Responsive navigation button-->  
        <div class="resBtn">
            <a href="#"><span class="icon16 minia-icon-list-3"></span></a>
        </div>
        
        <!--Sidebar collapse button-->  
        <div class="collapseBtn leftbar">
             <a href="#" class="tipR" title="Hide sidebar"><span class="icon12 minia-icon-layout"></span></a>
        </div>

        <!--Sidebar background-->
        <div id="sidebarbg"></div>
        <!--Sidebar content-->
        <div id="sidebar">
			<?php include 'inc/sidebar.php'; ?><!-- /sidebar -->
        </div><!-- End #sidebar -->

        <!--Body content-->
        <div id="content" class="clearfix">
            <div class="contentwrapper"><!--Content wrapper-->

                <div class="heading">
				<!--Content Title-->
                    <h3><?php echo $inventory_name; ?> Inventory Management</h3>                    

                    <div class="resBtnSearch">
                        <a href="#"><span class="icon16 icomoon-icon-search-3"></span></a>
                    </div>

                    <ul class="breadcrumb">
                        <li>
                            <a href="./" class="tip" title="back to dashboard">
                                <span class="icon16 icomoon-icon-screen-2"></span>
                            </a> 
                            <span class="divider">
                                <span class="icon16 icomoon-icon-arrow-right-3"></span>
                            </span>
                        </li>
                        <li class="active"><a href="javascript: history.go(-1)">Go Back</a></li>
                    </ul>

                </div><!-- End .heading-->


                <!-- Build page from here: -->
                <div class="row-fluid">
					
                    <div class="span12">
                            <div class="page-header">
                                <h4>Control Inventory &nbsp; <a href="microsite.php" class="btn btn-primary"><span class="icomoon-icon-arrow-left-9 white"/> Back</a></h4>
                            </div>
                            <div style="margin-bottom: 20px;">
                                <ul id="myTab" class="nav nav-tabs pattern">
                                    <li <?php echo $label1; ?>><a href="#tab1" data-toggle="tab">Current Inventory</a></li>
                                    <li <?php echo $label2; ?>><a href="#tab2" data-toggle="tab">Add City</a></li>
                                    <li <?php echo $label3; ?>><a href="#tab3" data-toggle="tab">Add Hotel</a></li>
                                    <li <?php echo $label4; ?>><a href="#tab4" data-toggle="tab">Top Destinations</a></li>                                    
                                </ul>

                                <div class="tab-content">
                                    <!-- Start Tab1 -->
                                    <div class="tab-pane fade <?php echo $tab1; ?>" id="tab1">
                                        <?php echo $smessage; ?>
                                        
									<?php if($customtotal > 0) { ?>
                                        <table cellpadding="0" cellspacing="0" border="0" class="tableTools display table table-bordered" width="100%">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                  	<th>Element Name</th>
                                                  	<th>Status</th>
                                                  	<th>Actions</th>
                                                </tr>
                                            </thead>
                                          <tbody>
                                    <?php while($busData = mysqli_fetch_array($custom))     
										{
										 $activelement = 'Inactive';
										 $activelabel = 'label-important';
										 $pubelement = 'Unpublished';
										 $publabel = 'label-warning';
										 $topdelement = 'Regular';
										 $topdlabel = 'label-info';
										 $topdelement = 'Regular';
										 $topdlabel = 'label-info';
										 $hotelement = '';
										 $hotlabel = '';
										 $elementtype = $busData['element_type'];
										 if($busData['active'] == 1) {
											$activelement = 'Active';
											$activelabel = 'label-success';
										 }
										 if($busData['publish'] == 1) {
											$pubelement = 'Published';
											$publabel = 'label-info';
										 }
										 if($busData['top_destination'] == 1) {
											$topdelement = 'Top Destination';
											$topdlabel = 'label-error';
										 }
										 if($busData['hot_deal'] == 1) {
											$hotelement = 'Hot Deal';
											$hotlabel = 'label-warning';
										 }
										 ?>
                                            <tr class="user-row">
                                                <td><?php echo $busData['inventory_id']; ?></td>
                                              	<td><?php echo $busData['element_name']; ?></td>
                                              	<td>
                                                	<span class='label <?=$activelabel?>'>
                                                  		<?=$activelement?>
                                                	</span>
                                                	<span class='label <?=$publabel?>'>
                                                  		<?=$pubelement?>
                                                	</span>
                                                    <span class='label <?=$topdlabel?>'>
                                                  		<?=$topdelement?>
                                                	</span>
                                               <?php
											   if($busData['hot_deal'] == 1) {
											   ?>
                                                    <span class='label <?=$hotlabel?>'>
                                                  		<?=$hotelement?>
                                                	</span>
                                              	</td>
                                                <?php
												}
												?>
                                              	<td width='380px'>
                                    <?php if($busData['publish'] == 0) { ?>
                                                  	<a href='transql/upds/change-inventory-ind-element-status.php?inventoryid=<?=$inventory_id?>&inventoryname=<?=$inventory_name?>&elementid=<?php echo $busData['inventory_id']; ?>&elstatus=1&pageorigin=<?php echo $pageorigin; ?>' class='btn'><strong>Publish</strong></a>
                                    <?php } elseif($busData['publish'] == 1) { ?>
                                                  	<a href='transql/upds/change-inventory-ind-element-status.php?inventoryid=<?=$inventory_id?>&inventoryname=<?=$inventory_name?>&elementid=<?php echo $busData['inventory_id']; ?>&elstatus=0&pageorigin=<?php echo $pageorigin; ?>' class='btn'><strong>Unpublish</strong></a>
                                    	<?php } ?>
                                        <?php 
										if($elementtype == '2'){
										  if($busData['top_destination'] == 0) { ?>
                                             <a href='transql/upds/change-inventory-element-topdestination.php?inventoryid=<?=$inventory_id?>&inventoryname=<?=$inventory_name?>&elementid=<?php echo $busData['inventory_id']; ?>&topdestination=1&toptypedestination=1&controlmes=2&pageorigin=<?php echo $pageorigin; ?>' class='btn'><strong>Done Top Destination</strong></a>
                                        <?php } elseif($busData['top_destination'] == 1) { ?>
                                             <a href='transql/upds/change-inventory-element-topdestination.php?inventoryid=<?=$inventory_id?>&inventoryname=<?=$inventory_name?>&elementid=<?php echo $busData['inventory_id']; ?>&topdestination=0&toptypedestination=0&controlmes=3&pageorigin=<?php echo $pageorigin; ?>' class='btn'><strong>Udone Top Destination</strong></a>
                                        <?php }
										}
										 ?>
                                        <?php 
										if($elementtype == '1'){
										  if($busData['hot_deal'] == 0) { ?>
                                             <a href='transql/upds/change-inventory-element-hotdeal.php?inventoryid=<?=$inventory_id?>&inventoryname=<?=$inventory_name?>&elementid=<?php echo $busData['inventory_id']; ?>&hotdeal=1&controlmes=6&pageorigin=<?php echo $pageorigin; ?>' class='btn'><strong>Done Hot Deal</strong></a>
                                        <?php } elseif($busData['hot_deal'] == 1) { ?>
                                             <a href='transql/upds/change-inventory-element-hotdeal.php?inventoryid=<?=$inventory_id?>&inventoryname=<?=$inventory_name?>&elementid=<?php echo $busData['inventory_id']; ?>&hotdeal=0&controlmes=7&pageorigin=<?php echo $pageorigin; ?>' class='btn'><strong>Udone Hot Deal</strong></a>
                                        <?php }
										}
										 ?>
                                                	<a href='transql/upds/remove-inventory-element.php?elementid=<?php echo $busData['inventory_id']; ?>&inventoryid=<?=$inventory_id?>&inventoryname=<?=$inventory_name?>&pageorigin=<?php echo $pageorigin; ?>' class='btn'><strong>Remove</strong></a>
                                              	</td>
                                            </tr>
                                        <?php } ?>
                                          </tbody>
                                        </table>
                                    <?php } mysqli_free_result($custom); ?>    
                                    </div>
                                    
                                    <!-- Start Tab2 -->
                                    <div class="tab-pane fade <?php echo $tab2; ?>" id="tab2">
                                    	<?php echo $smessage2; ?>
									
									<?php if($customcitytotal > 0) { ?>
                                        <table cellpadding="0" cellspacing="0" border="0" class="tableTools2 display table table-bordered" width="100%">
                                            <thead>
                                                <tr>
                                                    <th width="160px">City Photo</th>
                                                    <th>City Code</th>
                                                  	<th>City Name</th>
                                                  	<th>Status</th>
                                                  	<th>Actions</th>
                                                </tr>
                                            </thead>
                                          <tbody>
                                    <?php while($customcityData = mysqli_fetch_array($customcity))     
										{
										 $activelementct = 'Inactive';
										 $activelabelct = 'label-important';
										 if($customcityData['city_active'] == 1) {
			
											$activelementct = 'Active';
											$activelabelct = 'label-success';
										 } ?>
                                            <tr class="user-row">
                                                <td><img src="/bk-admin/images/topdestinations/<?php echo $customcityData['city_image']; ?>" alt="" class="image marginR10"/></td>
                                                <td><?php echo $customcityData['city_id']; ?></td>
                                              	<td><?php echo $customcityData['city_name']; ?></td>
                                              	<td>
                                                	<span class='label <?=$activelabelct?>'>
                                                  		<?=$activelementct?>
                                                	</span>
                                              	</td>
                                              	<td width='200px'>
                                                	<form method="post" action="transql/insts/add-element-to-inventory.php">
                                                    	<input type="hidden" name="inventoryid" value="<?=$inventory_id?>" />
                                                        <input type="hidden" name="inventoryname" value="<?=$inventory_name?>" />
                                                        <input type="hidden" name="elementid" value="<?php echo $customcityData['city_id']; ?>" />
                                                        <input type="hidden" name="elementname" value="<?php echo $customcityData['city_name']; ?>" />
                                                        <input type="hidden" name="otadefault" value="<?php echo $customcityData['city_id']; ?>" />
                                                        <input type="hidden" name="elementtype" value="2" />
                                                        <input type="hidden" name="cityid" value="<?php echo $customcityData['city_id']; ?>" />
                                                        <input type="hidden" name="province" value="<?php echo $customcityData['state_id']; ?>" />
                                                        <input type="hidden" name="countrycode" value="<?php echo $customcityData['country_code']; ?>" />
                                                        <input type="hidden" name="inventorycode" value="<?=$inventory_id?>" />
                                                        <input type="hidden" name="topdestination" value="0" />
                                                        <input type="hidden" name="imagecity" value="<?=$customcityData['city_image']?>" />
                                                        <button type="submit" class='btn'><strong>Add to Inventory</strong></a>
                                                    </form>
                                              	</td>
                                            </tr>
                                            <?php } ?>
                                          </tbody>
                                        </table>
                                    <?php } mysqli_free_result($customcity); ?>
                                    </div>
                                    
                                    <!-- Start Tab3 -->
                                    <div class="tab-pane fade <?php echo $tab3; ?>" id="tab3">
                                        <?php echo $smessage3; ?>
										
									<?php if($customhoteltotal > 0) { ?>
                                        <table cellpadding="0" cellspacing="0" border="0" class="tableTools3 display table table-bordered" width="100%">
                                            <thead>
                                                <tr>
                                                    <th>Hotel Code</th>
                                                  	<th>Hotel Name</th>
                                                  	<th>Status</th>
                                                  	<th>Actions</th>
                                                </tr>
                                            </thead>
                                          <tbody>
                                    <?php while($customhotelData = mysqli_fetch_array($customhotel))     
										{
										 $activelementhot = 'Inactive';
										 $activelabelhot = 'label-important';
										 if($customhotelData['active'] == 1) {
											$activelementhot = 'Active';
											$activelabelhot = 'label-success';
										 } ?>
                                            <tr class="user-row">
                                                <td><?php echo $customhotelData['hotel_id']; ?></td>
                                              	<td><?php echo $customhotelData['hotel_name']; ?></td>
                                              	<td>
                                                	<span class='label <?=$activelabelhot?>'>
                                                  		<?=$activelementhot?>
                                                	</span>
                                              	</td>
                                              	<td width='200px'>
                                                	<form method="post" action="transql/insts/add-element-to-inventory.php">
                                                    	<input type="hidden" name="inventoryid" value="<?=$inventory_id?>" />
                                                        <input type="hidden" name="inventoryname" value="<?=$inventory_name?>" />
                                                        <input type="hidden" name="elementid" value="<?php echo $customhotelData['hotel_id']; ?>" />
                                                        <input type="hidden" name="elementname" value="<?php echo $customhotelData['hotel_name']; ?>" />
                                                        <input type="hidden" name="otadefault" value="<?php echo $customhotelData['ota_default']; ?>" />
                                                        <input type="hidden" name="elementtype" value="1" />
                                                        <input type="hidden" name="cityid" value="<?php echo $customhotelData['hotel_city']; ?>" />
                                                        <input type="hidden" name="province" value="<?php echo $customhotelData['hotel_state']; ?>" />
                                                        <input type="hidden" name="countrycode" value="<?php echo $customhotelData['hotel_country']; ?>" />
                                                        <input type="hidden" name="inventorycode" value="<?=$inventory_id?>" />
                                                        <button type="submit" class='btn'><strong>Add to Inventory</strong></a>
                                                    </form>
                                                </td>
                                            </tr>
                                            <?php } ?>
                                          </tbody>
                                        </table>
                                    <?php } mysqli_free_result($customhotel); ?>
                                    </div>
                                    
                                    <!-- Start Tab4 -->
                                    <div class="tab-pane fade <?php echo $tab4; ?>" id="tab4">
                                    	<?php echo $smessage4; ?>
									
									<?php if($customcitytoptotal > 0) { ?>
                                        <table cellpadding="0" cellspacing="0" border="0" class="tableTools4 display table table-bordered" width="100%">
                                            <thead>
                                                <tr>
                                                    <th width="120px">City Photo</th>
                                                    <th>City Code</th>
                                                  	<th>City Name</th>
                                                  	<th>Destination Type</th>
                                                  	<th>Actions</th>
                                                </tr>
                                            </thead>
                                          <tbody>
                                    <?php while($customcitytopData = mysqli_fetch_array($customcitytop))     
										{
										 $activelementct = 'Local';
										 $activelabelct = 'label-important';
										 $urlphoto = $customcitytopData['image_topdestination'];
										 if($customcitytopData['topdestination_type'] == 2) {			
											$activelementct = 'Worldwide';
											$activelabelct = 'label-success';
										 } ?>
                                            <tr class="user-row">
                                                <td><center><img src='./images/topdestinations/<?=$urlphoto?>'></center></td>
                                                <td><?php echo $customcitytopData['element_id']; ?></td>
                                              	<td><?php echo $customcitytopData['element_name']; ?></td>
                                              	<td>
                                                	<span class='label <?=$activelabelct?>'>
                                                  		<?=$activelementct?>
                                                	</span>
                                              	</td>
                                              	<td width='240px'>                                                	
                                                    <?php if($customcitytopData['topdestination_type'] == 1) { ?>
                                                         <a href='transql/upds/change-destination-type.php?inventoryid=<?=$inventory_id?>&inventoryname=<?=$inventory_name?>&elementid=<?php echo $customcitytopData['inventory_id']; ?>&topdestinationtype=2&controlmes=4' class='btn'><strong>Worldwide Destination</strong></a>
                                                    <?php } elseif($customcitytopData['topdestination_type'] == 2) { ?>
                                                         <a href='transql/upds/change-destination-type.php?inventoryid=<?=$inventory_id?>&inventoryname=<?=$inventory_name?>&elementid=<?php echo $customcitytopData['inventory_id']; ?>&topdestinationtype=1&controlmes=5' class='btn'><strong>Local Destination</strong></a>
                                                    <?php } ?>
                                              	</td>
                                            </tr>
                                            <?php } ?>
                                          </tbody>
                                        </table>
                                    <?php } mysqli_free_result($customcitytop); ?>
                                    </div>
                                    
                                </div>
                            </div>

                        </div><!-- End .span6 -->
                    
                </div><!-- End .row-fluid -->
                <!--End page -->
                
                
            </div><!-- End contentwrapper -->
        </div><!-- End #content -->
           
    <footer>
    	<?php include 'inc/footer.php'; ?><!-- /footer -->
    </footer>
    
    </div><!-- End #wrapper -->
    
    <!-- Le javascript
    ================================================== -->
    <!-- Important plugins put in all pages -->
    <script  type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.2/jquery-ui.min.js"></script>
    <script type="text/javascript" src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/bootstrap/bootstrap.js"></script>  
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/jquery.mousewheel.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/libs/jRespond.min.js"></script>


    <!-- Misc plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/misc/qtip/jquery.qtip.min.js"></script><!-- Custom tooltip plugin -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/misc/totop/jquery.ui.totop.min.js"></script> 
    
    
    <!-- Form plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/uniform/jquery.uniform.min.js"></script>

	
    <!-- Table plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/tables/dataTables/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/tables/dataTables/TableTools.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/tables/dataTables/ZeroClipboard.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/tables/responsive-tables/responsive-tables.js"></script><!-- Make tables responsive -->
    

    <!-- Init plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/main.js"></script><!-- Core js functions -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/datatable.js"></script><!-- Init plugins only for page -->


	<script src="<?php echo SITE_URL; ?>ASLibrary/js/asengine.js" type="text/javascript" charset="utf-8"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>ASLibrary/js/index.js" charset="utf-8"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>ASLibrary/js/logout.js" charset="utf-8"></script>
    
    </body>
</html>