<?php
$pageorigin = 'microsite.php';
include 'ASEngine/AS.php';
if(!$login->isLoggedIn())
    header("Location: login.php");
$user = new ASUser(ASSession::get("user_id"));
$userInfo = $user->getInfo();

//basic include files
require_once("../db.php");

$nav = '';

//Messages
include 'inc/messages.php';

//Current Tab Active
	$label1 = '';
	$tab1 = '';
	$label2 = '';
	$tab2 = '';
	$label3 = '';
	$tab3 = '';
if(isset($_GET['tab'])) {
	if($_GET['tab'] == '2') {
	$label2 = 'class="active"';
	$tab2 = 'in active';
	} elseif($_GET['tab'] == '3') {
	$label3 = 'class="active"';
	$tab3 = 'in active';
	}
} else {
	$label1 = 'class="active"';
	$tab1 = 'in active';
}

//Active Inventory
$inventarioactivo = mysqli_query($conn, "SELECT * FROM inventory WHERE inve_active = '1' LIMIT 1 ");
$inventarioactivototal = mysqli_num_rows($inventarioactivo);
$inventarioactivoData = mysqli_fetch_array($inventarioactivo);
$codeinventario = $inventarioactivoData['inventory_id'];
$custom = mysqli_query($conn, "SELECT * FROM approved_inventory WHERE microsite_inventory_code = '$codeinventario' AND deleted = '0' ");
$customtotal = mysqli_num_rows($custom);
$custominv = mysqli_query($conn, "SELECT * FROM inventory WHERE inve_deleted = '0' ");
$custominvtotal = mysqli_num_rows($custominv);

mysqli_free_result($inventarioactivo);
mysqli_close($conn);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo WEBSITE_NAME; ?></title>
    <meta name="author" content="Bookingo" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="application-name" content="Bookingo" />

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- Force IE9 to render in normla mode -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- Le styles -->
    <!-- Use new way for google web fonts 
    http://www.smashingmagazine.com/2012/07/11/avoiding-faux-weights-styles-google-web-fonts -->
    <!-- Headings -->
    <!-- <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css' />  -->
    <!-- Text -->
    <!-- <link href='http://fonts.googleapis.com/css?family=Droid+Sans:400,700' rel='stylesheet' type='text/css' /> --> 
    <!--[if lt IE 9]>
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:700" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=Droid+Sans:400" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=Droid+Sans:700" rel="stylesheet" type="text/css" />
    <![endif]-->

    <!-- Core stylesheets do not remove -->
    <link id="bootstrap" href="<?php echo SITE_URL; ?>css/bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link id="bootstrap-responsive" href="<?php echo SITE_URL; ?>css/bootstrap/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo SITE_URL; ?>css/supr-theme/jquery.ui.supr.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo SITE_URL; ?>css/icons.css" rel="stylesheet" type="text/css" />

    <!-- Plugin stylesheets -->
    <link href="<?php echo SITE_URL; ?>plugins/misc/qtip/jquery.qtip.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo SITE_URL; ?>plugins/forms/uniform/uniform.default.css" type="text/css" rel="stylesheet" />        
    <link href="<?php echo SITE_URL; ?>plugins/tables/dataTables/jquery.dataTables.css" type="text/css" rel="stylesheet" />
    <link href="<?php echo SITE_URL; ?>plugins/tables/dataTables/TableTools.css" type="text/css" rel="stylesheet" />

    <!-- Main stylesheets -->
    <link href="<?php echo SITE_URL; ?>css/main.css" rel="stylesheet" type="text/css" /> 

    <!-- Custom stylesheets ( Put your own changes here ) -->
    <link href="<?php echo SITE_URL; ?>css/custom.css" rel="stylesheet" type="text/css" /> 

    <!--[if IE 8]><link href="css/ie8.css" rel="stylesheet" type="text/css" /><![endif]-->

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script type="text/javascript" src="js/libs/excanvas.min.js"></script>
      <script type="text/javascript" src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <script type="text/javascript" src="js/libs/respond.min.js"></script>
    <![endif]-->

    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="<?php echo SITE_URL; ?>images/favicon.ico" />
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo SITE_URL; ?>images/apple-touch-icon-144-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo SITE_URL; ?>images/apple-touch-icon-114-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo SITE_URL; ?>images/apple-touch-icon-72-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" href="<?php echo SITE_URL; ?>images/apple-touch-icon-57-precomposed.png" />
    
    <!-- Windows8 touch icon ( http://www.buildmypinnedsite.com/ )-->
    <meta name="msapplication-TileColor" content="#3399cc"/> 

    <!-- Load modernizr first -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/libs/modernizr.js"></script>
	
    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
    <![endif]-->
    
    </head>
      
    <body>
    <!-- loading animation -->
    <div id="qLoverlay"></div>
    <div id="qLbar"></div>
    
    <div id="header" class="fixed">

        <?php include 'inc/header.php'; ?><!-- /navbar --> 

    </div><!-- End #header -->

    <div id="wrapper">

        <!--Responsive navigation button-->  
        <div class="resBtn">
            <a href="#"><span class="icon16 minia-icon-list-3"></span></a>
        </div>
        
        <!--Sidebar collapse button-->  
        <div class="collapseBtn leftbar">
             <a href="#" class="tipR" title="Hide sidebar"><span class="icon12 minia-icon-layout"></span></a>
        </div>

        <!--Sidebar background-->
        <div id="sidebarbg"></div>
        <!--Sidebar content-->
        <div id="sidebar">
			<?php include 'inc/sidebar.php'; ?><!-- /sidebar -->
        </div><!-- End #sidebar -->

        <!--Body content-->
        <div id="content" class="clearfix">
            <div class="contentwrapper"><!--Content wrapper-->

                <div class="heading">
				<!--Content Title-->
                    <h3>Inventory Administration</h3>                    

                    <div class="resBtnSearch">
                        <a href="#"><span class="icon16 icomoon-icon-search-3"></span></a>
                    </div>

                    <ul class="breadcrumb">
                        <li>
                            <a href="./" class="tip" title="back to dashboard">
                                <span class="icon16 icomoon-icon-screen-2"></span>
                            </a> 
                            <span class="divider">
                                <span class="icon16 icomoon-icon-arrow-right-3"></span>
                            </span>
                        </li>
                        <li class="active"><a href="javascript: history.go(-1)">Go Back</a></li>
                    </ul>

                </div><!-- End .heading-->


                <!-- Build page from here: -->
                <div class="row-fluid">
					
                    <div class="span12">
                            <div class="page-header">
                                <h4>Control Inventory</h4>
                            </div>
                            <div style="margin-bottom: 20px;">
                                <ul id="myTab" class="nav nav-tabs pattern">
                                    <li <?php echo $label1; ?>><a href="#tab1" data-toggle="tab">Current Inventory</a></li>
                                    <li <?php echo $label2; ?>><a href="#tab2" data-toggle="tab">Inventory List</a></li>
                                    <li <?php echo $label3; ?>><a href="#tab3" data-toggle="tab">Add Inventory</a></li>
                                </ul>

                                <div class="tab-content">
                                    <!-- Start Tab1 -->
                                    <div class="tab-pane fade <?php echo $tab1; ?>" id="tab1">
										<?php echo $smessage; ?>
									
									<?php if($customtotal > 0) { ?>
                                        <table cellpadding="0" cellspacing="0" border="0" class="tableTools display table table-bordered" width="100%">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Element Name</th>
                                                    <th>Status</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                          <tbody>
                                    <?php while($busData = mysqli_fetch_array($custom))     
										{
										 $activelement = 'Inactive';
										 $activelabel = 'label-important';
										 $pubelement = 'Unpublished';
										 $publabel = 'label-warning';
										 $topdelement = 'Regular';
										 $topdlabel = 'label-info';
										 $topdelement = 'Regular';
										 $topdlabel = 'label-info';
										 $hotelement = '';
										 $hotlabel = '';
										 $elementtype = $busData['element_type'];
										 if($busData['active'] == 1) {
											$activelement = 'Active';
											$activelabel = 'label-success';
										 }
										 if($busData['publish'] == 1) {
											$pubelement = 'Published';
											$publabel = 'label-info';
										 }
										 if($busData['top_destination'] == 1) {
											$topdelement = 'Top Destination';
											$topdlabel = 'label-error';
										 }
										 if($busData['hot_deal'] == 1) {
											$hotelement = 'Hot Deal';
											$hotlabel = 'label-warning';
										 }
										 ?>
                                            <tr class="user-row">
                                                <td><?php echo $busData['inventory_id']; ?></td>
                                              	<td><?php echo $busData['element_name']; ?></td>
                                              	<td>
                                                	<span class='label <?=$activelabel?>'>
                                                  		<?=$activelement?>
                                                	</span>
                                                	<span class='label <?=$publabel?>'>
                                                  		<?=$pubelement?>
                                                	</span>
                                                    <span class='label <?=$topdlabel?>'>
                                                  		<?=$topdelement?>
                                                	</span>
                                               <?php
											   if($busData['hot_deal'] == 1) {
											   ?>
                                                    <span class='label <?=$hotlabel?>'>
                                                  		<?=$hotelement?>
                                                	</span>
                                              	</td>
                                                <?php
												}
												?>
                                              	<td width='380px'>
                                    <?php if($busData['publish'] == 0) { ?>
                                                  	<a href='transql/upds/change-inventory-ind-element-status.php?inventoryid=<?php echo $busData['inventory_id']; ?>&elementid=<?php echo $busData['inventory_id']; ?>&elstatus=1&pageorigin=<?php echo $pageorigin; ?>' class='btn'><strong>Publish</strong></a>
                                    <?php } elseif($busData['publish'] == 1) { ?>
                                                  	<a href='transql/upds/change-inventory-ind-element-status.php?inventoryid=<?php echo $busData['inventory_id']; ?>&elementid=<?php echo $busData['inventory_id']; ?>&elstatus=0&pageorigin=<?php echo $pageorigin; ?>' class='btn'><strong>Unpublish</strong></a>
                                    	<?php } ?>
                                        <?php 
										if($elementtype == '2'){
										  if($busData['top_destination'] == 0) { ?>
                                             <a href='transql/upds/change-inventory-element-topdestination.php?inventoryid=<?php echo $busData['inventory_id']; ?>&elementid=<?php echo $busData['inventory_id']; ?>&topdestination=1&toptypedestination=1&controlmes=2&pageorigin=<?php echo $pageorigin; ?>' class='btn'><strong>Done Top Destination</strong></a>
                                        <?php } elseif($busData['top_destination'] == 1) { ?>
                                             <a href='transql/upds/change-inventory-element-topdestination.php?inventoryid=<?php echo $busData['inventory_id']; ?>&elementid=<?php echo $busData['inventory_id']; ?>&topdestination=0&toptypedestination=0&controlmes=3&pageorigin=<?php echo $pageorigin; ?>' class='btn'><strong>Udone Top Destination</strong></a>
                                        <?php }
										}
										 ?>
                                        <?php 
										if($elementtype == '1'){
										  if($busData['hot_deal'] == 0) { ?>
                                             <a href='transql/upds/change-inventory-element-hotdeal.php?inventoryid=<?php echo $busData['inventory_id']; ?>&elementid=<?php echo $busData['inventory_id']; ?>&hotdeal=1&controlmes=6&pageorigin=<?php echo $pageorigin; ?>' class='btn'><strong>Done Hot Deal</strong></a>
                                        <?php } elseif($busData['hot_deal'] == 1) { ?>
                                             <a href='transql/upds/change-inventory-element-hotdeal.php?inventoryid=<?php echo $busData['inventory_id']; ?>&elementid=<?php echo $busData['inventory_id']; ?>&hotdeal=0&controlmes=7&pageorigin=<?php echo $pageorigin; ?>' class='btn'><strong>Udone Hot Deal</strong></a>
                                        <?php }
										}
										 ?>
                                                	<a href='transql/upds/remove-inventory-element.php?elementid=<?php echo $busData['inventory_id']; ?>&inventoryid=<?php echo $busData['inventory_id']; ?>&pageorigin=<?php echo $pageorigin; ?>' class='btn'><strong>Remove</strong></a>
                                              	</td>
                                            </tr>
                                        <?php } ?>
                                          </tbody>
                                        </table>
                                    <?php } mysqli_free_result($custom); ?>    
                                    </div>
                                    
                                    <!-- Start Tab2 -->
                                    <div class="tab-pane fade <?php echo $tab2; ?>" id="tab2">
                                    	<?php echo $smessage2; ?>
									
									<?php if($custominvtotal > 0) { ?>
                                        <table cellpadding="0" cellspacing="0" border="0" class="tableTools2 display table table-bordered" width="100%">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                  	<th>Inventory Name</th>
                                                  	<th>Status</th>
                                                  	<th>Actions</th>
                                                </tr>
                                            </thead>
                                          <tbody>
                                    <?php while($custominvData = mysqli_fetch_array($custominv)) {
										 $activeinventory = 'Inactive';
										 $activelabelinventory = 'label-important';
										 if($custominvData['inve_active'] == 1) {
											$activeinventory = 'Active';
											$activelabelinventory = 'label-success';
										 } ?>
                                            <tr class="user-row">
                                                <td><?php echo $custominvData['inventory_id']; ?></td>
                                              	<td><?php echo $custominvData['inve_name']; ?></td>
                                              	<td>
                                                	<span class='label <?=$activelabelinventory?>'>
                                                  		<?=$activeinventory?>
                                                	</span>
                                              	</td>
                                              	<td width='300px'>
                                               		<a href="manage-inventory.php?inventoryid=<?php echo $custominvData['inventory_id']; ?>&inventoryname=<?php echo $custominvData['inve_name']; ?>" class='btn'><i class='icon-edit'></i> <strong>Manage</strong></a>
                                	<?php if($custominvData['inve_active'] == 0) { ?>
                                                 	<a href="transql/upds/change-inventory-status.php?inventoryid=<?php echo $custominvData['inventory_id']; ?>" class='btn'><strong>Active</strong></a>
                                     		<?php } ?>
                                              <a href="transql/upds/change-inventory-delete.php?inventoryid=<?php echo $custominvData['inventory_id']; ?>" class='btn'><strong>Deleted</strong></a>
                                              </td>
                                            </tr>
                                            <?php } ?>
                                          </tbody>
                                        </table>
                                    <?php } mysqli_free_result($custominv); ?>
                                    </div>
                                    
                                    <!-- Start Tab3 -->
                                    <div class="tab-pane fade <?php echo $tab3; ?>" id="tab3">
                                        <?php echo $smessage3; ?>
                                        
                                        <p><form action="transql/insts/inventory-new.php" method="post" class="form-horizontal" id="signup">
                                             <div class="control-group">
                                             <label class="control-label">Inventory Name</label>
                                                <div class="controls">
                                                <input type="text" name="inventory_name" class="span6" />
                                                </div>
                                             </div>
                                                                                         
                                             <div class="form-actions">
                                                <button type="submit" class="btn btn-primary">Submit</button>
                                             </div>
                                           </form>
                                        </p>
                                    </div>
                                </div>
                            </div>

                        </div><!-- End .span6 -->
                    
                </div><!-- End .row-fluid -->
                <!--End page -->
                
                
            </div><!-- End contentwrapper -->
        </div><!-- End #content -->
           
    <footer>
    	<?php include 'inc/footer.php'; ?><!-- /footer -->
    </footer>
    
    </div><!-- End #wrapper -->
    
    <!-- Le javascript
    ================================================== -->
    <!-- Important plugins put in all pages -->
    <script  type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.2/jquery-ui.min.js"></script>
    <script type="text/javascript" src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/bootstrap/bootstrap.js"></script>  
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/jquery.mousewheel.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/libs/jRespond.min.js"></script>


    <!-- Misc plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/misc/qtip/jquery.qtip.min.js"></script><!-- Custom tooltip plugin -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/misc/totop/jquery.ui.totop.min.js"></script> 
    
    
    <!-- Form plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/uniform/jquery.uniform.min.js"></script>

	
    <!-- Table plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/tables/dataTables/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/tables/dataTables/TableTools.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/tables/dataTables/ZeroClipboard.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/tables/responsive-tables/responsive-tables.js"></script><!-- Make tables responsive -->
    

    <!-- Init plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/main.js"></script><!-- Core js functions -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/datatable.js"></script><!-- Init plugins only for page -->


	<script src="<?php echo SITE_URL; ?>ASLibrary/js/asengine.js" type="text/javascript" charset="utf-8"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>ASLibrary/js/index.js" charset="utf-8"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>ASLibrary/js/logout.js" charset="utf-8"></script>
    
    </body>
</html>