<?php
include 'ASEngine/AS.php';
$user = new ASUser(ASSession::get("user_id"));
$userInfo = $user->getInfo();
if($user->isAdmin()) { 

//prepare and output result
	$user_id = new ASUser($_GET['user_id']);
    	$info = $user_id->getInfo();
		$user_id->getDetails();

		
$user_email = $info['email'];
$user_username = $info['username'];
$confirmed = $info['confirmed'];

ASSession::set("iduser", $_GET['user_id']);
?>
            <!-- Build page from here: -->
                <div class="row-fluid">
					
                    <div class="span12">

                        <div class="page-header">
                            <h4>User Info</h4>
                        </div>

                        <form class="form-horizontal seperator" id="form-user">
                            <div id="successuser"></div>
                            <div class="form-row row-fluid">
                                <div class="span12">
                                    <div class="row-fluid">
                                        <label class="form-label span3" for="username">Username:</label>
                                        <input class="span4" id="username" name="username" disabled="disabled" type="text" value="<?php echo $user_username;  ?>" />
                                    </div>
                                </div>
                            </div>
                            
                            <div class="control-group form-row row-fluid">
                                <div class="span12">
                                    <div class="row-fluid controlsmsn">
                                        <label class="form-label span3" for="email">Email:</label>
                                        <input class="span4" id="email" name="email" type="text" value="<?php echo $user_email; ?>" />
                                    </div>
                                </div>
                            </div>
                            
                            <div class="control-group form-row row-fluid">
                                <div class="span12">
                                	<div class="row-fluid controlsmsn">
                                        <label class="form-label span3" for="confirmed_status">Confirmed Status</label>
                                        	<div class="span4 controls">
                                        	<?php if($confirmed == 'N') { 
												$confirmedid = "No";
											?>
                                            <select id="confirmed" name="confirmed">
                                                <option value="N" selected="selected"><?php echo $confirmedid; ?></option>
                                                <option value="Y">Yes</option>
                                            </select>
                                    		<?php } elseif($confirmed == 'Y') { 
												$confirmedid = "Yes";
											?>
                                            <select name="select">
                                                <option value="Y" selected="selected"><?php echo $confirmedid; ?></option>
                                                <option value="N">No</option>
                                            </select>
                                    		<?php } ?>
                                			</div>
                                    </div>
                            	</div>
                            </div>
                            
                            <div class="control-group form-row row-fluid">        
                                <div class="span12">
                                    <div class="row-fluid">
                                        <div class="form-actions">
                                        <div class="span3"></div>
                                        <div class="span4 controlsmsn">
                                            <button id="update_user" name="update_user" class="btn btn-primary">Update</button>
                                            <button class="btn btn-danger cancel">Close</button>
                                        </div>
                                        </div>
                                    </div>
                                </div>   
                            </div>


                        </form>
                      
                    </div>
                    
                </div><!-- End .row-fluid -->
                
              <!-- Build page from here: --> 
                <div class="row-fluid">

                    <div class="span12">

                        <div class="page-header">
                            <h4>Change Password</h4>
                        </div>

                        <form class="form-horizontal seperator">
                            <div id="form-updatepassword"></div>
                            
                            <div class="control-group form-row row-fluid">
                                <div class="span12">
                                    <div class="row-fluid controlsmsn">
                                        <label class="form-label span3" for="new_password">New Password</label>
                                        <input class="span4" type="password" id="new_password" name="new_password" />
                                    </div>
                                </div>
                            </div>
                            
                            <div class="control-group form-row row-fluid">
                                <div class="span12">
                                    <div class="row-fluid controlsmsn">
                                        <label class="form-label span3" for="new_password_confirm">Confirm New Password</label>
                                        <input class="span4" type="password" id="new_password_confirm" name="new_password_confirm" />
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-row row-fluid">        
                                <div class="span12">
                                    <div class="row-fluid">
                                        <div class="form-actions">
                                        <div class="span3"></div>
                                        <div class="span4 controls">
                                            <button id="update_password" name="update_password" class="btn btn-primary">Update</button>
                                            <button class="btn btn-danger cancel">Close</button>
                                        </div>
                                        </div>
                                    </div>
                                </div>   
                            </div>


                        </form>
                      
                    </div><!-- End .span12 -->

                </div><!-- End .row-fluid -->
           	<!--End page -->
<?php } ?>

<script src="<?php echo SITE_URL; ?>js/sha512.js" type="text/javascript" charset="utf-8"></script>
<script src="<?php echo SITE_URL; ?>ASLibrary/js/asengine.js" type="text/javascript" charset="utf-8"></script>
<script src="<?php echo SITE_URL; ?>ASLibrary/js/edituser.js" type="text/javascript" charset="utf-8"></script>