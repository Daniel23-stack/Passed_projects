<?php
//Base ROOT PATH
define('ROOT', $_SERVER['DOCUMENT_ROOT']);

if('5.3.0' > phpversion()) {
	header("Location: conerror.php");
}


//Files
include ROOT . "/db.php";
include ROOT . "/inc/config.php";
include 'ASSession.php';
include 'ASDatabase.php';
include 'ASEmail.php';
include 'ASLogin.php';
include 'ASRegister.php';
include 'ASAdduser.php';
include 'ASUser.php';
include 'ASComment.php';

//DATABASE CONFIGURATION
$db = new ASDatabase("mysql", BKDB_HOST, BKDB_NAME, BKDB_USER, BKDB_PASS);

ASSession::startSession();

$login    = new ASLogin();
$register = new ASRegister();
$registeruser = new ASRegisteruser();
$mailer   = new ASEmail();
