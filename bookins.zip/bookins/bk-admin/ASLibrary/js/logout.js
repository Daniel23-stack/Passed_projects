$(document).ready(function () {
    
	//logout button click
    $("#logout").click(function () {
        $.ajax({
            url: "ASEngine/ASAjax.php",
            type: "POST",
            data: {action: "logout"},
            success: function (result) {
                window.location = "login.php";
            }
        });
    });

});