<?php
header("Location: ./bk-admin");
?>
