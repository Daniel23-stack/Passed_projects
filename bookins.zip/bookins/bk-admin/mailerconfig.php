<?php
include 'ASEngine/AS.php';
if(!$login->isLoggedIn())
    header("Location: login.php");
$user = new ASUser(ASSession::get("user_id"));
$userInfo = $user->getInfo();

//basic include files
require_once("../db.php");

$nav = '';

//Messages
include 'inc/messages.php';

//Current Tab Active
	$label1 = '';
	$tab1 = '';
	$label2 = '';
	$tab2 = '';
	$label3 = '';
	$tab3 = '';
if(isset($_GET['tab'])) {
	if($_GET['tab'] == '2') {
	$label2 = 'class="active"';
	$tab2 = 'in active';
	} elseif($_GET['tab'] == '3') {
	$label3 = 'class="active"';
	$tab3 = 'in active';
	}
} else {
	$label1 = 'class="active"';
	$tab1 = 'in active';
}

//Email Recipients List Data
$custom = mysqli_query($conn, "SELECT * FROM email_recipients WHERE deleted = 0 AND id > 1 ");
$customtotal = mysqli_num_rows($custom);

//Email Reservation
$email_recipients = mysqli_query($conn, "SELECT * FROM email_recipients WHERE id = 1");
$email_Data = mysqli_fetch_array($email_recipients);
//Variables
$recipient_email = $email_Data['email_address'];
$site_name = $email_Data['site_name'];
$reply_email = $email_Data['reply_email'];
$from_email = $email_Data['from_email'];

//Admin Email Template Data
$admin_mail = mysqli_query($conn, "SELECT * FROM email_template WHERE email_type = 'booking_request_notification' ");
$admin_mailData = mysqli_fetch_array($admin_mail);
//Variables
$adminmsn = $admin_mailData['email_message'];
$subjectmail = $admin_mailData['email_subject'];

//Client Email DATA
$client_mail = mysqli_query($conn, "SELECT * FROM email_template WHERE email_type = 'new_booking_confirmed' ");
$client_mailData = mysqli_fetch_array($client_mail);
//Variables
$clientemsn = $client_mailData['email_message'];
$subjectmailclient = $client_mailData['email_subject'];

//Admin Paypal Email Template Data
$admin_paypalmail = mysqli_query($conn, "SELECT * FROM email_template WHERE email_type = 'new_booking_paypal' ");
$admin_paypalmailData = mysqli_fetch_array($admin_paypalmail);
//Variables
$adminpaypalmsn = $admin_paypalmailData['email_message'];
$subjectpaypalmail = $admin_paypalmailData['email_subject'];

//Client Paypal Email DATA
$client_paypalmail = mysqli_query($conn, "SELECT * FROM email_template WHERE email_type = 'booking_request_payment' ");
$client_paypalmailData = mysqli_fetch_array($client_paypalmail);
//Variables
$clientpaypalmsn = $client_paypalmailData['email_message'];
$subjectmailclientpaypal = $client_paypalmailData['email_subject'];

//Admin Cancel Email Template Data
$admin_cancel_mail = mysqli_query($conn, "SELECT * FROM email_template WHERE email_type = 'booking_cancel_admin' ");
$admin_cancel_mailData = mysqli_fetch_array($admin_cancel_mail);
//Variables
$admincancelmsn = $admin_cancel_mailData['email_message'];
$subjectmailcancel = $admin_cancel_mailData['email_subject'];
		
//Client Cancel Email DATA
$client_cancel_mail = mysqli_query($conn, "SELECT * FROM email_template WHERE email_type = 'booking_cancel_request' ");
$client_cancel_mailData = mysqli_fetch_array($client_cancel_mail);
//Variables
$client_cancelmsn = $client_cancel_mailData['email_message'];
$subjectmailclientcancel = $client_cancel_mailData['email_subject'];

mysqli_close($conn);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo WEBSITE_NAME; ?></title>
    <meta name="author" content="Bookingo" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="application-name" content="Bookingo" />

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- Force IE9 to render in normla mode -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- Le styles -->
    <!-- Use new way for google web fonts 
    http://www.smashingmagazine.com/2012/07/11/avoiding-faux-weights-styles-google-web-fonts -->
    <!-- Headings -->
    <!-- <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css' />  -->
    <!-- Text -->
    <!-- <link href='http://fonts.googleapis.com/css?family=Droid+Sans:400,700' rel='stylesheet' type='text/css' /> --> 
    <!--[if lt IE 9]>
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:700" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=Droid+Sans:400" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=Droid+Sans:700" rel="stylesheet" type="text/css" />
    <![endif]-->

    <!-- Core stylesheets do not remove -->
    <link id="bootstrap" href="<?php echo SITE_URL; ?>css/bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link id="bootstrap-responsive" href="<?php echo SITE_URL; ?>css/bootstrap/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo SITE_URL; ?>css/supr-theme/jquery.ui.supr.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo SITE_URL; ?>css/icons.css" rel="stylesheet" type="text/css" />

    <!-- Plugin stylesheets -->
    <link href="<?php echo SITE_URL; ?>plugins/misc/qtip/jquery.qtip.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo SITE_URL; ?>plugins/forms/uniform/uniform.default.css" type="text/css" rel="stylesheet" />        
    <link href="<?php echo SITE_URL; ?>plugins/tables/dataTables/jquery.dataTables.css" type="text/css" rel="stylesheet" />
    <link href="<?php echo SITE_URL; ?>plugins/tables/dataTables/TableTools.css" type="text/css" rel="stylesheet" />

    <!-- Main stylesheets -->
    <link href="<?php echo SITE_URL; ?>css/main.css" rel="stylesheet" type="text/css" /> 

    <!-- Custom stylesheets ( Put your own changes here ) -->
    <link href="<?php echo SITE_URL; ?>css/custom.css" rel="stylesheet" type="text/css" /> 

    <!--[if IE 8]><link href="css/ie8.css" rel="stylesheet" type="text/css" /><![endif]-->

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script type="text/javascript" src="js/libs/excanvas.min.js"></script>
      <script type="text/javascript" src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <script type="text/javascript" src="js/libs/respond.min.js"></script>
    <![endif]-->

    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="<?php echo SITE_URL; ?>images/favicon.ico" />
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo SITE_URL; ?>images/apple-touch-icon-144-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo SITE_URL; ?>images/apple-touch-icon-114-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo SITE_URL; ?>images/apple-touch-icon-72-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" href="<?php echo SITE_URL; ?>images/apple-touch-icon-57-precomposed.png" />
    
    <!-- Windows8 touch icon ( http://www.buildmypinnedsite.com/ )-->
    <meta name="msapplication-TileColor" content="#3399cc"/> 

    <!-- Load modernizr first -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/libs/modernizr.js"></script>
	
    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
    <![endif]-->

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script>
$(function() {	
	$("#db-one").change(function() {
	$("#tmplallservices").load("transql/stateselector.php?choice=" + $("#db-one").val());
	});	
});
</script>
    
    </head>
      
    <body>
    <!-- loading animation -->
    <div id="qLoverlay"></div>
    <div id="qLbar"></div>
    
    <div id="header" class="fixed">

        <?php include 'inc/header.php'; ?><!-- /navbar --> 

    </div><!-- End #header -->

    <div id="wrapper">

        <!--Responsive navigation button-->  
        <div class="resBtn">
            <a href="#"><span class="icon16 minia-icon-list-3"></span></a>
        </div>
        
        <!--Sidebar collapse button-->  
        <div class="collapseBtn leftbar">
             <a href="#" class="tipR" title="Hide sidebar"><span class="icon12 minia-icon-layout"></span></a>
        </div>

        <!--Sidebar background-->
        <div id="sidebarbg"></div>
        <!--Sidebar content-->
        <div id="sidebar">
			<?php include 'inc/sidebar.php'; ?><!-- /sidebar -->
        </div><!-- End #sidebar -->

        <!--Body content-->
        <div id="content" class="clearfix">
            <div class="contentwrapper"><!--Content wrapper-->

                <div class="heading">
				<!--Content Title-->
                    <h3>Emails Administration</h3>                    

                    <div class="resBtnSearch">
                        <a href="#"><span class="icon16 icomoon-icon-search-3"></span></a>
                    </div>

                    <ul class="breadcrumb">
                        <li>
                            <a href="./" class="tip" title="back to dashboard">
                                <span class="icon16 icomoon-icon-screen-2"></span>
                            </a> 
                            <span class="divider">
                                <span class="icon16 icomoon-icon-arrow-right-3"></span>
                            </span>
                        </li>
                        <li class="active"><a href="javascript: history.go(-1)">Go Back</a></li>
                    </ul>

                </div><!-- End .heading-->


                <!-- Build page from here: -->
                <div class="row-fluid">
					
                    <div class="span12">
                            <div class="page-header">
                                <h4>Email Templates</h4>
                            </div>
                            <div style="margin-bottom: 20px;">
                                <ul id="myTab" class="nav nav-tabs pattern">
                                    <li <?php echo $label1; ?>><a href="#tab1" data-toggle="tab">Email Template</a></li>
                                    <li <?php echo $label2; ?>><a href="#tab2" data-toggle="tab">Email Recipients</a></li>
                                    <li <?php echo $label3; ?>><a href="#tab3" data-toggle="tab">Add Email Recipients</a></li>
                                </ul>

                                <div class="tab-content">
                                    <!-- Start Tab1 -->
                                    <div class="tab-pane fade <?php echo $tab1; ?>" id="tab1">
                                    	<?php echo $emailtemplatemsn; ?>
									
										<form action="transql/upds/update-default-email.php" method="post" class="form-horizontal">
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">Admin Default Email</label>
                                                        <input class="span4" type="text" name="defaultemail" value="<?php echo $recipient_email; ?>" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">Website Name</label>
                                                        <input class="span4" type="text" name="webname" value="<?php echo $site_name; ?>" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">Reply Email</label>
                                                        <input class="span4" type="text" name="replymail" value="<?php echo $reply_email; ?>" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">From Email</label>
                                                        <input class="span4" type="text" name="fromail" value="<?php echo $from_email; ?>" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-actions">
                                            	<button type="submit" class="btn btn-primary">Update</button>
                                             </div>
                                        </form>
                                        
                                        <?php echo $emailtemplatemsn2; ?>
                                        <form action="transql/upds/update-email-template.php" method="post" class="form-horizontal">
                                             <div class="page-header">
                                                <h4>New Reservation Admin</h4>
                                             </div>
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">Subject</label>
                                                        <input class="span4" type="text" name="subject_admin" value="<?php echo $subjectmail; ?>" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">Email Message</label>
                                                        <textarea class="tinymce span4" name="msnadmin"><?php echo $adminmsn; ?></textarea>
                                                    </div>
                                                </div>  
                                             </div>
                                             
                                             <?php mysqli_free_result($admin_mail); ?>
                                             
                                             <div class="page-header">
                                                <h4>New Reservation Client</h4>
                                             </div>
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">Subject</label>
                                                        <input class="span4" type="text" name="subject_client" value="<?php echo $subjectmailclient; ?>" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">Email Message</label>
                                                        <textarea class="tinymce span4" name="msnclient"><?php echo $clientemsn; ?></textarea>
                                                    </div>
                                                </div>  
                                             </div>
                                             
                                             <?php mysqli_free_result($client_mail); ?>
                                             
                                             <div class="page-header">
                                                <h4>New Reservation Admin Paypal</h4>
                                             </div>
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">Subject</label>
                                                        <input class="span4" type="text" name="subjectpaypalmail" value="<?php echo $subjectpaypalmail; ?>" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">Email Message</label>
                                                        <textarea class="tinymce span4" name="adminpaypalmsn"><?php echo $adminpaypalmsn; ?></textarea>
                                                    </div>
                                                </div>  
                                             </div>
                                             
                                             <?php mysqli_free_result($admin_paypalmail); ?>
                                             
                                             <div class="page-header">
                                                <h4>New Reservation Client Paypal</h4>
                                             </div>
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">Subject</label>
                                                        <input class="span4" type="text" name="subjectmailclientpaypal" value="<?php echo $subjectmailclientpaypal; ?>" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">Email Message</label>
                                                        <textarea class="tinymce span4" name="clientpaypalmsn"><?php echo $clientpaypalmsn; ?></textarea>
                                                    </div>
                                                </div>  
                                             </div>
                                             
                                             <?php mysqli_free_result($client_paypalmail); ?>
                                             
                                             <div class="page-header">
                                                <h4>Cancelation Email for Admin</h4>
                                             </div>
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">Subject</label>
                                                        <input class="span4" type="text" name="subjectmailcancel" value="<?php echo $subjectmailcancel; ?>" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">Email Message</label>
                                                        <textarea class="tinymce span4" name="admincancelmsn"><?php echo $admincancelmsn; ?></textarea>
                                                    </div>
                                                </div>  
                                             </div>
                                             
                                             <?php mysqli_free_result($admin_cancel_mail); ?>
                                             
                                             <div class="page-header">
                                                <h4>Cancelation Email for Client</h4>
                                             </div>
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">Subject</label>
                                                        <input class="span4" type="text" name="subject_cancel_client" value="<?php echo $subjectmailclientcancel; ?>" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">Email Message</label>
                                                        <textarea class="tinymce span4" name="client_cancelmsn"><?php echo $client_cancelmsn; ?></textarea>
                                                    </div>
                                                </div>  
                                             </div>
                                             
                                             <?php mysqli_free_result($client_cancel_mail); ?>
                                             
                                             <div class="form-actions">
                                            	<button type="submit" class="btn btn-primary">Update</button>
                                             </div>
                                        </form>
                                    </div>
                                    
                                    <!-- Start Tab2 -->
                                    <div class="tab-pane fade <?php echo $tab2; ?>" id="tab2">
										<?php echo $emailtemplatemsn3; ?>
									
									<?php if($customtotal > 0) { ?>
                                        <table cellpadding="0" cellspacing="0" border="0" class="tableTools display table table-bordered" width="100%">
                                            <thead>
                                                <tr>
                                                    <th>ID</th>
                                                  	<th>Recipient Email</th>
                                                  	<th>Status</th>
                                                  	<th>Actions</th>
                                                </tr>
                                            </thead>
                                          <tbody>
                                    <?php while($busData = mysqli_fetch_array($custom))     
										{
										 $activelement = 'Inactive';
										 $activelabel = 'label-important';
										 if($busData['active'] == 1) {
											$activelement = 'Active';
											$activelabel = 'label-success';
										 } ?>
                                            <tr class="user-row">
                                                <td><?php echo $busData['id']; ?></td>
                                              	<td><?php echo $busData['email_address']; ?></td>
                                              	<td>
                                                    <span class='label <?=$activelabel?>'>
                                                      <?=$activelement?>
                                                    </span>
                                              	</td>
                                              	<td width='200px'>
                                              		<a href="manage-email.php?emailid=<?php echo $busData['id']; ?>&email_address=<?php echo $busData['email_address']; ?>" class='btn'><i class='icon-edit'></i> <strong>Manage</strong></a>
                                    <?php if($busData['active'] == 0) { ?>
                                              		<a href="transql/upds/change-email-status.php?emailid=<?php echo $busData['id']; ?>&mailstatus=1" class='btn'><strong>Active</strong></a>
                                    <?php } elseif($busData['active'] == 1) { ?>
                                              		<a href="transql/upds/change-email-status.php?emailid=<?php echo $busData['id']; ?>&mailstatus=0" class='btn'><strong>Inactive</strong></a>
                                        	<?php } ?>
                                              	</td>
                                            </tr>
                                            <?php } ?>
                                          </tbody>
                                        </table>
                                    <?php } mysqli_free_result($custom); ?>    
                                    </div>
                                    
                                    <!-- Start Tab3 -->
                                    <div class="tab-pane fade <?php echo $tab3; ?>" id="tab3">
                                        <?php echo $emailtemplatemsn4; ?>
                                        
                                          <form action="transql/insts/new-recipient-email.php" method="post" class="form-horizontal">
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_name">Aditional Recipient Email</label>
                                                        <input class="span4" type="text" name="aditional_email" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-actions">
                                                <button type="submit" class="btn btn-primary">Submit</button>
                                             </div>
                                          </form>
                                    </div>
                                </div>
                            </div>

                        </div><!-- End .span6 -->
                    
                </div><!-- End .row-fluid -->
                <!--End page -->
                
                
            </div><!-- End contentwrapper -->
        </div><!-- End #content -->
           
    <footer>
    	<?php include 'inc/footer.php'; ?><!-- /footer -->
    </footer>
    
    </div><!-- End #wrapper -->
    
    <!-- Le javascript
    ================================================== -->
    <!-- Important plugins put in all pages -->
    <script  type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.2/jquery-ui.min.js"></script>
    <script type="text/javascript" src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/bootstrap/bootstrap.js"></script>  
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/jquery.mousewheel.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/libs/jRespond.min.js"></script>


    <!-- Misc plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/misc/qtip/jquery.qtip.min.js"></script><!-- Custom tooltip plugin -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/misc/totop/jquery.ui.totop.min.js"></script> 
    
    
    <!-- Form plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/uniform/jquery.uniform.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/maskedinput/jquery.maskedinput-1.3.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/maskedinput/jquery.maskedinput-1.3.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/tiny_mce/jquery.tinymce.js"></script>
    
    <!-- Form plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/elastic/jquery.elastic.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/inputlimiter/jquery.inputlimiter.1.3.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/maskedinput/jquery.maskedinput-1.3.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/togglebutton/jquery.toggle.buttons.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/uniform/jquery.uniform.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/globalize/globalize.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/color-picker/colorpicker.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/timeentry/jquery.timeentry.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/select/select2.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/dualselect/jquery.dualListBox-1.3.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/tiny_mce/jquery.tinymce.js"></script>
    
    
    <!-- Table plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/tables/dataTables/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/tables/dataTables/TableTools.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/tables/dataTables/ZeroClipboard.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/tables/responsive-tables/responsive-tables.js"></script><!-- Make tables responsive -->
    

    <!-- Init plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/main.js"></script><!-- Core js functions -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/datatable.js"></script><!-- Init plugins only for page -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/forms.js"></script><!-- Init plugins only for page -->


	<script src="<?php echo SITE_URL; ?>ASLibrary/js/asengine.js" type="text/javascript" charset="utf-8"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>ASLibrary/js/index.js" charset="utf-8"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>ASLibrary/js/logout.js" charset="utf-8"></script>
    
    </body>
</html>