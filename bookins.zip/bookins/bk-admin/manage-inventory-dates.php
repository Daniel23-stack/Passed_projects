<?php
//DB Data
include '../../ASEngine/AS.php';
if(!$login->isLoggedIn())
    header("Location: ../../login.php");
$user = new ASUser(ASSession::get("user_id"));
$userInfo = $user->getInfo();

//basic include files
require_once("../../../db.php");
function newdate($date)
{
    list($m, $d, $a) = explode("/", $date);
    return $a . "-" . $m . "-" . $d;
}
function daysDifference($endDate, $beginDate)
{
    $date_parts1 = explode("/", $beginDate);
    $date_parts2 = explode("/", $endDate);
    $start_date  = gregoriantojd($date_parts1[0], $date_parts1[1], $date_parts1[2]);
    $end_date    = gregoriantojd($date_parts2[0], $date_parts2[1], $date_parts2[2]);
    return $end_date - $start_date;
}
//variables
$room_id = $_POST['room_id'];
$room_name = $_POST['room_name'];
$hotel_id = $_POST['hotel_id'];
$hotel_name = $_POST['hotel_name'];
echo $avafordate = $_POST['avafordate'];
echo $avatodate = $_POST['avatodate'];
$avainventory = $_POST['avainventory'];
//Updating the availability of each room
$fiava = strtotime($avafordate);
$diava = date('d', $fiava);
$miava = date('m', $fiava);
$yiava = date('Y', $fiava);
$foava = strtotime($avatodate);
$doava = date('d', $foava);
$moava = date('m', $foava);
$yoava = date('Y', $foava);
$first_date_ava = MKTIME(12,0,0,$miava,$diava,$yiava);
$second_date_ava = MKTIME(12,0,0,$moava,$doava,$yoava);
$offset_ava = $second_date_ava-$first_date_ava;
//echo $intday_ava = $offset_ava/60/60/24;
echo $diasestadia = daysDifference($avatodate, $avafordate);
$fechaavainicial = newdate($avafordate);
$roominventory = mysqli_query($conn, "SELECT room_type_inventory FROM hotel_room_type WHERE room_type_id = '$room_id'");
$roominventoryData = mysqli_fetch_array($roominventory);
$inventariodefault = $roominventoryData['room_type_inventory'];
for ( $interva = 1 ; $interva <= $intday_ava ; $interva ++)      
    {
     $undia = $interva;
     $fechaavasiguiente = mktime(0,0,0, $miava,$diava,$yiava) + $undia * 24 * 60 * 60;
     $fechaavasalida=date("Y-m-d",$fechaavasiguiente);
	 //verificacion diaria
	 $veriday = mysqli_query($conn, "SELECT * FROM booking_check_avilability WHERE check_in_date = '$fechaavainicial' AND check_out_date = '$fechaavasalida' AND room_type_id = '$roomcode'");
     $totalveriday= mysqli_num_rows($veriday);
	 $veridayData = mysqli_fetch_array($veriday);
	 $total_booked = $veridayData['total_room'] + $rooms;	
	 //echo '<br>';
	 $availability_id  = $veridayData['check_availability_id'];
	 //echo '<br>';
	 if ($totalveriday > 0){
        mysqli_query($conn, "UPDATE booking_check_avilability SET total_room = '$total_booked' WHERE check_availability_id = '$availability_id' ");
     }else {
	    mysqli_query($conn, "INSERT INTO booking_check_avilability (check_in_date,check_out_date,room_type_id,total_room,inventory) VALUES('$fechaavainicial','$fechaavasalida','$room_id','$avainventory','$inventariodefault' )");	 
	 }
	 $fechaavainicial = $fechaavasalida;
  }

mysqli_close($conn);

//header("Location: ../../manage-room.php?roomid=".$room_id."&roomname=".$room_name."&hotelid=".$hotel_id."&hotelname=".$hotel_name."&hotelmsn=newavailability&tab=2");
?>