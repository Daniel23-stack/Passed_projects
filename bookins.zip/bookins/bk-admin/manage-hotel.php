<?php
include 'ASEngine/AS.php';
if(!$login->isLoggedIn())
    header("Location: login.php");
$user = new ASUser(ASSession::get("user_id"));
$userInfo = $user->getInfo();

//basic include files
require_once("../db.php");

$nav = 'hotels';

$hotel_id = $_GET['hotelid'];
$hotel_name =$_GET['hotelname'];

//Messages
include 'inc/messages.php';

//Current Tab Active
	$label1 = '';
	$tab1 = '';
	$label2 = '';
	$tab2 = '';
	$label3 = '';
	$tab3 = '';
	$label4 = '';
	$tab4 = '';
	$label5 = '';
	$tab5 = '';
	$label6 = '';
	$tab6 = '';
if(isset($_GET['tab'])) {
	if($_GET['tab'] == '2') {
	$label2 = 'class="active"';
	$tab2 = 'in active';
	} elseif($_GET['tab'] == '3') {
	$label3 = 'class="active"';
	$tab3 = 'in active';
	} elseif($_GET['tab'] == '4') {
	$label4 = 'class="active"';
	$tab4 = 'in active';
	} elseif($_GET['tab'] == '5') {
	$label5 = 'class="active"';
	$tab5 = 'in active';
	} elseif($_GET['tab'] == '6') {
	$label6 = 'class="active"';
	$tab6 = 'in active';
	}
} else {
	$label1 = 'class="active"';
	$tab1 = 'in active';
}

//Room Types
$custom = mysqli_query($conn, "SELECT * FROM hotel_room_type WHERE hotel_id = '$hotel_id' AND deleted = '0' ");
$customtotal = mysqli_num_rows($custom);
//Hotel Amenities
$customamenity = mysqli_query($conn, "SELECT * FROM hotel_amenities WHERE hotel_id = '$hotel_id' AND amen_deleted = '0' ");
$customamenitytotal = mysqli_num_rows($customamenity);
//Hotel Images
$customphoto = mysqli_query($conn, "SELECT * FROM hotel_images WHERE hotel_id = '$hotel_id' AND hotel_ima_deleted = '0' ");
$customphotototal = mysqli_num_rows($customphoto);
//Hotel Reviews
$customareview = mysqli_query($conn, "SELECT * FROM reviews WHERE hotelid = '$hotel_id' AND deleted = '0' ");
$customareviewtotal = mysqli_num_rows($customareview);

//Hotel Information
$hotel_info = mysqli_query($conn, "SELECT * from hotels WHERE hotel_id = '$hotel_id'");
$hotel_Data = mysqli_fetch_array($hotel_info);

//Variables Hotel Info
	$account_id = $hotel_Data['account_id'];
	$hotel_name = $hotel_Data['hotel_name'];
	$hotel_short_description = $hotel_Data['hotel_short_description'];
	$hotel_information = $hotel_Data['hotel_information'];
	$hotel_low_price = $hotel_Data['hotel_low_price'];
	$hotel_country = $hotel_Data['hotel_country'];
	$hotel_state = $hotel_Data['hotel_state'];
	$hotel_address = $hotel_Data['hotel_address'];
	$hotel_city = $hotel_Data['hotel_city'];
	$hotel_zipcode = $hotel_Data['hotel_zipcode'];
	$longitud = $hotel_Data['longitud'];
	$latitud = $hotel_Data['latitud'];
	$hotel_stars = $hotel_Data['hotel_stars'];
	$max_adults = $hotel_Data['max_adults'];
	$max_children = $hotel_Data['max_children'];
	$max_guests = $hotel_Data['max_guests'];
	$max_rooms = $hotel_Data['max_rooms'];
	$policy_cancel = $hotel_Data['policy_cancel'];
	$hotel_tax = $hotel_Data['hotel_tax'];
	$hotel_image_path = $hotel_Data['hotel_image_path'];
	

//Hotel City Data
$hotelcityid = mysqli_query($conn, "SELECT * FROM cities WHERE city_deleted = 0 ");
$hotelcitytotal = mysqli_num_rows($hotelcityid);

//Hotel Data
$hotelcountry = mysqli_query($conn, "SELECT country, countrycode FROM countries");

//User List
$users_list = mysqli_query($conn, "SELECT us.user_id, us.username, hotel_id FROM as_users AS us LEFT OUTER JOIN (SELECT hotel_id, account_id FROM hotels) AS hot ON us.user_id = hot.account_id WHERE user_role = '4' AND hotel_id IS NULL ");


//Hotel Stars
$hotelstars = mysqli_query($conn, "SELECT * FROM hotel_stars");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo WEBSITE_NAME; ?></title>
    <meta name="author" content="Bookingo" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="application-name" content="Bookingo" />

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- Force IE9 to render in normla mode -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- Le styles -->
    <!-- Use new way for google web fonts 
    http://www.smashingmagazine.com/2012/07/11/avoiding-faux-weights-styles-google-web-fonts -->
    <!-- Headings -->
    <!-- <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css' />  -->
    <!-- Text -->
    <!-- <link href='http://fonts.googleapis.com/css?family=Droid+Sans:400,700' rel='stylesheet' type='text/css' /> --> 
    <!--[if lt IE 9]>
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:700" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=Droid+Sans:400" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=Droid+Sans:700" rel="stylesheet" type="text/css" />
    <![endif]-->

    <!-- Core stylesheets do not remove -->
    <link id="bootstrap" href="<?php echo SITE_URL; ?>css/bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link id="bootstrap-responsive" href="<?php echo SITE_URL; ?>css/bootstrap/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo SITE_URL; ?>css/supr-theme/jquery.ui.supr.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo SITE_URL; ?>css/icons.css" rel="stylesheet" type="text/css" />

    <!-- Plugin stylesheets -->
    <link href="<?php echo SITE_URL; ?>plugins/misc/qtip/jquery.qtip.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo SITE_URL; ?>plugins/forms/uniform/uniform.default.css" type="text/css" rel="stylesheet" />        
    <link href="<?php echo SITE_URL; ?>plugins/tables/dataTables/jquery.dataTables.css" type="text/css" rel="stylesheet" />
    <link href="<?php echo SITE_URL; ?>plugins/tables/dataTables/TableTools.css" type="text/css" rel="stylesheet" />

    <!-- Main stylesheets -->
    <link href="<?php echo SITE_URL; ?>css/main.css" rel="stylesheet" type="text/css" /> 

    <!-- Custom stylesheets ( Put your own changes here ) -->
    <link href="<?php echo SITE_URL; ?>css/custom.css" rel="stylesheet" type="text/css" /> 

    <!--[if IE 8]><link href="css/ie8.css" rel="stylesheet" type="text/css" /><![endif]-->

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script type="text/javascript" src="js/libs/excanvas.min.js"></script>
      <script type="text/javascript" src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <script type="text/javascript" src="js/libs/respond.min.js"></script>
    <![endif]-->

    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="<?php echo SITE_URL; ?>images/favicon.ico" />
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo SITE_URL; ?>images/apple-touch-icon-144-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo SITE_URL; ?>images/apple-touch-icon-114-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo SITE_URL; ?>images/apple-touch-icon-72-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" href="<?php echo SITE_URL; ?>images/apple-touch-icon-57-precomposed.png" />
    
    <!-- Windows8 touch icon ( http://www.buildmypinnedsite.com/ )-->
    <meta name="msapplication-TileColor" content="#3399cc"/> 

    <!-- Load modernizr first -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/libs/modernizr.js"></script>
	
    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
    <![endif]-->

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script>
$(function() {	
	$("#db-one").change(function() {
	$("#tmplallservices").load("transql/stateselectoreditor.php?choice=" + $("#db-one").val());
	});	
});
</script>
    
    </head>
      
    <body>
    <!-- loading animation -->
    <div id="qLoverlay"></div>
    <div id="qLbar"></div>
    
    <div id="header" class="fixed">

        <?php include 'inc/header.php'; ?><!-- /navbar --> 

    </div><!-- End #header -->

    <div id="wrapper">

        <!--Responsive navigation button-->  
        <div class="resBtn">
            <a href="#"><span class="icon16 minia-icon-list-3"></span></a>
        </div>
        
        <!--Sidebar collapse button-->  
        <div class="collapseBtn leftbar">
             <a href="#" class="tipR" title="Hide sidebar"><span class="icon12 minia-icon-layout"></span></a>
        </div>

        <!--Sidebar background-->
        <div id="sidebarbg"></div>
        <!--Sidebar content-->
        <div id="sidebar">
			<?php include 'inc/sidebar.php'; ?><!-- /sidebar -->
        </div><!-- End #sidebar -->

        <!--Body content-->
        <div id="content" class="clearfix">
            <div class="contentwrapper"><!--Content wrapper-->

                <div class="heading">
				<!--Content Title-->
                    <h3><?php echo $hotel_name; ?> Management</h3>                    

                    <div class="resBtnSearch">
                        <a href="#"><span class="icon16 icomoon-icon-search-3"></span></a>
                    </div>

                    <ul class="breadcrumb">
                        <li>
                            <a href="./" class="tip" title="back to dashboard">
                                <span class="icon16 icomoon-icon-screen-2"></span>
                            </a> 
                            <span class="divider">
                                <span class="icon16 icomoon-icon-arrow-right-3"></span>
                            </span>
                        </li>
                        <li class="active"><a href="javascript: history.go(-1)">Go Back</a></li>
                    </ul>

                </div><!-- End .heading-->


                <!-- Build page from here: -->
                <div class="row-fluid">
					
                    <div class="span12">
                            <div class="page-header">
                                <h4>Hotel Info &nbsp; <a href="hotels.php" class="btn btn-primary"><span class="icomoon-icon-arrow-left-9 white"/> Back</a></h4>
                            </div>
                            <div style="margin-bottom: 20px;">
                                <ul id="myTab" class="nav nav-tabs pattern">
                                    <li <?php echo $label1; ?>><a href="#tab1" data-toggle="tab">Hotel Overview</a></li>
                                    <li <?php echo $label2; ?>><a href="#tab2" data-toggle="tab">Hotel Rooms</a></li>
                                    <li <?php echo $label3; ?>><a href="#tab3" data-toggle="tab">Hotel Amenities</a></li>
                                    <li <?php echo $label4; ?>><a href="#tab4" data-toggle="tab">Hotel Photos</a></li>
                                    <li <?php echo $label5; ?>><a href="#tab5" data-toggle="tab">Hotel Reviews</a></li>
                                    <?php if($user->isAdmin()) { ?>
                                      <li <?php echo $label6; ?>><a href="#tab6" data-toggle="tab">Hotel Owner</a></li>
                                    <?php } ?>
                                </ul>

                                <div class="tab-content">
                                    <!-- Start Tab1 -->
                                    <div class="tab-pane fade <?php echo $tab1; ?>" id="tab1">
										<?php echo $hotelmsn; ?>
									
										 <form action="transql/upds/update-hotel.php" method="post" name="image_upload" id="image_upload" enctype="multipart/form-data" class="form-horizontal">
                                             <input type="hidden" name="hotel_id" value="<?=$hotel_id?>">
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_name">Hotel name</label>
                                                        <input class="span4" type="text" name="hotel_name" value="<?=$hotel_name?>" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <!--<div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_expedia">Expedia Code</label>
                                                        <input class="span4" type="text" name="expidia_id" value="<//?=$expidia_id?>" />
                                                    </div>
                                                </div>
                                             </div>---->
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_description">Hotel description</label>
                                                        <textarea class="span4 limit elastic" id="textarea2" rows="3" cols="5" name="hotel_description"><?=$hotel_short_description?></textarea>
                                                    </div>
                                                </div>  
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_information">Hotel information</label>
                                                        <textarea class="tinymce span4" name="hotel_information"><?=$hotel_information?></textarea>
                                                    </div>
                                                </div>  
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_address">Hotel address</label>
                                                        <input class="span4" type="text" name="hotel_address" value="<?=$hotel_address?>" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_price">Hotel general price</label>
                                                        <input class="span4" type="text" name="hotel_price" value="<?=$hotel_low_price?>" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_tax">Hotel Tax</label>
                                                        <input class="span4" type="text" name="hotel_tax" value="<?=$hotel_tax?>" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="control-group form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">Country</label>
                                                            <div class="span4 controls">
                                                            <select name="hotel_country" id="db-one">
                                                              <option value=''>Select...</option>
																<?php			  	  	                 
                                                                    while ($hotelcountryData = mysqli_fetch_array($hotelcountry, MYSQL_ASSOC))
                                                                      if($hotelcountryData['countrycode'] == $hotel_country) {
                                                                        echo "<option value='$hotelcountryData[countrycode]' selected='selected'>$hotelcountryData[country]</option>";
                                                                      } 
                                                                      else {
                                                                        echo "<option value='$hotelcountryData[countrycode]'>$hotelcountryData[country]</option>";
                                                                      }
																	  mysqli_free_result($hotelcountry);
                                                                ?>
                                                            </select>
                                                            </div>
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div id="tmplallservices">
                                             	<?php include 'inc/manage_state.php'; ?>
                                             </div>
                                             
                                                              
                                             <div class="control-group form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">City</label>
                                                            <div class="span4 controls">
                                                            <select name="hotel_city">
                                                              <option value=''>Select...</option>
                                                              <?php			  	  	                 
																	while ($hotelcityData = mysqli_fetch_array($hotelcityid, MYSQL_ASSOC))
																	  if($hotelcityData['city_id'] == $hotel_city) {
																		echo "<option value='$hotelcityData[city_id]' selected='selected'>$hotelcityData[city_name]</option>";
																	  } 
																	  else {
																		echo "<option value='$hotelcityData[city_id]'>$hotelcityData[city_name]</option>";
																	  }
																	  mysqli_free_result($hotelcityid);
															  ?>
                                                            </select>
                                                            </div>
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_zip">Hotel zip</label>
                                                        <input class="span4" type="text" name="hotel_zipcode" value="<?=$hotel_zipcode?>" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="control-group form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">Hotel stars</label>
                                                            <div class="span4 controls">
                                                            <select name="stars" class="span6" tabindex="1">
                                                                <option value=''>Select...</option>
																<?php			  	  	                 
                                                                    while ($hotelstarsData = mysqli_fetch_array($hotelstars, MYSQL_ASSOC))
                                                                      if($hotelstarsData['star_name'] == $hotel_stars) {
                                                                        echo "<option value='$hotelstarsData[star_name]' selected='selected'>$hotelstarsData[star_name]</option>";
                                                                      }
                                                                      else {
                                                                        echo "<option value='$hotelstarsData[star_name]'>$hotelstarsData[star_name]</option>";
                                                                      }
																	  mysqli_free_result($hotelstars);
                                                                ?>
                                                            </select>
                                                            </div>
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_adults">Hotel max adults</label>
                                                        <input class="span4" type="text" name="max_adults" value="<?=$max_adults?>" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_children">Hotel max children</label>
                                                        <input class="span4" type="text" name="max_children" value="<?=$max_children?>" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_guests">Hotel max guests</label>
                                                        <input class="span4" type="text" name="max_guests" value="<?=$max_guests?>" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_rooms">Hotel max rooms</label>
                                                        <input class="span4" type="text" name="max_rooms" value="<?=$max_rooms?>" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_longitud">Hotel longitud</label>
                                                        <input class="span4" type="text" name="longitud" value="<?=$longitud?>" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_latitud">Hotel latitud</label>
                                                        <input class="span4" type="text" name="latitud" value="<?=$latitud?>" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">Hotel Policy Cancel</label>
                                                        <textarea class="span4 elastic" id="textarea2" rows="3" cols="5" name="hotel_policy_cancel"><?=$policy_cancel?></textarea>
                                                    </div>
                                                </div>  
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="image">Hotel Thumb 70x70px</label>
                                                        <img src="/bk-admin/hotelimages/<?=$hotel_image_path?>" alt="" class="image marginR10"/>
                                                        <input type="file" name="image" id="file" />
                                                    </div>
                                                </div>
                                             </div>
                                            
                                             <div class="form-actions">
                                            	<button type="submit" class="btn btn-primary">Submit</button>
                                             </div>
                                        </form>   
                                    </div>
                                    
                                    <!-- Start Tab2 -->
                                    <div class="tab-pane fade <?php echo $tab2; ?>" id="tab2">
                                    	                            
                                            <a href='add-hotel-room.php?hotelid=<?php echo $hotel_id; ?>&hotelname=<?php echo $hotel_name; ?>' class='btn btn-large btn-block btn-success'><strong>Add Room</strong></a><br />
										<?php echo $hotelmsn2; ?>
									
									<?php if($customtotal > 0) { ?>
                                        <table cellpadding="0" cellspacing="0" border="0" class="tableTools display table table-bordered" width="100%">
                                            <thead>
                                                <tr>
                                                    <th>Room Code</th>
                                                  	<th>Room Name</th>
                                                  	<th>Status</th>
                                                  	<th>Actions</th>
                                                </tr>
                                            </thead>
                                          <tbody>
                                    <?php while($busData = mysqli_fetch_array($custom))     
										{
										 $activelement = 'Inactive';
										 $activelabel = 'label-important';
										 if($busData['active'] == 1) {
			
											$activelement = 'Active';
											$activelabel = 'label-success';
										 } ?>
                                            <tr class="user-row">
                                                <td><?php echo $busData['room_type_id']; ?></td>
                                              	<td><?php echo $busData['room_type_name']; ?></td>
                                              	<td>
                                                    <span class='label <?=$activelabel?>'>
                                                      <?=$activelement?>
                                                    </span>
                                              	</td>
                                              	<td width='320px'>
                                              		<a href='manage-room.php?roomid=<?php echo $busData['room_type_id']; ?>&roomname=<?php echo $busData['room_type_name']; ?>&hotelid=<?=$hotel_id?>&hotelname=<?=$hotel_name?>' class='btn'><i class='icon-edit'></i> <strong>Manage Room</strong></a>
                                    <?php if($busData['active'] == 0) { ?>
                                              		<a href='transql/upds/change-room-status.php?roomid=<?php echo $busData['room_type_id']; ?>&roomstatus=1&hotelid=<?=$hotel_id?>&hotelname=<?=$hotel_name?>' class='btn'><strong>Active</strong></a>
                                    <?php } elseif($busData['active'] == 1) { ?>
                                              		<a href='transql/upds/change-room-status.php?roomid=<?php echo $busData['room_type_id']; ?>&roomstatus=0&hotelid=<?=$hotel_id?>&hotelname=<?=$hotel_name?>' class='btn'><strong>Inactive</strong></a>
                                            <?php } ?>
                                                 <a href='transql/upds/delete-room.php?roomid=<?php echo $busData['room_type_id']; ?>&hotelid=<?=$hotel_id?>&hotelname=<?=$hotel_name?>' class='btn'><strong>Delete</strong></a>
                                              </td>
                                            </tr>
                                            <?php } ?>
                                          </tbody>
                                        </table>
                                    <?php } mysqli_free_result($custom); ?>
                                    </div>
                                    
                                    <!-- Start Tab3 -->
                                    <div class="tab-pane fade <?php echo $tab3; ?>" id="tab3">
                                        	<a href='add-hotel-amenity.php?hotelid=<?php echo $hotel_id; ?>&hotelname=<?php echo $hotel_name; ?>' class='btn btn-large btn-block btn-success'><strong>Add Amenities</strong></a><br />
										<?php echo $hotelmsn3; ?>
                                        
                                    <?php if($customamenitytotal > 0) { ?>
                                        <table cellpadding="0" cellspacing="0" border="0" class="tableTools2 display table table-bordered" width="100%">
                                            <thead>
                                                <tr>
                                                    <th>Amenity Name</th>
                                                  	<th>Status</th>
                                                  	<th>Actions</th>
                                                </tr>
                                            </thead>
                                          <tbody>
                                    <?php while($customamenityData = mysqli_fetch_array($customamenity))     
										{
										 $activelementamen = 'Inactive';
										 $activelabelamen = 'label-important';
										 if($customamenityData['amen_active'] == 1) {
											$activelementamen = 'Active';
											$activelabelamen = 'label-success';
										 } ?>
                                            <tr class="user-row">
                                                <td><?php echo $customamenityData['amen_description']; ?></td>
                                              	<td>
                                                    <span class='label <?=$activelabelamen?>'>
                                                      <?=$activelementamen?>
                                                    </span>
                                              	</td>
                                              	<td width='320px'>
                                	<?php if($customamenityData['amen_active'] == 0) { ?>
                                              		<a href='transql/upds/change-amenity-status.php?amenityid=<?php echo $customamenityData['amenity_id']; ?>&amenitystatus=1&hotelid=<?=$hotel_id?>&hotelname=<?=$hotel_name?>' class='btn'><strong>Active</strong></a>
                                	<?php } elseif($customamenityData['amen_active'] == 1) { ?>
                                              		<a href='transql/upds/change-amenity-status.php?amenityid=<?php echo $customamenityData['amenity_id']; ?>&amenitystatus=0&hotelid=<?=$hotel_id?>&hotelname=<?=$hotel_name?>' class='btn'><strong>Inactive</strong></a>
                                			<?php } ?>
                                                    <a href='transql/upds/delete-amenity.php?amenityid=<?php echo $customamenityData['amenity_id']; ?>&hotelid=<?=$hotel_id?>&hotelname=<?=$hotel_name?>' class='btn'><strong>Delete</strong></a>							  
                                              </td>
                                            </tr>
                                            <?php } ?>
                                          </tbody>
                                        </table>
                                    <?php } mysqli_free_result($customamenity); ?>      
                                    </div>
                                    
                                    <!-- Start Tab4 -->
                                    <div class="tab-pane fade <?php echo $tab4; ?>" id="tab4">
                                    		<a href='add-hotel-photos.php?hotelid=<?php echo $hotel_id; ?>&hotelname=<?php echo $hotel_name; ?>' class='btn btn-large btn-block btn-success'><strong>Add Photos</strong></a><br />
										<?php echo $hotelmsn4; ?>
                                    
                                    <?php if($customphotototal > 0) { ?>
                                        <table cellpadding="0" cellspacing="0" border="0" class="tableTools3 display table table-bordered" width="100%">
                                            <thead>
                                                <tr>
                                                    <th>Photo</th>
                                                  	<th>Status</th>
                                                  	<th>Actions</th>
                                                </tr>
                                            </thead>
                                          <tbody>
                                    <?php while($customphotoData = mysqli_fetch_array($customphoto))     
										{
										 $activelementphoto = 'Inactive';
										 $activelabelphoto = 'label-important';
										 if($customphotoData['hotel_ima_active'] == 1) {
											$activelementphoto = 'Active';
											$activelabelphoto = 'label-success';
										 } ?>
                                            <tr class="user-row">
                                                <td><img class='rsTmb' width='56' height='56' src='upload_photos/images/<?php echo $customphotoData['hotel_image_url']; ?>'></td>
                                              	<td>
                                                    <span class='label <?=$activelabelphoto?>'>
                                                      <?=$activelementphoto?>
                                                    </span>
                                              	</td>
                                              	<td width='320px'>
                                	<?php if($customphotoData['hotel_ima_active'] == 0) { ?>
                                              		<a href='transql/upds/change-photo-status.php?photoid=<?php echo $customphotoData['hotel_image_id']; ?>&photostatus=1&hotelid=<?=$hotel_id?>&hotelname=<?=$hotel_name?>' class='btn'><strong>Active</strong></a>
                                	<?php } elseif($customphotoData['hotel_ima_active'] == 1) { ?>
                                              		<a href='transql/upds/change-photo-status.php?photoid=<?php echo $customphotoData['hotel_image_id']; ?>&photostatus=0&hotelid=<?=$hotel_id?>&hotelname=<?=$hotel_name?>' class='btn'><strong>Inactive</strong></a>
                                         	<?php } ?>	
                                                    <a href='transql/upds/delete-photo.php?photoid=<?php echo $customphotoData['hotel_image_id']; ?>&hotelid=<?=$hotel_id?>&hotelname=<?=$hotel_name?>' class='btn'><strong>Delete</strong></a>						  
                                            	</td>
                                            </tr>
                                            <?php } ?>
                                          </tbody>
                                        </table>
                                    <?php } mysqli_free_result($customphoto); ?>      
                                    </div>
                                    
                                    <!-- Start Tab5 -->
                                    <div class="tab-pane fade <?php echo $tab5; ?>" id="tab5">
										<?php echo $hotelmsn5; ?>
                                    
                                    <?php if($customareviewtotal > 0) { ?>
                                        <table cellpadding="0" cellspacing="0" border="0" class="tableTools4 display table table-bordered" width="100%">
                                            <thead>
                                                <tr>
                                                    <th>Review</th>
                                                  	<th>Status</th>
                                                  	<th>Actions</th>
                                                </tr>
                                            </thead>
                                          <tbody>
                                    <?php while($customareviewData = mysqli_fetch_array($customareview))     
										{
										 $activelementreview = 'Inactive';
										 $activelabelreview = 'label-important';
										 if($customareviewData['active'] == 1) {
											$activelementreview = 'Active';
											$activelabelreview = 'label-success';
										 } ?>
                                            <tr class="user-row">
                                                <td><?php echo $customareviewData['review']; ?></td>
                                              	<td>
                                                    <span class='label <?=$activelabelreview?>'>
                                                      <?=$activelementreview?>
                                                    </span>
                                              	</td>
                                              	<td width='250px'>
                                	<?php if($customareviewData['active'] == 0) { ?>
                                              		<a href='transql/upds/change-review-status.php?reviewid=<?php echo $customareviewData['review_id']; ?>&reviewstatus=1&hotelid=<?=$hotel_id?>&hotelname=<?=$hotel_name?>' class='btn'><strong>Active</strong></a>
                                	<?php } elseif($customareviewData['active'] == 1) { ?>
                                              		<a href='transql/upds/change-review-status.php?reviewid=<?php echo $customareviewData['review_id']; ?>&reviewstatus=0&hotelid=<?=$hotel_id?>&hotelname=<?=$hotel_name?>' class='btn'><strong>Inactive</strong></a>
                                        	<?php }	?>						  
                                            	</td>
                                            </tr>
                                            <?php } ?>
                                          </tbody>
                                        </table>
                                    <?php } mysqli_free_result($customareview); ?>      
                                    </div>
                                    
                                    <?php if($user->isAdmin()) { ?>
                                    <!-- Start Tab6 -->
                                    <div class="tab-pane fade <?php echo $tab6; ?>" id="tab6">
                                    	<?php echo $hotelmsn6; ?>
                                        
                                        <form action="transql/upds/update-hotel-owner.php" method="post" class="form-horizontal">
                                             	<input type="hidden" name="hotel_id" value="<?=$hotel_id?>">
                             					<input type="hidden" name="hotel_name" value="<?=$hotel_name?>">
                                             
                                            <div class="control-group form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">Select User</label>
                                                            <div class="span4 controls">
                                                            <select name="hotel_owner">
                                                              <option value=''>Select...</option>
                                                                <?php			  	  	                 
																	while ($users_Data = mysqli_fetch_array($users_list, MYSQL_ASSOC))
																	  if($users_Data['user_id'] == $account_id) {
																		echo "<option value='$users_Data[user_id]' selected='selected'>$users_Data[username]</option>";
																	  } 
																	  else {
																		echo "<option value='$users_Data[user_id]'>$users_Data[username]</option>";
																	  } mysqli_free_result($users_list);
																?>
                                                            </select>
                                                            </div>
                                                    </div>
                                                </div>
                                            </div>
                                             
                                            <div id="tmplallservices"></div>
                                             
                                            <div class="form-actions">
                                               <button type="submit" class="btn btn-primary">Submit</button>
                                            </div>
                                        </form>  
                                    </div>
                                    <?php } ?>
                                    
                                </div>
                            </div>

                        </div><!-- End .span6 -->
                    
                </div><!-- End .row-fluid -->
                <!--End page -->
                
                
            </div><!-- End contentwrapper -->
        </div><!-- End #content -->
           
    <footer>
    	<?php include 'inc/footer.php'; ?><!-- /footer -->
    </footer>
    
    </div><!-- End #wrapper -->
    
    <!-- Le javascript
    ================================================== -->
    <!-- Important plugins put in all pages -->
    <script  type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.2/jquery-ui.min.js"></script>
    <script type="text/javascript" src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/bootstrap/bootstrap.js"></script>  
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/jquery.mousewheel.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/libs/jRespond.min.js"></script>


    <!-- Misc plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/misc/qtip/jquery.qtip.min.js"></script><!-- Custom tooltip plugin -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/misc/totop/jquery.ui.totop.min.js"></script> 
    
    
    <!-- Form plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/uniform/jquery.uniform.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/maskedinput/jquery.maskedinput-1.3.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/maskedinput/jquery.maskedinput-1.3.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/tiny_mce/jquery.tinymce.js"></script>
    
    <!-- Form plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/elastic/jquery.elastic.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/inputlimiter/jquery.inputlimiter.1.3.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/maskedinput/jquery.maskedinput-1.3.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/togglebutton/jquery.toggle.buttons.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/uniform/jquery.uniform.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/globalize/globalize.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/color-picker/colorpicker.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/timeentry/jquery.timeentry.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/select/select2.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/dualselect/jquery.dualListBox-1.3.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/tiny_mce/jquery.tinymce.js"></script>
    
    
    <!-- Table plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/tables/dataTables/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/tables/dataTables/TableTools.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/tables/dataTables/ZeroClipboard.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/tables/responsive-tables/responsive-tables.js"></script><!-- Make tables responsive -->
    

    <!-- Init plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/main.js"></script><!-- Core js functions -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/datatable.js"></script><!-- Init plugins only for page -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/forms.js"></script><!-- Init plugins only for page -->


	<script src="<?php echo SITE_URL; ?>ASLibrary/js/asengine.js" type="text/javascript" charset="utf-8"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>ASLibrary/js/index.js" charset="utf-8"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>ASLibrary/js/logout.js" charset="utf-8"></script>
    
    </body>
</html>