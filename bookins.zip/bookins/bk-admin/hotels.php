<?php
include 'ASEngine/AS.php';
if(!$login->isLoggedIn())
    header("Location: login.php");
$user = new ASUser(ASSession::get("user_id"));
$userInfo = $user->getInfo();
$user_id = $userInfo['user_id'];

//basic include files
require_once("../db.php");

$nav = '';

//Messages
include 'inc/messages.php';

//Current Tab Active
	$label1 = '';
	$tab1 = '';
	$label2 = '';
	$tab2 = '';
	$label3 = '';
	$tab3 = '';
if(isset($_GET['tab'])) {
	if($_GET['tab'] == '2') {
	$label2 = 'class="active"';
	$tab2 = 'in active';
	} elseif($_GET['tab'] == '3') {
	$label3 = 'class="active"';
	$tab3 = 'in active';
	}
} else {
	$label1 = 'class="active"';
	$tab1 = 'in active';
}

//AGREGAR ESTO AL QUERY SI ES OTRO PERFIL
$queryadd = '';
if($_SESSION['roleuser'] == 4){
	$queryadd = 'AND account_id ='.$user_id;
}
//Hotel Data
$custom = mysqli_query($conn, "SELECT * FROM hotels WHERE deleted = 0 $queryadd ");
$customtotal = mysqli_num_rows($custom);

//Hotel City Data
$hotelcityid = mysqli_query($conn, "SELECT * FROM cities WHERE city_deleted = 0 ");
$hotelcitytotal = mysqli_num_rows($hotelcityid);

//Hotel Country Data
$hotelcountry = mysqli_query($conn, "SELECT country, countrycode FROM countries");

mysqli_close($conn);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo WEBSITE_NAME; ?></title>
    <meta name="author" content="Bookingo" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="application-name" content="Bookingo" />

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- Force IE9 to render in normla mode -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- Le styles -->
    <!-- Use new way for google web fonts 
    http://www.smashingmagazine.com/2012/07/11/avoiding-faux-weights-styles-google-web-fonts -->
    <!-- Headings -->
    <!-- <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css' />  -->
    <!-- Text -->
    <!-- <link href='http://fonts.googleapis.com/css?family=Droid+Sans:400,700' rel='stylesheet' type='text/css' /> --> 
    <!--[if lt IE 9]>
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:700" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=Droid+Sans:400" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=Droid+Sans:700" rel="stylesheet" type="text/css" />
    <![endif]-->

    <!-- Core stylesheets do not remove -->
    <link id="bootstrap" href="<?php echo SITE_URL; ?>css/bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link id="bootstrap-responsive" href="<?php echo SITE_URL; ?>css/bootstrap/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo SITE_URL; ?>css/supr-theme/jquery.ui.supr.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo SITE_URL; ?>css/icons.css" rel="stylesheet" type="text/css" />

    <!-- Plugin stylesheets -->
    <link href="<?php echo SITE_URL; ?>plugins/misc/qtip/jquery.qtip.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo SITE_URL; ?>plugins/forms/uniform/uniform.default.css" type="text/css" rel="stylesheet" />        
    <link href="<?php echo SITE_URL; ?>plugins/tables/dataTables/jquery.dataTables.css" type="text/css" rel="stylesheet" />
    <link href="<?php echo SITE_URL; ?>plugins/tables/dataTables/TableTools.css" type="text/css" rel="stylesheet" />

    <!-- Main stylesheets -->
    <link href="<?php echo SITE_URL; ?>css/main.css" rel="stylesheet" type="text/css" /> 

    <!-- Custom stylesheets ( Put your own changes here ) -->
    <link href="<?php echo SITE_URL; ?>css/custom.css" rel="stylesheet" type="text/css" /> 

    <!--[if IE 8]><link href="css/ie8.css" rel="stylesheet" type="text/css" /><![endif]-->

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script type="text/javascript" src="js/libs/excanvas.min.js"></script>
      <script type="text/javascript" src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <script type="text/javascript" src="js/libs/respond.min.js"></script>
    <![endif]-->

    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="<?php echo SITE_URL; ?>images/favicon.ico" />
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo SITE_URL; ?>images/apple-touch-icon-144-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo SITE_URL; ?>images/apple-touch-icon-114-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo SITE_URL; ?>images/apple-touch-icon-72-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" href="<?php echo SITE_URL; ?>images/apple-touch-icon-57-precomposed.png" />
    
    <!-- Windows8 touch icon ( http://www.buildmypinnedsite.com/ )-->
    <meta name="msapplication-TileColor" content="#3399cc"/> 

    <!-- Load modernizr first -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/libs/modernizr.js"></script>
	
    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
    <![endif]-->

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script>
$(function() {	
	$("#db-one").change(function() {
	$("#tmplallservices").load("transql/stateselector.php?choice=" + $("#db-one").val());
	});	
});
</script>
    
    </head>
      
    <body>
    <!-- loading animation -->
    <div id="qLoverlay"></div>
    <div id="qLbar"></div>
    
    <div id="header" class="fixed">

        <?php include 'inc/header.php'; ?><!-- /navbar --> 

    </div><!-- End #header -->

    <div id="wrapper">

        <!--Responsive navigation button-->  
        <div class="resBtn">
            <a href="#"><span class="icon16 minia-icon-list-3"></span></a>
        </div>
        
        <!--Sidebar collapse button-->  
        <div class="collapseBtn leftbar">
             <a href="#" class="tipR" title="Hide sidebar"><span class="icon12 minia-icon-layout"></span></a>
        </div>

        <!--Sidebar background-->
        <div id="sidebarbg"></div>
        <!--Sidebar content-->
        <div id="sidebar">
			<?php include 'inc/sidebar.php'; ?><!-- /sidebar -->
        </div><!-- End #sidebar -->

        <!--Body content-->
        <div id="content" class="clearfix">
            <div class="contentwrapper"><!--Content wrapper-->

                <div class="heading">
				<!--Content Title-->
                    <h3>Hotels Administration</h3>                    

                    <div class="resBtnSearch">
                        <a href="#"><span class="icon16 icomoon-icon-search-3"></span></a>
                    </div>

                    <ul class="breadcrumb">
                        <li>
                            <a href="./" class="tip" title="back to dashboard">
                                <span class="icon16 icomoon-icon-screen-2"></span>
                            </a> 
                            <span class="divider">
                                <span class="icon16 icomoon-icon-arrow-right-3"></span>
                            </span>
                        </li>
                        <li class="active"><a href="javascript: history.go(-1)">Go Back</a></li>
                    </ul>

                </div><!-- End .heading-->


                <!-- Build page from here: -->
                <div class="row-fluid">
					
                    <div class="span12">
                            <div class="page-header">
                                <h4>Hotel List</h4>
                            </div>
                            <div style="margin-bottom: 20px;">
                                <ul id="myTab" class="nav nav-tabs pattern">
                                    <li <?php echo $label1; ?>><a href="#tab1" data-toggle="tab">Hotels List</a></li>
                                    <?php if($user->isAdmin()){
                                     echo"<li $label2 ><a href='#tab2' data-toggle='tab'>Add Direct Hotel</a></li>";
                                    }
                                    ?>
                                </ul>

                                <div class="tab-content">
                                    <!-- Start Tab1 -->
                                    <div class="tab-pane fade <?php echo $tab1; ?>" id="tab1">
										<?php echo $hotelmsn; ?>
									
									<?php if($customtotal > 0) { ?>
                                        <table cellpadding="0" cellspacing="0" border="0" class="tableTools display table table-bordered" width="100%">
                                            <thead>
                                                <tr>
                                                    <th>Hotel Code</th>
                                                  	<th>Hotel Name</th>
                                                  	<th>Status</th>
                                                  	<th>Actions</th>
                                                </tr>
                                            </thead>
                                          <tbody>
                                    <?php while($busData = mysqli_fetch_array($custom))     
										{
										 $activelement = 'Inactive';
										 $activelabel = 'label-important';
										 if($busData['active'] == 1) {
											$activelement = 'Active';
											$activelabel = 'label-success';
										 } ?>
                                            <tr class="user-row">
                                                <td><?php echo $busData['hotel_id']; ?></td>
                                              	<td><?php echo $busData['hotel_name']; ?></td>
                                              	<td>
                                                    <span class='label <?=$activelabel?>'>
                                                      <?=$activelement?>
                                                    </span>
                                              	</td>
                                              	<td width='270px'>
                                              		<a href="manage-hotel.php?hotelid=<?php echo $busData['hotel_id']; ?>&hotelname=<?php echo $busData['hotel_name']; ?>" class='btn'><i class='icon-edit'></i> <strong>Manage</strong></a>
                                    <?php if($busData['active'] == 0) { ?>
                                              		<a href="transql/upds/change-hotel-status.php?hotelid=<?php echo $busData['hotel_id']; ?>&hstatus=1" class='btn'><strong>Active</strong></a>
                                    <?php } elseif($busData['active'] == 1) { ?>
                                              		<a href="transql/upds/change-hotel-status.php?hotelid=<?php echo $busData['hotel_id']; ?>&hstatus=0" class='btn'><strong>Inactive</strong></a>
                                        	<?php } ?>
                                                    <a href="transql/upds/delete-hotel.php?hotelid=<?php echo $busData['hotel_id']; ?>" class='btn'><strong>Delete</strong></a>
                                              	</td>
                                            </tr>
                                            <?php } ?>
                                          </tbody>
                                        </table>
                                    <?php } mysqli_free_result($custom); ?>    
                                    </div>
                                    
                                    <!-- Start Tab2 -->
                                    <?php if($user->isAdmin()) { ?>
                                    <div class="tab-pane fade <?php echo $tab2; ?>" id="tab2">
                                    	<?php echo $hotelmsn2; ?>
									
										<form action="transql/insts/hotel-new.php" method="post" name="image_upload" id="image_upload" enctype="multipart/form-data" class="form-horizontal">
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_name">Hotel name</label>
                                                        <input class="span4" type="text" name="hotel_name" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_description">Hotel description</label>
                                                        <textarea class="span4 limit elastic" id="textarea2" rows="3" cols="5" name="hotel_description"></textarea>
                                                    </div>
                                                </div>  
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_information">Hotel information</label>
                                                        <textarea class="tinymce span4" name="hotel_information"></textarea>
                                                    </div>
                                                </div>  
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_address">Hotel address</label>
                                                        <input class="span4" type="text" name="hotel_address" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_price">Hotel general price</label>
                                                        <input class="span4" type="text" name="hotel_price" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_tax">Hotel tax</label>
                                                        <input class="span4" type="text" name="hotel_tax" value="0.00" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="control-group form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">Country</label>
                                                            <div class="span4 controls">
                                                            <select name="hotel_country" id="db-one">
                                                              <option value=''>Select...</option>
                                                              <?php
																  while($hotelcountryData = mysqli_fetch_array($hotelcountry)) { 
																  //variables
																  $countrycode = $hotelcountryData['countrycode'];
																  $country = $hotelcountryData['country'];
															  ?>
                                                              <option value="<?php echo $countrycode; ?>"><?php echo $country; ?></option>
                                                            
                                                              <?php } mysqli_free_result($hotelcountry); ?>
                                                            </select>
                                                            </div>
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div id="tmplallservices"></div>
                                                                   
                                             <div class="control-group form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">City</label>
                                                            <div class="span4 controls">
                                                            <select name="hotel_city">
                                                              <option value=''>Select...</option>
                                                              <?php
																  while($hotelcityData = mysqli_fetch_array($hotelcityid)) { 
																  //variables
																  $city_id = $hotelcityData['city_id'];
																  $city_name = $hotelcityData['city_name'];
															  ?>
																<option value="<?php echo $city_id; ?>"><?php echo $city_name; ?></option>
															
															  <?php } mysqli_free_result($hotelcityid); ?>
                                                            </select>
                                                            </div>
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_zip">Hotel zip</label>
                                                        <input class="span4" type="text" name="hotel_zipcode" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="control-group form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">Hotel stars</label>
                                                            <div class="span4 controls">
                                                            <select name="stars" class="span6" tabindex="1">
                                                                <option value="">Select...</option>
                                                                <option value="1.0">1</option>
                                                                <option value="1.5">1.5</option>
                                                                <option value="2.0">2</option>
                                                                <option value="2.5">2.5</option>
                                                                <option value="3.0">3</option>
                                                                <option value="3.5">3.5</option>
                                                                <option value="4.0">4</option>
                                                                <option value="4.5">4.5</option>
                                                                <option value="5.0">5</option>
                                                            </select>
                                                            </div>
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_adults">Hotel max adults</label>
                                                        <input class="span4" type="text" name="max_adults" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_children">Hotel max children</label>
                                                        <input class="span4" type="text" name="max_children" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_guests">Hotel max guests</label>
                                                        <input class="span4" type="text" name="max_guests" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_rooms">Hotel max rooms</label>
                                                        <input class="span4" type="text" name="max_rooms" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_longitud">Hotel longitud</label>
                                                        <input class="span4" type="text" name="longitud" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="hotel_latitud">Hotel latitud</label>
                                                        <input class="span4" type="text" name="latitud" />
                                                    </div>
                                                </div>
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3">Hotel Policy Cancel</label>
                                                        <textarea class="span4 elastic" id="textarea2" rows="3" cols="5" name="hotel_policy_cancel"></textarea>
                                                    </div>
                                                </div>  
                                             </div>
                                             
                                             <div class="form-row row-fluid">
                                                <div class="span12">
                                                    <div class="row-fluid">
                                                        <label class="form-label span3" for="image">Hotel Thumb 70x70px</label>
                                                        <img src="/bk-admin/hotelimages/city_hotel_icon70x70.png" alt="" class="image marginR10"/>
                                                        <input type="file" name="image" id="file" />
                                                    </div>
                                                </div>
                                             </div>
                                            
                                             <div class="form-actions">
                                            	<button type="submit" class="btn btn-primary">Submit</button>
                                             </div>
                                        </form>
                                    </div>
                                    <?php } ?>
                                 
                                </div>
                            </div>

                        </div><!-- End .span6 -->
                    
                </div><!-- End .row-fluid -->
                <!--End page -->
                
                
            </div><!-- End contentwrapper -->
        </div><!-- End #content -->
           
    <footer>
    	<?php include 'inc/footer.php'; ?><!-- /footer -->
    </footer>
    
    </div><!-- End #wrapper -->
    
    <!-- Le javascript
    ================================================== -->
    <!-- Important plugins put in all pages -->
    <script  type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.2/jquery-ui.min.js"></script>
    <script type="text/javascript" src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/bootstrap/bootstrap.js"></script>  
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/jquery.mousewheel.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/libs/jRespond.min.js"></script>


    <!-- Misc plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/misc/qtip/jquery.qtip.min.js"></script><!-- Custom tooltip plugin -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/misc/totop/jquery.ui.totop.min.js"></script> 
    
    
    <!-- Form plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/uniform/jquery.uniform.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/maskedinput/jquery.maskedinput-1.3.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/maskedinput/jquery.maskedinput-1.3.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/tiny_mce/jquery.tinymce.js"></script>
    
    <!-- Form plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/elastic/jquery.elastic.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/inputlimiter/jquery.inputlimiter.1.3.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/maskedinput/jquery.maskedinput-1.3.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/togglebutton/jquery.toggle.buttons.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/uniform/jquery.uniform.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/globalize/globalize.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/color-picker/colorpicker.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/timeentry/jquery.timeentry.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/select/select2.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/dualselect/jquery.dualListBox-1.3.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/tiny_mce/jquery.tinymce.js"></script>
    
    
    <!-- Table plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/tables/dataTables/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/tables/dataTables/TableTools.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/tables/dataTables/ZeroClipboard.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/tables/responsive-tables/responsive-tables.js"></script><!-- Make tables responsive -->
    

    <!-- Init plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/main.js"></script><!-- Core js functions -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/datatable.js"></script><!-- Init plugins only for page -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/forms.js"></script><!-- Init plugins only for page -->


	<script src="<?php echo SITE_URL; ?>ASLibrary/js/asengine.js" type="text/javascript" charset="utf-8"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>ASLibrary/js/index.js" charset="utf-8"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>ASLibrary/js/logout.js" charset="utf-8"></script>
    
    </body>
</html>