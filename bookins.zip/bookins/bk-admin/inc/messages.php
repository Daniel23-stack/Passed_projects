<?php

//Messages Inventories: manage-inventory.php, microsite.php
$smessage = '';
$smessage2 = '';
$smessage3 = '';
if($_GET) {
if(isset($_GET['message'])) {

//microsite.php and manage-inventory.php Tab1
	if($_GET['message'] == '0') {
	$smessage = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The element was Unpublished successfully.
                 </div>';
	}
	
	if($_GET['message'] == '1') {
	$smessage = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The element was Published successfully.
                 </div>';
	}
	if($_GET['message'] == '2') {
	$smessage = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The element was converted in a TOP DESTINATION successfully.
                 </div>';
	}
	
	if($_GET['message'] == '3') {
	$smessage = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The element was converted in a REGULAR DESTINATION successfully.
                 </div>';
	}	
	if($_GET['message'] == '6') {
	$smessage = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The element was converted in a HOT DEAL successfully.
                 </div>';
	}
	
	if($_GET['message'] == '7') {
	$smessage = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The element was converted in a REGULAR DEAL successfully.
                 </div>';
	}	
//########### END #############//	

//microsite.php	Tab2
	if($_GET['message'] == 'active') {
	$smessage2 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The inventory was Activated successfully.
                 </div>';
	}
	if($_GET['message'] == 'del') {
	$smessage2 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The inventory was Deleted successfully.
                 </div>';
	}
//########### END #############//

//microsite.php	Tab3
	if($_GET['message'] == 'added') {
	$smessage3 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The inventory was Added successfully.
                 </div>';
	}
//########### END #############//

//microsite.php	Tab4
if($_GET['message'] == '4') {
	$smessage4 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The element was converted in a WORLDWIDE TOP DESTINATION successfully.
                 </div>';
}
	
if($_GET['message'] == '5') {
   $smessage4 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The element was converted in a LOCAL TOP DESTINATION successfully.
                 </div>';
	}
//########### END #############//


//manage-inventory.php Tab1		
	if($_GET['message'] == 'remove_element') {
	$smessage = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The element was removed successfully.
                 </div>';
	}
//########### END #############//

//manage-inventory.php Tab2
	if($_GET['message'] == 'add2') {
	$smessage2 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The City was Added successfully.
                 </div>';
	}
//########### END #############//

//manage-inventory.php Tab3
	if($_GET['message'] == 'add1') {
	$smessage3 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Hotel was Added successfully.
                 </div>';
	}
//########### END #############//
}
}

//Messages Cities: cities.php
$citymsn = '';
$citymsn2 = '';
if($_GET) {
if(isset($_GET['citymsn'])) {

//cities.php Tab1
    if($_GET['citymsn'] == '2') {
	$citymsn = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The City was Deleted successfully.
                 </div>';
	}
			
	if($_GET['citymsn'] == '1') {
	$citymsn = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The City was Activated successfully.
                 </div>';
	}

	if($_GET['citymsn'] == '0') {
	$citymsn = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The City was Inactivated successfully.
                 </div>';
	}
//########### END #############//

//cities.php Tab2
	if($_GET['citymsn'] == 'added') {
	$citymsn2 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The City was Added successfully.
                 </div>';
	}
//########### END #############//
}
}

//Messages Hotels: hotels.php and manage-hotel.php, manage-room.php, add-hotel-amenity.php
$hotelmsn = '';
$hotelmsn2 = '';
$hotelmsn3 = '';
$hotelmsn4 = '';
$hotelmsn5 = '';
$hotelmsn6 = '';
$hotelmsn7 = '';
if($_GET) {
if(isset($_GET['hotelmsn'])) {

//hotels.php Tab1		
	if($_GET['hotelmsn'] == '1') {
	$hotelmsn = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Hotel was Activated successfully.
                 </div>';
	}

	if($_GET['hotelmsn'] == '0') {
	$hotelmsn = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Hotel was Inactivated successfully.
                 </div>';
	}

	if($_GET['hotelmsn'] == 'deleted') {
	$hotelmsn = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Hotel was Deleted successfully.
                 </div>';
	}
//########### END #############//

//hotels.php Tab2
	if($_GET['hotelmsn'] == 'added') {
	$hotelmsn2 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Hotel was Added successfully.
                 </div>';
	}

	if($_GET['hotelmsn'] == 'error') {
	$errormsn = $_GET['errormsn'];
	$hotelmsn2 = '<div class="alert alert-error">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Oh snap!</strong>
					 '.$errormsn.'.
                 </div>';
	}
//########### END #############//

//hotels.php Tab3
	if($_GET['hotelmsn'] == 'addedex') {
	$hotelmsn3 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Hotel was Added successfully.
                 </div>';
	}
//########### END #############//

//manage-hotel.php Tab1
	if($_GET['hotelmsn'] == 'update') {
	$hotelmsn = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Hotel was Added successfully.
                 </div>';
	}
	
	if($_GET['hotelmsn'] == 'error2') {
	$errormsn = $_GET['errormsn'];
	$hotelmsn = '<div class="alert alert-error">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Oh snap!</strong>
					 '.$errormsn.'.
                 </div>';
	}
//########### END #############//

//manage-hotel.php Tab2
	if($_GET['hotelmsn'] == 'addedroom') {
	$hotelmsn2 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Room was Added successfully.
                 </div>';
	}
	
	if($_GET['hotelmsn'] == 'deletedroom') {
	$hotelmsn2 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Room was Deleted successfully.
                 </div>';
	}

	if($_GET['hotelmsn'] == 'a0') {
	$hotelmsn2 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Room was Inactivated successfully.
                 </div>';
	}
	
	if($_GET['hotelmsn'] == 'a1') {
	$hotelmsn2 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Room was Activated successfully.
                 </div>';
	}
//########### END #############//

//manage_room.php Tab1
	if($_GET['hotelmsn'] == 'Y') {
	$hotelmsn = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Room Price was Activated successfully.
                 </div>';
	}
//########### END #############//

//manage_room.php Tab1
	if($_GET['hotelmsn'] == 'N') {
	$hotelmsn = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Room Price was Inactivated successfully.
                 </div>';
	}

	if($_GET['hotelmsn'] == 'deleteprice') {
	$hotelmsn = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Room Price was Deleted successfully.
                 </div>';
	}
//########### END #############//

//manage_room.php Tab3 
	if($_GET['hotelmsn'] == 'addedprice') {
	$hotelmsn2 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Room Price was Added successfully.
                 </div>';
	}
//########### END #############//

//manage-hotel.php Tab2
	if($_GET['hotelmsn'] == 'newavailability') {
	$hotelmsn7 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The availability of the Room was Added successfully.
                 </div>';
	}
//########### END #############//

//manage-hotel.php Tab3
	if($_GET['hotelmsn'] == 'am0') {
	$hotelmsn3 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Amenity was Inactivated successfully.
                 </div>';
	}
	
	if($_GET['hotelmsn'] == 'deletedame') {
	$hotelmsn3 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Amenity was Deleted successfully.
                 </div>';
	}
	
	if($_GET['hotelmsn'] == 'am1') {
	$hotelmsn3 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Amenity was Activated successfully.
                 </div>';
	}
//########### END #############//

//add-hotel-amenity.php
	if($_GET['hotelmsn'] == 'addedamenity') {
	$hotelmsn = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Hotel Amenity was Added successfully.
                 </div>';
	}
//########### END #############//

//manage-hotel.php Tab4
	if($_GET['hotelmsn'] == 'p0') {
	$hotelmsn4 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Photo was Inactivated successfully.
                 </div>';
	}
	
	if($_GET['hotelmsn'] == 'p1') {
	$hotelmsn4 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Photo was Activated successfully.
                 </div>';
	}

	if($_GET['hotelmsn'] == 'deletedphoto') {
	$hotelmsn4 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Photo was Deleted successfully.
                 </div>';
	}
//########### END #############//

//manage-hotel.php Tab5
	if($_GET['hotelmsn'] == 'r0') {
	$hotelmsn5 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Review was Inactivated successfully.
                 </div>';
	}
	
	if($_GET['hotelmsn'] == 'r1') {
	$hotelmsn5 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Review was Activated successfully.
                 </div>';
	}
//########### END #############//

//manage-hotel.php Tab6
	if($_GET['hotelmsn'] == 'updateowner') {
	$hotelmsn6 = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The User was Added successfully.
                 </div>';
	}
//########### END #############//

	if($_GET['hotelmsn'] == 'addedseasonal') {
	$hotelmsn = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Seasonal Price was Added successfully.
                 </div>';
	}
	if($_GET['hotelmsn'] == 'updseasonal') {
	$hotelmsn = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Seasonal Price was Updated successfully.
                 </div>';
	}
	if($_GET['hotelmsn'] == 'deleteseasonal') {
	$hotelmsn = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Seasonal Price was Deleted successfully.
                 </div>';
	}
}
}

//Messages Sales: total-sales.php manage-transaction.php
$salemsn = '';
if($_GET) {
if(isset($_GET['salemsn'])) {

//manage-transaction.php		
	if($_GET['salemsn'] == 'updated') {
	$salemsn = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Transaction was Updated successfully.
                 </div>';
	}
//########### END #############//
}
}

//Messages Bookings: Bookings Pages manage-bookings.php
$bookingmsn = '';
if($_GET) {
if(isset($_GET['bookingmsn'])) {

//manage-transaction.php		
	if($_GET['bookingmsn'] == 'updated') {
	$bookingmsn = '<div class="alert alert-success">
					 <button type="button" class="close" data-dismiss="alert">×</button>
					 <strong>Well done!</strong>
					 The Booking was Updated successfully.
                 </div>';
	}
//########### END #############//
}
}

//Messages Appearance: customize.php
$customizemsn = '';
$customizemsn2 = '';
$customizemsn3 = '';
$customizemsn4 = '';
$customizemsn5 = '';
$customizemsn6 = '';
$customizemsn7 = '';
$customizemsn8 = '';
$customizemsn9 = '';
if($_GET) {
if(isset($_GET['customizemsn'])) {
	
//customize.php Logo Form
	if($_GET['customizemsn'] == 'updated') {
	$customizemsn = '<div class="alert alert-success">
						 <button type="button" class="close" data-dismiss="alert">×</button>
						 <strong>Well done!</strong>
						 The Logo was Updated successfully.
					 </div>';
	}
	
	if($_GET['customizemsn'] == 'error') {
	$errormsn = $_GET['errormsn'];
	$customizemsn = '<div class="alert alert-error">
						 <button type="button" class="close" data-dismiss="alert">×</button>
						 <strong>Oh snap!</strong>
						 '.$errormsn.'.
					 </div>';
	}
//########### END #############//

//customize.php Favicon Form
	if($_GET['customizemsn'] == 'updatedicon') {
	$customizemsn2 = '<div class="alert alert-success">
						 <button type="button" class="close" data-dismiss="alert">×</button>
						 <strong>Well done!</strong>
						 The Favicon was Updated successfully.
					 </div>';
	}
	
	if($_GET['customizemsn'] == 'erroricon') {
	$errormsn = $_GET['errormsn'];
	$customizemsn2 = '<div class="alert alert-error">
						 <button type="button" class="close" data-dismiss="alert">×</button>
						 <strong>Oh snap!</strong>
						 '.$errormsn.'.
					 </div>';
	}
//########### END #############//

//customize.php Page Form
	if($_GET['customizemsn'] == 'updatedset') {
	$customizemsn3 = '<div class="alert alert-success">
						 <button type="button" class="close" data-dismiss="alert">×</button>
						 <strong>Well done!</strong>
						 The Settings were Updated successfully.
					 </div>';
	}
//########### END #############//

//customize.php Home Banner Form
	if($_GET['customizemsn'] == 'updatedbanner') {
	$customizemsn9 = '<div class="alert alert-success">
						 <button type="button" class="close" data-dismiss="alert">×</button>
						 <strong>Well done!</strong>
						 The Banner was Updated successfully.
					 </div>';
	}
//########### END #############//

//customize.php Special Offer Form
	if($_GET['customizemsn'] == 'updatedoffer') {
	$customizemsn8 = '<div class="alert alert-success">
						 <button type="button" class="close" data-dismiss="alert">×</button>
						 <strong>Well done!</strong>
						 The Offer was Updated successfully.
					 </div>';
	}
//########### END #############//

//customize.php Slides Form
	if($_GET['customizemsn'] == 'updatedslide') {
	$customizemsn4 = '<div class="alert alert-success">
						 <button type="button" class="close" data-dismiss="alert">×</button>
						 <strong>Well done!</strong>
						 The Hot Deal was Updated successfully.
					 </div>';
	}
	
	if($_GET['customizemsn'] == 'updatedslide2') {
	$customizemsn5 = '<div class="alert alert-success">
						 <button type="button" class="close" data-dismiss="alert">×</button>
						 <strong>Well done!</strong>
						 The Hot Deal 2 was Updated successfully.
					 </div>';
	}
	
	if($_GET['customizemsn'] == 'updatedslide3') {
	$customizemsn6 = '<div class="alert alert-success">
						 <button type="button" class="close" data-dismiss="alert">×</button>
						 <strong>Well done!</strong>
						 The Hot Deal 3 was Updated successfully.
					 </div>';
	}
	
	if($_GET['customizemsn'] == 'updatedslide4') {
	$customizemsn7 = '<div class="alert alert-success">
						 <button type="button" class="close" data-dismiss="alert">×</button>
						 <strong>Well done!</strong>
						 The Hot Deal 4 was Updated successfully.
					 </div>';
	}
//########### END #############//

//manage-page.php Form
	if($_GET['customizemsn'] == 'updatepage') {
	$customizemsn = '<div class="alert alert-success">
						 <button type="button" class="close" data-dismiss="alert">×</button>
						 <strong>Well done!</strong>
						 The Page was Updated successfully.
					 </div>';
	}
//########### END #############//
}
}

//Messages Email Template: mailerconfig.php, manage-email.php
$emailtemplatemsn = '';
$emailtemplatemsn2 = '';
$emailtemplatemsn3 = '';
$emailtemplatemsn4 = '';
if($_GET) {
if(isset($_GET['emailtemplatemsn'])) {
	
//mailerconfig.php Tab 1
	if($_GET['emailtemplatemsn'] == 'update1') {
	$emailtemplatemsn = '<div class="alert alert-success">
						 <button type="button" class="close" data-dismiss="alert">×</button>
						 <strong>Well done!</strong>
						 Default Emails were Updated successfully.
					 </div>';
	}
	
	if($_GET['emailtemplatemsn'] == 'update2') {
	$emailtemplatemsn2 = '<div class="alert alert-success">
						 <button type="button" class="close" data-dismiss="alert">×</button>
						 <strong>Well done!</strong>
						 Email Templates were Updated successfully.
					 </div>';
	}
//########### END #############//

//mailerconfig.php Tab 2	
	if($_GET['emailtemplatemsn'] == '1') {
	$emailtemplatemsn3 = '<div class="alert alert-success">
						 <button type="button" class="close" data-dismiss="alert">×</button>
						 <strong>Well done!</strong>
						 The Email was Activated successfully.
					 </div>';
	}
	
	if($_GET['emailtemplatemsn'] == '0') {
	$emailtemplatemsn3 = '<div class="alert alert-success">
						 <button type="button" class="close" data-dismiss="alert">×</button>
						 <strong>Well done!</strong>
						 The Email was Inactivated successfully.
					 </div>';
	}
//########### END #############//

//manage-email.php Email Form	
	if($_GET['emailtemplatemsn'] == 'emailupdate') {
	$emailtemplatemsn4 = '<div class="alert alert-success">
						 <button type="button" class="close" data-dismiss="alert">×</button>
						 <strong>Well done!</strong>
						 The Email was Updated successfully.
					 </div>';
	}
//########### END #############//

//mailerconfig.php Tab 3	
	if($_GET['emailtemplatemsn'] == 'added') {
	$emailtemplatemsn4 = '<div class="alert alert-success">
						 <button type="button" class="close" data-dismiss="alert">×</button>
						 <strong>Well done!</strong>
						 The Email was Added successfully.
					 </div>';
	}
//########### END #############//
}
}

//Messages Payment Gateway: payment-gat.php
$gatewaymsn = '';
$gatewaymsn2 = '';
if($_GET) {
if(isset($_GET['gatewaymsn'])) {
	
//payment-gat.php Form Gateway
	if($_GET['gatewaymsn'] == '1') {
	$gatewaymsn = '<div class="alert alert-success">
						 <button type="button" class="close" data-dismiss="alert">×</button>
						 <strong>Well done!</strong>
						 Payment Gateways was Updated successfully.
					 </div>';
	}
//########### END #############//

//payment-gat.php Form Paypal Gateway
	if($_GET['gatewaymsn'] == '2') {
	$gatewaymsn2 = '<div class="alert alert-success">
						 <button type="button" class="close" data-dismiss="alert">×</button>
						 <strong>Well done!</strong>
						 Paypal Settings were Updated successfully.
					 </div>';
	}
//########### END #############//
}
}
?>