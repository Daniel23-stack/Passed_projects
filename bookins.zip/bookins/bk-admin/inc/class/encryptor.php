<?php
//Define your Key and Salt
$keys = $securitykey;
$salt = $securitysalt;

interface ICrypter{
	public function __construct($Key, $CRYPTBLOW = MCRYPT_BLOWFISH);
	public function Encrypt($data);
	public function Decrypt($data);
}

class Encryptor implements ICrypter{
	private $Key;
	private $CRYPTBLOW;

	public function __construct($Key, $CRYPTBLOW = MCRYPT_BLOWFISH){
		$this->Key = substr($Key, 0, mcrypt_get_key_size($CRYPTBLOW, MCRYPT_MODE_CBC));
		$this->CRYPTBLOW = $CRYPTBLOW;
		$this->keypass = 'EGHY&*IOEFG456'; //Add your own key
		$this->salt = 'h!u@n#z$o%n^i&a*n'; // Add your own salt
	}

	public function Encrypt($data){
		if(!$data){
			return false;
		}
		
		$iv_size = mcrypt_get_iv_size($this->CRYPTBLOW, MCRYPT_MODE_CBC);
		$iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
		$ivcr = md5($iv);
		$keypass = $this->keypass;
		$salt = $this->salt;
		$privatekey = sha1($keypass.$salt);
		$hash = $privatekey;
		
		$crypt = mcrypt_encrypt($this->CRYPTBLOW, md5($this->Key.$hash), $data, MCRYPT_MODE_ECB, $ivcr);
		return strtr(base64_encode($crypt), '+/', '-_');
	}
	
	public function Decrypt($data){
		if(!$data){
			return false;
		}
		
		$crypt = base64_decode(strtr($data, '-_', '+/'));
		
		$iv_size = mcrypt_get_iv_size($this->CRYPTBLOW, MCRYPT_MODE_CBC);
		$iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
		$ivcr = md5($iv);
		$keypass = $this->keypass;
		$salt = $this->salt;
		$privatekey = sha1($keypass.$salt);
		$hash = $privatekey;
		
		$decrypt = mcrypt_decrypt($this->CRYPTBLOW, md5($this->Key.$hash), $crypt, MCRYPT_MODE_ECB, $ivcr);
		return trim($decrypt);
	
	}
}

//Creating a new instance of the Encryption with RIJNDAEL_256 encryption
$password = sha1($keys.$salt);
$encryptor = new Encryptor($password, MCRYPT_RIJNDAEL_256);
?>