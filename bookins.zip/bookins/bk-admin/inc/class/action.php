<?php
// ------------------------------------------------------------
// WHEN THE FORM IS SUBMITTED
// ------------------------------------------------------------
$encrypted = '';
$decrypted = '';
//Encrypt Process
if(isset($_POST['gencode']))
{
	
	$securitykey = $_POST['securitykey'];
	$securitysalt = $_POST['securitysalt'];
	$textcrypt = $_POST['textcrypt'];

include('inc/class/encryptor.php');

//Your Data to Encrypt
$data = $textcrypt;

//Encrypt the Data
	$encrypted = $encryptor->Encrypt($data);
}

//Decrypt Process
if(isset($_POST['decode']))
{
	
	$securitykey = $_POST['securitykey'];
	$securitysalt = $_POST['securitysalt'];
	$textdecrypt = $_POST['textdecrypt'];

include('inc/class/encryptor.php');

//Your Data to Encrypt
$data = $textdecrypt;

//Decrypt the Data
	$decrypted = $encryptor->Decrypt($data);
}
?>