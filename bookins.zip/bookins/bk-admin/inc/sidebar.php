		    <div class="shortcuts">
                <ul>
                    <li><a href="http://codecanyon.net/user/bookingo" title="Support section" class="tip"><span class="icon24 icomoon-icon-support"></span></a></li>
                    <li><a href="total-sales.php" title="Total Sales" class="tip"><span class="icon24 icomoon-icon-coin"></span></a></li>
                    <li><a href="bookings-actives.php" title="Bookings" class="tip"><span class="icon24 icomoon-icon-stopwatch"></span></a></li>
                     <?php if($user->isAdmin()) { ?>
                    <li><a href="customize.php" title="Appearance" class="tip"><span class="icon24 icomoon-icon-images"></span></a></li>
                    <?php } ?>
                </ul>
            </div><!-- End Icons -->            

            <div class="sidenav">

                <div class="sidebar-widget" style="margin: -1px 0 0 0;">
                    <h5 class="title" style="margin-bottom:0">Navigation</h5>
                </div><!-- End .sidenav-widget -->

                <div class="mainnav">
                    <ul>
                        <?php if($user->isAdmin()) { ?>
                        <li>
                            <a href="#"><span class="icon16 icomoon-icon-office"></span>Administration</a>
                            <ul class="sub <?php if ($nav == 'microsite' || $nav == 'hotels') echo 'expand'; ?>">
                            	<li><a href="microsite.php" <?php if ($nav == 'microsite') echo 'class="current"'; ?>><span class="icon16 icomoon-icon-certificate"></span>Inventories</a></li>
                                <li><a href="cities.php"><span class="icon16 icomoon-icon-earth"></span>Cities</a></li>
                                <li><a href="hotels.php" <?php if ($nav == 'hotels') echo 'class="current"'; ?>><span class="icon16 icomoon-icon-bed"></span>Hotels</a></li>
                            </ul>
                        </li>
                        <?php } ?>
                        
                        <?php if($_SESSION['roleuser'] == 4) { ?>
                        <li>
                            <a href="#"><span class="icon16 icomoon-icon-office"></span>Administration</a>
                            <ul class="sub <?php if ($nav == 'microsite' || $nav == 'hotels') echo 'expand'; ?>">                            	
                                <li><a href="hotels.php" <?php if ($nav == 'hotels') echo 'class="current"'; ?>><span class="icon16 icomoon-icon-bed"></span>Hotels</a></li>
                            </ul>
                        </li>
                        <?php } ?>
                        
                        <li>
                            <a href="#"><span class="icon16 icomoon-icon-tag-5"></span>Sales</a>
                            <ul class="sub <?php if ($nav == 'transactions') echo 'expand'; ?>">
                            	<li><a href="total-sales.php"><span class="icon16 icomoon-icon-cart-3"></span>Total Sales</a></li>
                                <li><a href="transactions.php" <?php if ($nav == 'transactions') echo 'class="current"'; ?>><span class="icon16 icomoon-icon-credit"></span>Transactions</a></li>
                            </ul>
                        </li>
                        
                        <li>
                            <a href="#"><span class="icon16 icomoon-icon-calendar"></span>Bookings</a>
                            <ul class="sub <?php if ($nav == 'booking-act' || $nav == 'pending-status' || $nav == 'records' || $nav == 'cancelled') echo 'expand'; ?>">
                            	<li><a href="bookings-actives.php" <?php if ($nav == 'booking-act') echo 'class="current"'; ?>><span class="icon16 icomoon-icon-foursquare-2"></span>Active</a></li>
                                <li><a href="bookings-pending.php" <?php if ($nav == 'pending-status') echo 'class="current"'; ?>><span class="icon16 icomoon-icon-warning"></span>Pending Status</a></li>
                                <li><a href="bookings-records.php" <?php if ($nav == 'records') echo 'class="current"'; ?>><span class="icon16 icomoon-icon-stack"></span>Record</a></li>
                                <li><a href="bookings-cancelled.php" <?php if ($nav == 'cancelled') echo 'class="current"'; ?>><span class="icon16 icomoon-icon-cancel-circle"></span>Cancelled</a></li>
                            </ul>
                        </li>
                        
                        <?php if($user->isAdmin()) { ?>
                        <li>
                            <a href="#"><span class="icon16 icomoon-icon-cog"></span>Settings</a>
                            <ul class="sub <?php if ($nav == 'settings' || $nav == 'email-template') echo 'expand'; ?>">
                            	<li><a href="add_user.php"><span class="icon16 icomoon-icon-user-plus"></span>Add User</a></li>
                                <li><a href="users.php"><span class="icon16 icomoon-icon-users"></span>Users</a></li>
                                <li><a href="user_roles.php"><span class="icon16 icomoon-icon-vcard"></span>User Roles</a></li>
                                <li><a href="customize.php" <?php if ($nav == 'settings') echo 'class="current"'; ?>><span class="icon16 icomoon-icon-paint-format"></span>Appearance</a></li>
                                <li><a href="mailerconfig.php" <?php if ($nav == 'email-template') echo 'class="current"'; ?>><span class="icon16 icomoon-icon-envelop"></span>Email Template</a></li>
                                <li><a href="encryptor.php"><span class="icon16 icomoon-icon-shield-2"></span>Decrypt Email Data</a></li>
                                <li><a href="payment-gat.php"><span class="icon16 icomoon-icon-coin"></span>Payment Gateway</a></li>
                            </ul>
                        </li>
                        <?php } ?>
                    </ul>
                </div>
            </div><!-- End sidenav -->