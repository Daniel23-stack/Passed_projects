<?php

if($hotel_country == 'US') { 
//States
$hotelstate = mysqli_query($conn, "SELECT name, abbrev, country FROM states WHERE country = 'US' ORDER by name ASC");
mysqli_close($conn);
?>

<div class="control-group form-row row-fluid">
  <div class="span12">
    <div class="row-fluid">
      <label class="form-label span3">State</label>
      <div class="span4 controls">
        <select name="hotel_state">
          <option value=''>Select...</option>
          <?php
			while ($hotelstateData = mysqli_fetch_array($hotelstate, MYSQL_ASSOC))
			if($hotelstateData['abbrev'] == $hotel_state) {
			echo "<option value='$hotelstateData[abbrev]' selected='selected'>$hotelstateData[name]</option>";
			} 
			else {
				echo "<option value='$hotelstateData[abbrev]'>$hotelstateData[name]</option>";
			} mysqli_free_result($hotelstate); 
		  ?>
        </select>
      </div>
    </div>
  </div>
</div>

<?php } elseif($hotel_country == 'CA') { 
//States
$hotelstate = mysqli_query($conn, "SELECT name, abbrev, country FROM states WHERE country = 'CA' ORDER by name ASC");
mysqli_close($conn);
?>

<div class="control-group form-row row-fluid">
  <div class="span12">
    <div class="row-fluid">
      <label class="form-label span3">State</label>
      <div class="span4 controls">
        <select name="hotel_state">
          <option value=''>Select...</option>
          <?php
			while ($hotelstateData = mysqli_fetch_array($hotelstate, MYSQL_ASSOC))
			if($hotelstateData['abbrev'] == $hotel_state) {
			echo "<option value='$hotelstateData[abbrev]' selected='selected'>$hotelstateData[name]</option>";
			} 
			else {
				echo "<option value='$hotelstateData[abbrev]'>$hotelstateData[name]</option>";
			} mysqli_free_result($hotelstate); 
		  ?>
        </select>
      </div>
    </div>
  </div>
</div>

<?php } else { ?>
<div class="control-group form-row row-fluid">
  <div class="span12">
    <div class="row-fluid">
      <label class="form-label span3">State</label>
      <div class="span4 controls">
        <select name="hotel_state">
          <option value=''>None</option>
        </select>
      </div>
    </div>
  </div>
</div>
<?php } ?>