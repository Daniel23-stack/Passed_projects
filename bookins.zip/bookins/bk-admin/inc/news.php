					<div class="row-fluid">		
                        <div class="span12">

                            <div class="hero-unit">
                               <h1><?php echo $customnewsData['news_title']; ?></h1>
                               <p><?php echo $customnewsData['news_description']; ?></p>
                               <p><a href="<?php echo $customnewsData['news_link']; ?>" class="btn btn-primary btn-large">Learn more</a></p>
                            </div>

                        </div><!-- End .span6 -->
					</div>