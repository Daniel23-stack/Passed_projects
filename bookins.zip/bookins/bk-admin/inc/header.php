		  <div class="navbar">
            <div class="navbar-inner">
              <div class="container-fluid">
                <a class="brand" href="./"><img src="images/logo.png" /></a>
                <div class="nav-no-collapse">
                   <ul class="nav">
                        <li <?php if($nav == 'dashboard') { echo 'class="active"'; } ?>><a href="./"><span class="icon16 icomoon-icon-screen-2"></span> <span class="txt">Dashboard</span></a></li>
                   </ul>
                   <ul class="nav pull-right usernav">
                        <li>
                            <a href="profile.php" class="dropdown-toggle avatar" >
                                <img src="images/avatar.jpg" alt="" class="image" /> 
                                <span class="txt"><?php echo $userInfo['username'];  ?></span>
                            </a>                            
                        </li>
                        <li><a href="javascript:void(0);" id="logout"><span class="icon16 icomoon-icon-exit"></span><span class="txt"> Logout</span></a></li>
                    </ul>
                </div><!-- /.nav-collapse -->
              </div>
            </div><!-- /navbar-inner -->
          </div>