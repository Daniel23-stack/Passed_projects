<h1>Please use PHP 5.3</h1></br>
If you are using Hostgator add this to your .htaccess:<br>
<p>Action application/x-hg-php53 /cgi-sys/php53<br>
AddHandler application/x-hg-php53 .php</p>