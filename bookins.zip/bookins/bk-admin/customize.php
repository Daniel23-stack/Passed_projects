<?php
include 'ASEngine/AS.php';
if(!$login->isLoggedIn())
    header("Location: login.php");
$user = new ASUser(ASSession::get("user_id"));
$userInfo = $user->getInfo();

//basic include files
require_once("../db.php");

$nav = '';

//Messages
include 'inc/messages.php';

//Current Tab Active
	$label1 = '';
	$tab1 = '';
	$label2 = '';
	$tab2 = '';
if(isset($_GET['tab'])) {
	if($_GET['tab'] == '2') {
	$label2 = 'class="active"';
	$tab2 = 'in active';
	}
} else {
	$label1 = 'class="active"';
	$tab1 = 'in active';
}

//DB DATA
$csslist = mysqli_query($conn, "SELECT * from css_list");
$css_textures = mysqli_query($conn, "SELECT * from css_textures");
$page_list = mysqli_query($conn, "SELECT * from page_settings");
$general_settings = mysqli_query($conn, "SELECT * FROM general_settings WHERE settings_id = 1");
$settings_total = mysqli_num_rows($general_settings);
$settings_Data = mysqli_fetch_array($general_settings);

//Variables
	$settings_id = $settings_Data['settings_id'];
	$settings_logo = $settings_Data['settings_logo'];
	$settings_icon = $settings_Data['settings_icon'];
	$settings_css = $settings_Data['settings_css'];
	$settings_css_texture = $settings_Data['settings_css_texture'];
	$settings_phone = $settings_Data['settings_phone'];
	$settings_script = $settings_Data['settings_script'];
	$settings_copyright = $settings_Data['settings_copyright'];
	$settings_twitter = $settings_Data['settings_twitter'];
	$settings_facebook = $settings_Data['settings_facebook'];
	$settings_google = $settings_Data['settings_google'];
	$settings_email = $settings_Data['settings_email'];
	$settings_from_mail = $settings_Data['settings_from_mail'];
	$settings_banner = $settings_Data['settings_banner'];
	$settings_banner_title = $settings_Data['settings_banner_title'];
	$settings_banner_txt = $settings_Data['settings_banner_txt'];
	$special_offer = $settings_Data['special_offer'];
	$special_offer_txt = $settings_Data['special_offer_txt'];
	$settings_slide1 = $settings_Data['settings_slide1'];
	$settings_slide1_link = $settings_Data['settings_slide1_link'];
	$settings_slide2 = $settings_Data['settings_slide2'];
	$settings_slide2_link = $settings_Data['settings_slide2_link'];
	$settings_slide3 = $settings_Data['settings_slide3'];
	$settings_slide3_link = $settings_Data['settings_slide3_link'];
	$settings_slide4 = $settings_Data['settings_slide4'];
	$settings_slide4_link = $settings_Data['settings_slide4_link'];
	$settings_map = $settings_Data['settings_map'];

//Datos Inventario City
$inventory = mysqli_query($conn, "SELECT inve_code FROM inventory WHERE inve_active = 1");
$inventory_Data = mysqli_fetch_array($inventory);
//Variables
$inve_code = $inventory_Data['inve_code'];

//Datos City
$inventory_city = mysqli_query($conn, "SELECT inventory_id, element_name FROM approved_inventory WHERE element_type = 2 AND microsite_inventory_code = '$inve_code'");

mysqli_close($conn);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo WEBSITE_NAME; ?></title>
    <meta name="author" content="Bookingo" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="application-name" content="Bookingo" />

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- Force IE9 to render in normla mode -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- Le styles -->
    <!-- Use new way for google web fonts 
    http://www.smashingmagazine.com/2012/07/11/avoiding-faux-weights-styles-google-web-fonts -->
    <!-- Headings -->
    <!-- <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css' />  -->
    <!-- Text -->
    <!-- <link href='http://fonts.googleapis.com/css?family=Droid+Sans:400,700' rel='stylesheet' type='text/css' /> --> 
    <!--[if lt IE 9]>
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:700" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=Droid+Sans:400" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=Droid+Sans:700" rel="stylesheet" type="text/css" />
    <![endif]-->

    <!-- Core stylesheets do not remove -->
    <link id="bootstrap" href="<?php echo SITE_URL; ?>css/bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link id="bootstrap-responsive" href="<?php echo SITE_URL; ?>css/bootstrap/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo SITE_URL; ?>css/supr-theme/jquery.ui.supr.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo SITE_URL; ?>css/icons.css" rel="stylesheet" type="text/css" />

    <!-- Plugin stylesheets -->
    <link href="<?php echo SITE_URL; ?>plugins/misc/qtip/jquery.qtip.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo SITE_URL; ?>plugins/forms/uniform/uniform.default.css" type="text/css" rel="stylesheet" />        
    <link href="<?php echo SITE_URL; ?>plugins/tables/dataTables/jquery.dataTables.css" type="text/css" rel="stylesheet" />
    <link href="<?php echo SITE_URL; ?>plugins/tables/dataTables/TableTools.css" type="text/css" rel="stylesheet" />

    <!-- Main stylesheets -->
    <link href="<?php echo SITE_URL; ?>css/main.css" rel="stylesheet" type="text/css" /> 

    <!-- Custom stylesheets ( Put your own changes here ) -->
    <link href="<?php echo SITE_URL; ?>css/custom.css" rel="stylesheet" type="text/css" /> 

    <!--[if IE 8]><link href="css/ie8.css" rel="stylesheet" type="text/css" /><![endif]-->

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script type="text/javascript" src="js/libs/excanvas.min.js"></script>
      <script type="text/javascript" src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <script type="text/javascript" src="js/libs/respond.min.js"></script>
    <![endif]-->

    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="<?php echo SITE_URL; ?>images/favicon.ico" />
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo SITE_URL; ?>images/apple-touch-icon-144-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo SITE_URL; ?>images/apple-touch-icon-114-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo SITE_URL; ?>images/apple-touch-icon-72-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" href="<?php echo SITE_URL; ?>images/apple-touch-icon-57-precomposed.png" />
    
    <!-- Windows8 touch icon ( http://www.buildmypinnedsite.com/ )-->
    <meta name="msapplication-TileColor" content="#3399cc"/> 

    <!-- Load modernizr first -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/libs/modernizr.js"></script>
	
    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
    <![endif]-->
    
    </head>
      
    <body>
    <!-- loading animation -->
    <div id="qLoverlay"></div>
    <div id="qLbar"></div>
    
    <div id="header" class="fixed">

        <?php include 'inc/header.php'; ?><!-- /navbar --> 

    </div><!-- End #header -->

    <div id="wrapper">

        <!--Responsive navigation button-->  
        <div class="resBtn">
            <a href="#"><span class="icon16 minia-icon-list-3"></span></a>
        </div>
        
        <!--Sidebar collapse button-->  
        <div class="collapseBtn leftbar">
             <a href="#" class="tipR" title="Hide sidebar"><span class="icon12 minia-icon-layout"></span></a>
        </div>

        <!--Sidebar background-->
        <div id="sidebarbg"></div>
        <!--Sidebar content-->
        <div id="sidebar">
			<?php include 'inc/sidebar.php'; ?><!-- /sidebar -->
        </div><!-- End #sidebar -->

        <!--Body content-->
        <div id="content" class="clearfix">
            <div class="contentwrapper"><!--Content wrapper-->

                <div class="heading">
				<!--Content Title-->
                    <h3>Site Administration</h3>                    

                    <div class="resBtnSearch">
                        <a href="#"><span class="icon16 icomoon-icon-search-3"></span></a>
                    </div>

                    <ul class="breadcrumb">
                        <li>
                            <a href="./" class="tip" title="back to dashboard">
                                <span class="icon16 icomoon-icon-screen-2"></span>
                            </a> 
                            <span class="divider">
                                <span class="icon16 icomoon-icon-arrow-right-3"></span>
                            </span>
                        </li>
                        <li class="active"><a href="javascript: history.go(-1)">Go Back</a></li>
                    </ul>

                </div><!-- End .heading-->


                 <!-- Build page from here: -->
                <div class="row-fluid">
					
                    <div class="span12">
                            <div class="page-header">
                                <h4>Appearance</h4>
                            </div>
                            <div style="margin-bottom: 20px;">
                                <ul id="myTab" class="nav nav-tabs pattern">
                                    <li <?php echo $label1; ?>><a href="#tab1" data-toggle="tab">General Settings</a></li>
                                    <li <?php echo $label2; ?>><a href="#tab2" data-toggle="tab">Page Settings</a></li>
                                </ul>

                                <div class="tab-content">
                                    <!-- Start Tab1 -->
                                    <div class="tab-pane fade <?php echo $tab1; ?>" id="tab1">
										
					<div class="row-fluid">
                        <div class="span3">
                        	<div class="content">
                               <?php echo $customizemsn; ?>
                               <form action="transql/upds/update-logo.php" method="post" name="image_upload" id="image_upload" enctype="multipart/form-data" class="form-horizontal">
                                <div class="form-row row-fluid">
                                	<div class="span12">
                                    	<div class="row-fluid">
                                            <img src="../inc/images/<?php echo $settings_logo; ?>" alt="" class="image marginR10"/>
                                            <input type="file" name="image" id="file" />
                                        </div>
                                        <span class="help-block blue span8">Page Logo 300x47px</span>
                                    </div>
                                </div>
                                
                                <br />
                                	<button type="submit" class="btn btn-primary">Submit</button>
                               </form>
                            </div>
                        </div><!-- End .span3 -->

                        <div class="span3">
                        	<div class="content">
                            <?php echo $customizemsn2; ?>
                               <form action="transql/upds/update-favicon.php" method="post" name="image_upload" id="image_upload" enctype="multipart/form-data" class="form-horizontal">
                                <div class="form-row row-fluid">
                                	<div class="span12">
                                    	<div class="row-fluid">
                                            <img src="../inc/images/<?php echo $settings_icon; ?>" alt="" class="image marginR10"/>
                                            <input type="file" name="favicon" id="file" />
                                        </div>
                                        <span class="help-block blue span8">Page favicon</span>
                                    </div>
                                </div>
                                
                                <br />
                                	<button type="submit" class="btn btn-primary">Submit</button>
                               </form>
                            </div>
                        </div><!-- End .span3 -->

                        

                    </div><!-- End .row-fluid -->
                    
                    <!-- Build page from here: -->
                <div class="row-fluid">
					
                    <div class="span12">
						<?php echo $customizemsn3; ?>
									
							<form action="transql/upds/update-settings.php" method="post" class="form-horizontal">
                                             
                            <div class="control-group form-row row-fluid">
                              <div class="span12">
                                <div class="row-fluid">
                                  <label class="form-label span3">Page CSS</label>
                                  <div class="span4 controls">
                                    <select name="settings_css">
                                      <option value=''>Select...</option>
                                        <?php			  	  	                 
											while ($csslist_Data = mysqli_fetch_array($csslist, MYSQL_ASSOC))
											  if($csslist_Data['css_link'] == $settings_css) {
												echo "<option value='$csslist_Data[css_link]' selected='selected'>$csslist_Data[css_name]</option>";
											  } 
											  else {
												echo "<option value='$csslist_Data[css_link]'>$csslist_Data[css_name]</option>";
											  }
											  mysqli_free_result($csslist);
										?>
                                    </select>
                                  </div>
                                </div>
                              </div>
                            </div>
                            
                            <div class="control-group form-row row-fluid">
                              <div class="span12">
                                <div class="row-fluid">
                                  <label class="form-label span3">Header & Footer Texture</label>
                                  <div class="span4 controls">
                                    <select name="settings_css_texture">
                                      <option value='none'>None</option>
                                        <?php			  	  	                 
											while ($css_textures_Data = mysqli_fetch_array($css_textures, MYSQL_ASSOC))
											  if($css_textures_Data['texture_link'] == $settings_css_texture) {
												echo "<option value='$css_textures_Data[texture_link]' selected='selected'>$css_textures_Data[texture_name]</option>";
											  } 
											  else {
												echo "<option value='$css_textures_Data[texture_link]'>$css_textures_Data[texture_name]</option>";
											  }
											  mysqli_free_result($css_textures);
										?>
                                    </select>
                                  </div>
                                </div>
                              </div>
                            </div>
                            
                            <div class="form-row row-fluid">
                              <div class="span12">
                                <div class="row-fluid">
                                  <label class="form-label span3">Page Phone</label>
                                  <input class="span4" type="text" name="settings_phone" value="<?php echo $settings_phone; ?>" />
                                </div>
                              </div>
                            </div>
                            
                            <div class="form-row row-fluid">
                              <div class="span12">
                                <div class="row-fluid">
                                  <label class="form-label span3">Page Custom Javascript</label>
                                  <textarea class="span4 elastic" id="textarea2" rows="3" cols="5" name="settings_script"><?php echo $settings_script; ?></textarea>
                                </div>
                              </div>
                            </div>
                            
                            <div class="form-row row-fluid">
                              <div class="span12">
                                <div class="row-fluid">
                                  <label class="form-label span3">Page Copyright</label>
                                  <input class="span4" type="text" name="settings_copyright" value="<?php echo $settings_copyright; ?>" />
                                </div>
                              </div>
                            </div>
                            
                            <div class="form-row row-fluid">
                              <div class="span12">
                                <div class="row-fluid">
                                  <label class="form-label span3">Page Twitter URL</label>
                                  <input class="span4" type="text" name="settings_twitter" value="<?php echo $settings_twitter; ?>" />
                                </div>
                              </div>
                            </div>
                            
                            <div class="form-row row-fluid">
                              <div class="span12">
                                <div class="row-fluid">
                                  <label class="form-label span3">Page Facebook URL</label>
                                  <input class="span4" type="text" name="settings_facebook" value="<?php echo $settings_facebook; ?>" />
                                </div>
                              </div>
                            </div>
                            
                            <div class="form-row row-fluid">
                              <div class="span12">
                                <div class="row-fluid">
                                  <label class="form-label span3">Page Google+ URL</label>
                                  <input class="span4" type="text" name="settings_google" value="<?php echo $settings_google; ?>" />
                                </div>
                              </div>
                            </div>
                            
                            <div class="form-row row-fluid">
                              <div class="span12">
                                <div class="row-fluid">
                                  <label class="form-label span3">Page Email</label>
                                  <input class="span4" type="text" name="settings_email" value="<?php echo $settings_email; ?>" />
                                  <span class="help-block blue span8">for multiple address separate it by (<span style="color:#F00">,</span>)</span>
                                </div>
                              </div>
                            </div>
                            
                            <div class="form-row row-fluid">
                              <div class="span12">
                                <div class="row-fluid">
                                  <label class="form-label span3">Page from email</label>
                                  <input class="span4" type="text" name="settings_from_mail" value="<?php echo $settings_from_mail; ?>" />
                                  <span class="help-block blue span8">Default From email address for contact us</span>
                                </div>
                              </div>
                            </div>
                            
                            <div class="control-group form-row row-fluid">        
                                <div class="span12">
                                    <div class="row-fluid">
                                        <div class="form-actions">
                                        <div class="span3"></div>
                                        <div class="span4">
                                            <button type="submit" class="btn btn-primary marginR10">Submit</button>
                                        </div>
                                        </div>
                                    </div>
                                </div>   
                            </div>
                                        </form>
                                    <?php mysqli_free_result($general_settings); ?>    
                                    
                        </div><!-- End .span6 -->
                    
                </div><!-- End .row-fluid -->
                
                <div class="row-fluid">

                        <div class="span12">
                        	<div class="content">
                               <?php echo $customizemsn9; ?>
                               <form action="transql/upds/update-banner.php" method="post" name="image_upload" id="image_upload" enctype="multipart/form-data" class="form-horizontal">
                                <h4>Home Banner</h4>
                                	<p class="help-block">Title:</p>
                                	<input class="span4 limit50" type="text" name="banner_title" value="<?php echo $settings_banner_title; ?>" /><br /><br />
                                    <p class="help-block">Text:</p>
                                	<input class="span4 limit100" type="text" name="banner_txt" value="<?php echo $settings_banner_txt; ?>" />
                                <div class="form-row row-fluid">
                                	<div class="span12">
                                    	<div class="row-fluid">
                                            <img src="../inc/images/carousel/<?php echo $settings_banner; ?>" alt="" class="image marginR10" style="height:200px;" />
                                            <input type="file" name="image" id="file" />
                                        </div>
                                        <span class="help-block blue span8">Default slide size: 1170x596px</span>
                                    </div>
                                </div>
                                
                                <br />
                                	<div class="control-group form-row row-fluid">        
                                <div class="span12">
                                    <div class="row-fluid">
                                        <div class="form-actions">
                                        	<div class="span3"></div>
                                        	<div class="span4">
                                            	<button type="submit" class="btn btn-primary marginR10" name="offer" value="offer">Submit</button>
                                        	</div>
                                        </div>
                                    </div>
                                </div>   
                            	
                                </div>
                               </form>
                            </div>
                        </div><!-- End .span3 -->
                </div>
                
                <div class="row-fluid">

                        <div class="span12">
                        	<div class="content">
                               <?php echo $customizemsn8; ?>
                               <form action="transql/upds/update-offer.php" method="post" name="image_upload" id="image_upload" enctype="multipart/form-data" class="form-horizontal">
                                <h4>Special Offer</h4>
                                	<p class="help-block">Text:</p>
                                	<input class="span4 limit30" type="text" name="offer_txt" value="<?php echo $special_offer_txt; ?>" />
                                <div class="form-row row-fluid">
                                	<div class="span12">
                                    	<div class="row-fluid">
                                            <img src="../inc/images/carousel/<?php echo $special_offer; ?>" alt="" class="image marginR10"/>
                                            <input type="file" name="image" id="file" />
                                        </div>
                                        <span class="help-block blue span8">Default slide size: 438x246px</span>
                                    </div>
                                </div>
                                
                                <br />
                                	<div class="control-group form-row row-fluid">        
                                <div class="span12">
                                    <div class="row-fluid">
                                        <div class="form-actions">
                                        	<div class="span3"></div>
                                        	<div class="span4">
                                            	<button type="submit" class="btn btn-primary marginR10" name="offer" value="offer">Submit</button>
                                        	</div>
                                        </div>
                                    </div>
                                </div>   
                            	
                                </div>
                               </form>
                            </div>
                        </div><!-- End .span3 -->
                </div>
                
                <div class="row-fluid">

                        <div class="span3">
                        	<div class="content">
                               <?php echo $customizemsn4; ?>
                               <form action="transql/upds/update-slide.php" method="post" name="image_upload" id="image_upload" enctype="multipart/form-data" class="form-horizontal">
                                <h4>Home Hot Deal 1</h4>
                                	<p class="help-block">Link for Hot Deal:</p>
                                	<input class="span10" type="text" name="slide_link" value="<?php echo $settings_slide1_link; ?>" />
                                <div class="form-row row-fluid">
                                	<div class="span12">
                                    	<div class="row-fluid">
                                            <img src="../inc/images/carousel/<?php echo $settings_slide1; ?>" alt="" class="image marginR10"/>
                                            <input type="file" name="image" id="file" />
                                        </div>
                                        <span class="help-block blue span8">Default image size: 189x142px</span>
                                    </div>
                                </div>
                                
                                <br />
                                	<button type="submit" class="btn btn-primary" name="slide1" value="slide1">Submit</button>
                               </form>
                            </div>
                        </div><!-- End .span3 -->

                        <div class="span3">
                        	<div class="content">
                               <?php echo $customizemsn5; ?>
                               <form action="transql/upds/update-slide.php" method="post" name="image_upload" id="image_upload" enctype="multipart/form-data" class="form-horizontal">
                                <h4>Home Hot Deal 2</h4>
                                	<p class="help-block">Link for Hot Deal:</p>
                                	<input class="span10" type="text" name="slide_link" value="<?php echo $settings_slide2_link; ?>" />
                                <div class="form-row row-fluid">
                                	<div class="span12">
                                    	<div class="row-fluid">
                                            <img src="../inc/images/carousel/<?php echo $settings_slide2; ?>" alt="" class="image marginR10"/>
                                            <input type="file" name="image" id="file" />
                                        </div>
                                        <span class="help-block blue span8">Default image size: 189x142px</span>
                                    </div>
                                </div>
                                
                                <br />
                                	<button type="submit" class="btn btn-primary" name="slide2" value="slide2">Submit</button>
                               </form>
                            </div>
                        </div><!-- End .span3 -->
                        
                        <div class="span3">
                        	<div class="content">
                               <?php echo $customizemsn6; ?>
                               <form action="transql/upds/update-slide.php" method="post" name="image_upload" id="image_upload" enctype="multipart/form-data" class="form-horizontal">
                                <h4>Home Hot Deal 3</h4>
                                	<p class="help-block">Link for Hot Deal:</p>
                                	<input class="span10" type="text" name="slide_link" value="<?php echo $settings_slide3_link; ?>" />
                                <div class="form-row row-fluid">
                                	<div class="span12">
                                    	<div class="row-fluid">
                                            <img src="../inc/images/carousel/<?php echo $settings_slide3; ?>" alt="" class="image marginR10"/>
                                            <input type="file" name="image" id="file" />
                                        </div>
                                        <span class="help-block blue span8">Default image size: 189x142px</span>
                                    </div>
                                </div>
                                
                                <br />
                                	<button type="submit" class="btn btn-primary" name="slide3" value="slide3">Submit</button>
                               </form>
                            </div>
                        </div><!-- End .span3 -->
                        
                        <div class="span3">
                        	<div class="content">
                               <?php echo $customizemsn7; ?>
                               <form action="transql/upds/update-slide.php" method="post" name="image_upload" id="image_upload" enctype="multipart/form-data" class="form-horizontal">
                                <h4>Home Hot Deal 4</h4>
                                	<p class="help-block">Link for Hot Deal:</p>
                                	<input class="span10" type="text" name="slide_link" value="<?php echo $settings_slide4_link; ?>" />
                                <div class="form-row row-fluid">
                                	<div class="span12">
                                    	<div class="row-fluid">
                                            <img src="../inc/images/carousel/<?php echo $settings_slide4; ?>" alt="" class="image marginR10"/>
                                            <input type="file" name="image" id="file" />
                                        </div>
                                        <span class="help-block blue span8">Default image size: 189x142px</span>
                                    </div>
                                </div>
                                
                                <br />
                                	<button type="submit" class="btn btn-primary" name="slide4" value="slide4">Submit</button>
                               </form>
                            </div>
                        </div><!-- End .span3 -->

                        

                    </div><!-- End .row-fluid -->    
                                    </div>
                                    
                                    <!-- Start Tab2 -->
                                    <div class="tab-pane fade <?php echo $tab2; ?>" id="tab2">
                                    	<?php echo $citymsn; ?>
									
									
                                        <table cellpadding="0" cellspacing="0" border="0" class="tableTools display table table-bordered" width="100%">
                                            <thead>
                                                <tr>
                                                    <th>Page ID</th>
                                                  	<th>Page Name</th>
                                                  	<th>Actions</th>
                                                </tr>
                                            </thead>
                                          <tbody>
                                    <?php while($page_Data = mysqli_fetch_array($page_list)) { ?>
                                            <tr class="user-row">
                                                <td><?php echo $page_Data['page_id']; ?></td>
                                              	<td><?php echo $page_Data['page_name']; ?></td>
                                              	<td width='200px'>
                                              		<a href='manage-page.php?page_id=<?php echo $page_Data['page_id']; ?>' class='btn'><i class='icon-edit'></i> <strong>Manage</strong></a>
                                             	</td>
                                            </tr>
                                            <?php } mysqli_free_result($page_list); ?>
                                          </tbody>
                                        </table>
                                    </div>
                                    
                                </div>
                            </div>

                        </div><!-- End .span6 -->
                    
                </div><!-- End .row-fluid -->
                <!--End page -->
                
                
                
            </div><!-- End contentwrapper -->
        </div><!-- End #content -->
           
    <footer>
    	<?php include 'inc/footer.php'; ?><!-- /footer -->
    </footer>
    
    </div><!-- End #wrapper -->
    
    <!-- Le javascript
    ================================================== -->
    <!-- Important plugins put in all pages -->
    <script  type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.2/jquery-ui.min.js"></script>
    <script type="text/javascript" src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/bootstrap/bootstrap.js"></script>  
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/jquery.mousewheel.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/libs/jRespond.min.js"></script>


    <!-- Misc plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/misc/qtip/jquery.qtip.min.js"></script><!-- Custom tooltip plugin -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/misc/totop/jquery.ui.totop.min.js"></script> 
    
    
    <!-- Form plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/uniform/jquery.uniform.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/maskedinput/jquery.maskedinput-1.3.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/maskedinput/jquery.maskedinput-1.3.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/tiny_mce/jquery.tinymce.js"></script>
    
    <!-- Form plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/elastic/jquery.elastic.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/inputlimiter/jquery.inputlimiter.1.3.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/maskedinput/jquery.maskedinput-1.3.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/togglebutton/jquery.toggle.buttons.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/uniform/jquery.uniform.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/globalize/globalize.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/color-picker/colorpicker.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/timeentry/jquery.timeentry.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/select/select2.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/dualselect/jquery.dualListBox-1.3.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/tiny_mce/jquery.tinymce.js"></script>
    
    
    <!-- Table plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/tables/dataTables/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/tables/dataTables/TableTools.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/tables/dataTables/ZeroClipboard.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/tables/responsive-tables/responsive-tables.js"></script><!-- Make tables responsive -->
    

    <!-- Init plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/main.js"></script><!-- Core js functions -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/datatable.js"></script><!-- Init plugins only for page -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/forms.js"></script><!-- Init plugins only for page -->


	<script src="<?php echo SITE_URL; ?>ASLibrary/js/asengine.js" type="text/javascript" charset="utf-8"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>ASLibrary/js/index.js" charset="utf-8"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>ASLibrary/js/logout.js" charset="utf-8"></script>
    
    </body>
</html>