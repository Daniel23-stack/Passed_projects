<?php
include 'ASEngine/AS.php';
if(!$login->isLoggedIn())
    header("Location: login.php");
$user = new ASUser(ASSession::get("user_id"));
$userInfo = $user->getInfo();

//basic include files
require_once("../db.php");

$nav = 'email-template';

$emailid = $_GET['emailid'];
$email_address =$_GET['email_address'];

//Messages
include 'inc/messages.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo WEBSITE_NAME; ?></title>
    <meta name="author" content="Bookingo" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="application-name" content="Bookingo" />

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- Force IE9 to render in normla mode -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- Le styles -->
    <!-- Use new way for google web fonts 
    http://www.smashingmagazine.com/2012/07/11/avoiding-faux-weights-styles-google-web-fonts -->
    <!-- Headings -->
    <!-- <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css' />  -->
    <!-- Text -->
    <!-- <link href='http://fonts.googleapis.com/css?family=Droid+Sans:400,700' rel='stylesheet' type='text/css' /> --> 
    <!--[if lt IE 9]>
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:700" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=Droid+Sans:400" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=Droid+Sans:700" rel="stylesheet" type="text/css" />
    <![endif]-->

    <!-- Core stylesheets do not remove -->
    <link id="bootstrap" href="<?php echo SITE_URL; ?>css/bootstrap/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link id="bootstrap-responsive" href="<?php echo SITE_URL; ?>css/bootstrap/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo SITE_URL; ?>css/supr-theme/jquery.ui.supr.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo SITE_URL; ?>css/icons.css" rel="stylesheet" type="text/css" />

    <!-- Plugin stylesheets -->
    <link href="<?php echo SITE_URL; ?>plugins/misc/qtip/jquery.qtip.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo SITE_URL; ?>plugins/forms/uniform/uniform.default.css" type="text/css" rel="stylesheet" />

    <!-- Main stylesheets -->
    <link href="<?php echo SITE_URL; ?>css/main.css" rel="stylesheet" type="text/css" /> 

    <!-- Custom stylesheets ( Put your own changes here ) -->
    <link href="<?php echo SITE_URL; ?>css/custom.css" rel="stylesheet" type="text/css" /> 

    <!--[if IE 8]><link href="css/ie8.css" rel="stylesheet" type="text/css" /><![endif]-->

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script type="text/javascript" src="js/libs/excanvas.min.js"></script>
      <script type="text/javascript" src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <script type="text/javascript" src="js/libs/respond.min.js"></script>
    <![endif]-->

    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="<?php echo SITE_URL; ?>images/favicon.ico" />
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo SITE_URL; ?>images/apple-touch-icon-144-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo SITE_URL; ?>images/apple-touch-icon-114-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo SITE_URL; ?>images/apple-touch-icon-72-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" href="<?php echo SITE_URL; ?>images/apple-touch-icon-57-precomposed.png" />
    
    <!-- Windows8 touch icon ( http://www.buildmypinnedsite.com/ )-->
    <meta name="msapplication-TileColor" content="#3399cc"/> 

    <!-- Load modernizr first -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/libs/modernizr.js"></script>
	
    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
    <![endif]-->
    
    </head>
      
    <body>
    <!-- loading animation -->
    <div id="qLoverlay"></div>
    <div id="qLbar"></div>
    
    <div id="header" class="fixed">

        <?php include 'inc/header.php'; ?><!-- /navbar --> 

    </div><!-- End #header -->

    <div id="wrapper">

        <!--Responsive navigation button-->  
        <div class="resBtn">
            <a href="#"><span class="icon16 minia-icon-list-3"></span></a>
        </div>
        
        <!--Sidebar collapse button-->  
        <div class="collapseBtn leftbar">
             <a href="#" class="tipR" title="Hide sidebar"><span class="icon12 minia-icon-layout"></span></a>
        </div>

        <!--Sidebar background-->
        <div id="sidebarbg"></div>
        <!--Sidebar content-->
        <div id="sidebar">
			<?php include 'inc/sidebar.php'; ?><!-- /sidebar -->
        </div><!-- End #sidebar -->

        <!--Body content-->
        <div id="content" class="clearfix">
            <div class="contentwrapper"><!--Content wrapper-->

                <div class="heading">
				<!--Content Title-->
                    <h3>Edit Email</h3>                    

                    <div class="resBtnSearch">
                        <a href="#"><span class="icon16 icomoon-icon-search-3"></span></a>
                    </div>

                    <ul class="breadcrumb">
                        <li>
                            <a href="./" class="tip" title="back to dashboard">
                                <span class="icon16 icomoon-icon-screen-2"></span>
                            </a> 
                            <span class="divider">
                                <span class="icon16 icomoon-icon-arrow-right-3"></span>
                            </span>
                        </li>
                        <li class="active"><a href="javascript: history.go(-1)">Go Back</a></li>
                    </ul>

                </div><!-- End .heading-->

				
                <!-- Build page from here: -->
                <div class="row-fluid">

                    <div class="span12">

                        <div class="page-header">
                            <h4>Edit Email &nbsp; <a href="mailerconfig.php?tab=2" class="btn btn-primary"><span class="icomoon-icon-arrow-left-9 white"/> Back</a></h4>
                        </div>

                        <?php echo $emailtemplatemsn4; ?>
                        
                        <form action="transql/upds/update-email.php" method="post" class="form-horizontal">
                            <input type="hidden" name="emailid" value="<?php echo $emailid; ?>" class="span6" />
                            
                            <div class="form-row row-fluid">
								<div class="span12">
									<div class="row-fluid">
										<label class="form-label span3">Email</label>
										<input class="span4" type="text" name="email_address" value="<?php echo $email_address; ?>" />
									</div>
								</div>
							</div>
                            
                            <div class="control-group form-row row-fluid">        
                                <div class="span12">
                                    <div class="row-fluid">
                                        <div class="form-actions">
                                        <div class="span3"></div>
                                        <div class="span4 controlsmsn">
                                            <button id="btn-adduser" class="btn btn-success">Submit</button>
                                        </div>
                                        </div>
                                    </div>
                                </div>   
                            </div>
                        </form>
                      
                    </div><!-- End .span12 -->

                </div><!-- End .row-fluid -->
                
                
                <!--End page -->
                
                
            </div><!-- End contentwrapper -->
        </div><!-- End #content -->
           
    <footer>
    	<?php include 'inc/footer.php'; ?><!-- /footer -->
    </footer>
    
    </div><!-- End #wrapper -->
    
    <!-- Le javascript
    ================================================== -->
    <!-- Important plugins put in all pages -->
    <script  type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.2/jquery-ui.min.js"></script>
    <script type="text/javascript" src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/bootstrap/bootstrap.js"></script>  
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/jquery.mousewheel.js"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/libs/jRespond.min.js"></script>


    <!-- Misc plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/misc/qtip/jquery.qtip.min.js"></script><!-- Custom tooltip plugin -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/misc/totop/jquery.ui.totop.min.js"></script> 
    
    
    <!-- Form plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>plugins/forms/uniform/jquery.uniform.min.js"></script>

    <!-- Init plugins -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/main.js"></script><!-- Core js functions -->
    <script type="text/javascript" src="<?php echo SITE_URL; ?>js/empty.js"></script><!-- Init plugins only for page -->


	<script src="<?php echo SITE_URL; ?>ASLibrary/js/asengine.js" type="text/javascript" charset="utf-8"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>ASLibrary/js/index.js" charset="utf-8"></script>
    <script type="text/javascript" src="<?php echo SITE_URL; ?>ASLibrary/js/logout.js" charset="utf-8"></script>
    
    </body>
</html>