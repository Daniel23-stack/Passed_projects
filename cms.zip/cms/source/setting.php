<?php 
define('CNF_APPNAME','CODEIGNITER - SXIMO');
define('CNF_APPDESC','Internal PHP Application');
define('CNF_COMNAME','Mangopik LTD');
define('CNF_EMAIL','info@sximobuilder.com',true);
define('CNF_METAKEY','');
define('CNF_METADESC','');
define('CNF_GROUP','3');
define('CNF_ACTIVATION','auto');
define('CNF_REGIST','true');
define('CNF_FRONT','true');
define('CNF_THEME','mango');
define('CNF_MULTILANG','true');
define('CNF_CICAPTCHA','true');
define('CNF_RECAPTCHA','');
define('CNF_RECAPTCHA_PUBLIC','6Lc3CgATAAAAAPgCiPghxW05nTD9zkP2PAbTbJ31');
define('CNF_RECAPTCHA_PRIVATE','6Lc3CgATAAAAABGFov6XNNdaTP9xM9ctDLCaGiBw');
define('CNF_LOGINFB','true');
define('CNF_LOGINFB_ID','1468944159994855');
define('CNF_LOGINFB_SECRET','8b5b2516044931d1b0c034fe195ed4ec');
define('CNF_LOGINGG','true');
define('CNF_LOGINGG_ID','559583753076-52227gi95f7ndiloavemt2ai3ef2bm6g.apps.googleusercontent.com');
define('CNF_LOGINGG_SECRET','nlsH3tidIYC3THzL6inhKy3C');
define('CNF_LOGINTW','true');
define('CNF_LOGINTW_ID','fJbc2gx4tIG1ZLzNTbYAaCfpy');
define('CNF_LOGINTW_SECRET','XvTc0DF83s1rjKy7zgT0zD6ilgCOSod4DLjNubUMByU1cPsgPT');
?>