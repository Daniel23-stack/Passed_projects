<?php 
$route["home"] = "page/index/home";
$route["home/(:any)"] = "page/index/home/%1";
$route["service"] = "page/index/service";
$route["service/(:any)"] = "page/index/service/%1";
$route["about-us"] = "page/index/about-us";
$route["about-us/(:any)"] = "page/index/about-us/%1";
$route["contact-us"] = "page/index/contact-us";
$route["contact-us/(:any)"] = "page/index/contact-us/%1";
$route["faq"] = "page/index/faq";
$route["faq/(:any)"] = "page/index/faq/%1";
$route["portpolio"] = "page/index/portpolio";
$route["portpolio/(:any)"] = "page/index/portpolio/%1";
?>