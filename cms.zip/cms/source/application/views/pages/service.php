	<section class="story section has-pattern" id="story">
        <div class="container">
            <div class="row">
                <div class="content col-md-6 col-sm-6 col-xs-12 text-center animated fadeInLeft delayp1" style="opacity: 0;">
                    <h2 class="title">What We can do for you ?</h2>
                    <p>Aliquam euismod vehicula lacus, non congue ante pulvinar a. .</p>
                    <p>Nullam vel nibh pulvinar, interdum purus tristique, iaculis turpis. Integer imperdiet tincidunt erat vel gravida. eleifend ut. Integer at lorem nec diam elementum convallis vel vel nulla.</p>
                </div><!--//content-->
                <div class="team col-md-5 col-sm-5 col-md-offset-1 col-sm-offset-1 col-xs-12">
                    
                    
                </div>
            </div>
        </div>
    </section>
	
	
	<section class="services" id="why">
	<div class="container">
	  <div class="row">
		<div class="col-md-4 col-sm-6">
		  <h4><i class="fa fa-flag"></i> Service </h4>
		  Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod. 
		</div>
		<div class="col-md-4 col-sm-6">
		  <h4><i class="fa fa-ban"></i>Service </h4>
		 Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod. 
		</div>
		<div class="col-md-4 col-sm-6">
		  <h4><i class="fa fa-arrows-alt"></i> Service </h4>
		  Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod. 
		</div>
		<div class="col-md-4 col-sm-6">
		  <h4><i class="fa fa-microphone"></i> Service </h4>
		 Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod. 
		</div>
		<div class="col-md-4 col-sm-6">
		  <h4><i class="fa fa-pencil"></i> Service </h4>
		  Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod. 
		</div>
		<div class="col-md-4 col-sm-6">
		  <h4><i class="fa fa-eye"></i> PService </h4>
		 Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod. 
		</div>
		<div class="col-md-4 col-sm-6">
		  <h4><i class="fa fa-gamepad"></i> Service </h4>
		 Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod. 
		</div>
		<div class="col-md-4 col-sm-6">
		  <h4><i class="fa fa-desktop"></i> Service </h4>
		 Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod. 
		</div>
		<div class="col-md-4 col-sm-6">
		  <h4><i class="fa fa-search"></i> Service </h4>
		  Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod. 
		</div>
	  </div>
	  </div>	
	</section>
