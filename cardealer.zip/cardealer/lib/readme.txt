Shared by Lolclol

on http://bestblackhatforum.com