<?php
  /**
   * 404 Error
   *
   * @package Car Dealer Pro
   * @author wojoscripts.com
   * @copyright 2012
   *Shared by LOLcLOL
   * @version $Id: 404.php, v1.00 2012-03-05 10:12:05 gewa Exp $
   */
  define("_VALID_PHP", true);
  require_once("init.php");
  $row = false;
?>
<?php include("header.php");?>
<?php include(THEMEDIR . "/404.tpl.php");?>
<?php include("footer.php");?>