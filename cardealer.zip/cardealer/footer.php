<?php
  /**
   * Footer
   *
   * @package Car Dealer Pro
   * @author wojoscripts.com
   * @copyright 2014
   * Shared by LOLcLOL
   * @version $Id: footer.php, v 1.00 2014-01-10 21:12:05 gewa Exp $
   */
  
  if (!defined("_VALID_PHP"))
      die('Direct access to this location is not allowed.');
?>
<?php /*Shared by LOLcLOL*/ ?>
Shared by LOLcLOL
<?php include(THEMEDIR . "/footer.tpl.php");?>