<?php
  /**
   * Safe Mod Rewrite Test.php
   *
   * @package CMS Pro
   * @author wojocms.com
   * @copyright 2010
   * @version $Id: modrewrite.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
?>
<?php echo "Mod-Rewrite Test"; ?>