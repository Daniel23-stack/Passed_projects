-- ================================================================
--
-- @version $Id: structure.sql 2014-02-01 10:12:05 gewa $
-- @package Car Dealer Pro
-- @copyright 2014. wojoscripts.com
--
-- ================================================================
-- Database structure
-- ================================================================

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `slug` varchar(120) DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`,`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `conditions`
--

DROP TABLE IF EXISTS `conditions`;
CREATE TABLE IF NOT EXISTS `conditions` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `email_templates`
--

DROP TABLE IF EXISTS `email_templates`;
CREATE TABLE IF NOT EXISTS `email_templates` (
  `id` tinyint(2) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `help` text,
  `body` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `email_templates`
--

INSERT INTO `email_templates` (`id`, `name`, `subject`, `help`, `body`) VALUES
(1, 'Welcome Mail From Admin', 'You have been registered', 'This template is used to send welcome email, when user is added by administrator', '&lt;div style=&quot;font-family:Arial, Helvetica, sans-serif; font-size:13px&quot; align=&quot;center&quot;&gt;\n	&lt;table style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 2px solid #bbb;&quot; border=&quot;0&quot; cellpadding=&quot;10&quot; cellspacing=&quot;5&quot; width=&quot;600&quot;&gt;\n	&lt;tbody&gt;\n	&lt;tr&gt;\n		&lt;th style=&quot;background-color: rgb(204, 204, 204); font-size:16px;padding:5px;border-bottom-width:2px; border-bottom-color:#fff; border-bottom-style:solid&quot;&gt;\n			Welcome [NAME]\n		&lt;/th&gt;\n	&lt;/tr&gt;\n	&lt;tr&gt;\n		&lt;td style=&quot;text-align: left;&quot; valign=&quot;top&quot;&gt;\n			Hello, &lt;br&gt;\n			&lt;br&gt;\n          You&#039;re now a member of [SITE_NAME]. \n			&lt;br&gt;\n          Here are your login details. Please keep them in a safe place:\n		&lt;/td&gt;\n	&lt;/tr&gt;\n	&lt;tr&gt;\n		&lt;td style=&quot;text-align: left;&quot; valign=&quot;top&quot;&gt;\n			&lt;table border=&quot;0&quot; cellpadding=&quot;4&quot; cellspacing=&quot;2&quot;&gt;\n			&lt;tbody&gt;\n			&lt;tr&gt;\n				&lt;td style=&quot;border-bottom-width:1px; border-bottom-color:#bbb; border-bottom-style:dashed&quot; align=&quot;right&quot; width=&quot;130&quot;&gt;\n					&lt;strong&gt;Username:&lt;/strong&gt;\n				&lt;/td&gt;\n				&lt;td style=&quot;border-bottom-width:1px; border-bottom-color:#bbb; border-bottom-style:dashed&quot;&gt;\n					[USERNAME]\n				&lt;/td&gt;\n			&lt;/tr&gt;\n			&lt;tr&gt;\n				&lt;td style=&quot;border-bottom-width:1px; border-bottom-color:#bbb; border-bottom-style:dashed&quot; align=&quot;right&quot;&gt;\n					&lt;strong&gt;Password:&lt;/strong&gt;\n				&lt;/td&gt;\n				&lt;td style=&quot;border-bottom-width:1px; border-bottom-color:#bbb; border-bottom-style:dashed&quot;&gt;\n					[PASSWORD]\n				&lt;/td&gt;\n			&lt;/tr&gt;\n			&lt;/tbody&gt;\n			&lt;/table&gt;\n&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;\n		&lt;td style=&quot;text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid&quot; valign=&quot;top&quot;&gt;\n			&lt;em&gt;Thanks,&lt;br&gt;\n          [SITE_NAME] Team\n			&lt;br&gt;\n			&lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;\n		&lt;/td&gt;&lt;/tr&gt;&lt;/tbody&gt;&lt;/table&gt;&lt;/div&gt;'),
(2, 'Contact Request', 'Contact Inquiry', 'This template is used to send default Contact Request Form.', '&lt;div style=&quot;font-family:Arial, Helvetica, sans-serif; font-size:13px&quot; align=&quot;center&quot;&gt;\n	&lt;table style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 2px solid #bbb;&quot; border=&quot;0&quot; cellpadding=&quot;10&quot; cellspacing=&quot;5&quot; width=&quot;600&quot;&gt;\n	&lt;tbody&gt;\n	&lt;tr&gt;\n		&lt;th style=&quot;background-color: rgb(204, 204, 204); font-size:16px;padding:5px;border-bottom-width:2px; border-bottom-color:#fff; border-bottom-style:solid&quot;&gt;\n			Hello, Admin\n		&lt;/th&gt;\n	&lt;/tr&gt;\n	&lt;tr&gt;\n		&lt;td style=&quot;text-align: left&quot;&gt;\n			You have received new contact request:\n		&lt;/td&gt;\n	&lt;/tr&gt;\n	&lt;tr&gt;\n		&lt;td style=&quot;text-align: left;&quot; valign=&quot;top&quot;&gt;\n			&lt;table border=&quot;0&quot; cellpadding=&quot;4&quot; cellspacing=&quot;2&quot;&gt;\n			&lt;tbody&gt;\n			&lt;tr&gt;\n				&lt;td style=&quot;border-bottom-width:1px; border-bottom-color:#bbb; border-bottom-style:dashed&quot; align=&quot;right&quot; width=&quot;130&quot;&gt;\n					&lt;strong&gt;From:&lt;/strong&gt;\n				&lt;/td&gt;\n				&lt;td style=&quot;border-bottom-width:1px; border-bottom-color:#bbb; border-bottom-style:dashed&quot;&gt;\n					[SENDER] - [NAME]\n				&lt;/td&gt;\n			&lt;/tr&gt;\n			&lt;tr&gt;\n				&lt;td style=&quot;border-bottom-width:1px; border-bottom-color:#bbb; border-bottom-style:dashed&quot; align=&quot;right&quot;&gt;\n					&lt;strong&gt;Subject:&lt;/strong&gt;\n				&lt;/td&gt;\n				&lt;td style=&quot;border-bottom-width:1px; border-bottom-color:#bbb; border-bottom-style:dashed&quot;&gt;\n					[MAILSUBJECT]\n				&lt;/td&gt;\n			&lt;/tr&gt;\n			&lt;tr&gt;\n				&lt;td style=&quot;border-bottom-width:1px; border-bottom-color:#bbb; border-bottom-style:dashed&quot; align=&quot;right&quot;&gt;\n					&lt;strong&gt;IP:&lt;/strong&gt;\n				&lt;/td&gt;\n				&lt;td style=&quot;border-bottom-width:1px; border-bottom-color:#bbb; border-bottom-style:dashed&quot;&gt;\n					[IP]\n				&lt;/td&gt;\n			&lt;/tr&gt;\n			&lt;tr&gt;\n				&lt;td colspan=&quot;2&quot; style=&quot;border-bottom-width:1px; border-bottom-color:#bbb; border-bottom-style:dashed&quot; align=&quot;left&quot; valign=&quot;top&quot;&gt;\n					[MESSAGE]\n				&lt;/td&gt;\n			&lt;/tr&gt;\n			&lt;/tbody&gt;\n			&lt;/table&gt;\n&lt;/td&gt;&lt;/tr&gt;&lt;/tbody&gt;&lt;/table&gt;&lt;/div&gt;'),
(3, 'Single Email', 'Single User Email', 'This template is used to email single user', '&lt;div style=&quot;font-family:Arial, Helvetica, sans-serif; font-size:13px&quot; align=&quot;center&quot;&gt;\n	&lt;table style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 2px solid #bbb;&quot; border=&quot;0&quot; cellpadding=&quot;10&quot; cellspacing=&quot;5&quot; width=&quot;600&quot;&gt;\n	&lt;tbody&gt;\n	&lt;tr&gt;\n		&lt;th style=&quot;background-color: rgb(204, 204, 204); font-size:16px;padding:5px;border-bottom-width:2px; border-bottom-color:#fff; border-bottom-style:solid&quot;&gt;\n			Hello [NAME]\n		&lt;/th&gt;\n	&lt;/tr&gt;\n	&lt;tr&gt;\n		&lt;td style=&quot;text-align: left;&quot; valign=&quot;top&quot;&gt;\n			Your message goes here...\n		&lt;/td&gt;\n	&lt;/tr&gt;\n	&lt;tr&gt;\n		&lt;td style=&quot;text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid&quot; valign=&quot;top&quot;&gt;\n			&lt;em&gt;Thanks,&lt;br&gt;\n          [SITE_NAME] Team\n			&lt;br&gt;\n			&lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;\n		&lt;/td&gt;\n	&lt;/tr&gt;\n	&lt;/tbody&gt;\n	&lt;/table&gt;&lt;/div&gt;'),
(4, 'Forgot Password Email', 'Password Reset', 'This template is used for retrieving lost admin password.', '&lt;div style=&quot;font-family:Arial, Helvetica, sans-serif; font-size:13px&quot; align=&quot;center&quot;&gt;\n  &lt;table style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 2px solid #bbb;&quot; border=&quot;0&quot; cellpadding=&quot;10&quot; cellspacing=&quot;5&quot; width=&quot;600&quot;&gt;\n	&lt;tbody&gt;\n	&lt;tr&gt;\n		&lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;\n			New password reset from [SITE_NAME]!\n		&lt;/th&gt;\n	&lt;/tr&gt;\n	&lt;tr&gt;\n		&lt;td style=&quot;text-align: left;&quot; valign=&quot;top&quot;&gt;\n			Hello, &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br&gt;\n			&lt;br&gt;\n            It seems that you or someone requested a new password for you.\n			&lt;br&gt;\n            We have generated a new password, as requested:\n			&lt;br&gt;\n			&lt;br&gt;\n            Your new password: \n			&lt;strong&gt;[PASSWORD]&lt;/strong&gt;&lt;br&gt;\n			&lt;br&gt;\n            To use the new password you need to activate it. To do this click the link provided below and login with your new password.\n			&lt;br&gt;\n			&lt;a href=&quot;[LINK]&quot;&gt;[LINK]&lt;/a&gt;&lt;br&gt;\n			&lt;br&gt;\n            You can change your password after you sign in.\n			&lt;hr&gt;\n            Password requested from IP: [IP]\n		&lt;/td&gt;\n	&lt;/tr&gt;\n	&lt;tr&gt;\n		&lt;td style=&quot;text-align: left;&quot;&gt;\n			&lt;em&gt;Thanks,&lt;br&gt;\n            [SITE_NAME] Team\n			&lt;br&gt;\n			&lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;\n		&lt;/td&gt;\n	&lt;/tr&gt;\n	&lt;/tbody&gt;\n	&lt;/table&gt;&lt;/div&gt;'),
(5, 'Default Newsletter', 'Newsletter', 'This is a default newsletter template', '&lt;div style=&quot;font-family:Arial, Helvetica, sans-serif; font-size:13px;margin:20px&quot; align=&quot;center&quot;&gt;\n  &lt;table style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 2px solid #bbb;&quot; border=&quot;0&quot; cellpadding=&quot;10&quot; cellspacing=&quot;5&quot; width=&quot;600&quot;&gt;\n    &lt;tbody&gt;\n      &lt;tr&gt;\n        &lt;th style=&quot;background-color: rgb(204, 204, 204); font-size:16px;padding:5px;border-bottom-width:2px; border-bottom-color:#fff; border-bottom-style:solid&quot;&gt;Hello [EMAIL]!&lt;/th&gt;\n      &lt;/tr&gt;\n      &lt;tr&gt;\n        &lt;td style=&quot;text-align: left;border-bottom-width:2px; border-bottom-color:#fff; border-bottom-style:solid&quot;&gt;You are receiving this email as a part of your newsletter subscription.&lt;/td&gt;\n      &lt;/tr&gt;\n      &lt;tr&gt;\n        &lt;td style=&quot;text-align: left;&quot; valign=&quot;top&quot;&gt; Here goes your newsletter content... &lt;/td&gt;\n      &lt;/tr&gt;\n      &lt;tr&gt;\n        &lt;td style=&quot;text-align: left;background-color:#f1f1f1;border-top-width:2px; border-top-color:#fff; border-top-style:solid&quot;&gt;&lt;em&gt;Thanks,&lt;br/&gt;\n          [SITE_NAME] Team&lt;br/&gt;\n          &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n      &lt;/tr&gt;\n      &lt;tr&gt;\n        &lt;td style=&quot;text-align: left; background-color:#fff;border-top-width:2px; border-top-color:#ccc; border-top-style:solid&quot; valign=&quot;top&quot;&gt;&lt;em&gt;To stop receiving future newsletters please visit our site and uncheck newsletter subscription box.&lt;/em&gt;&lt;/td&gt;\n      &lt;/tr&gt;\n    &lt;/tbody&gt;\n  &lt;/table&gt;\n&lt;/div&gt;');

--
-- Table structure for table `faq`
--

DROP TABLE IF EXISTS `faq`;
CREATE TABLE IF NOT EXISTS `faq` (
  `id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `question` varchar(150) DEFAULT NULL,
  `answer` text,
  `position` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `features`
--

DROP TABLE IF EXISTS `features`;
CREATE TABLE IF NOT EXISTS `features` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `fuel`
--

DROP TABLE IF EXISTS `fuel`;
CREATE TABLE IF NOT EXISTS `fuel` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `gallery`
--

DROP TABLE IF EXISTS `gallery`;
CREATE TABLE IF NOT EXISTS `gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `listing_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(100) DEFAULT NULL,
  `photo` varchar(200) DEFAULT NULL,
  `sorting` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `language`
--

DROP TABLE IF EXISTS `language`;
CREATE TABLE IF NOT EXISTS `language` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang_key` varchar(25) NOT NULL,
  `lang_value` text NOT NULL,
  `lang_type` varchar(50) NOT NULL,
  `abbr` varchar(6) NOT NULL DEFAULT 'en',
  `name` varchar(50) NOT NULL DEFAULT 'English',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `language`
--

INSERT INTO `language` (`id`, `lang_key`, `lang_value`, `lang_type`, `abbr`, `name`) VALUES
(1, 'YES', 'Yes', 'Global', 'en', 'English'),
(2, 'NO', 'No', 'Global', 'en', 'English'),
(3, 'ADD', 'Add', 'Global', 'en', 'English'),
(4, 'ADDALL', 'Add All', 'Global', 'en', 'English'),
(5, 'EDIT', 'Edit', 'Global', 'en', 'English'),
(6, 'DELETE', 'Delete', 'Global', 'en', 'English'),
(7, 'CANCEL', 'Cancel', 'Global', 'en', 'English'),
(8, 'UPLOAD', 'Upload', 'Global', 'en', 'English'),
(9, 'SUBMIT', 'Submit', 'Global', 'en', 'English'),
(10, 'VIEW', 'View', 'Global', 'en', 'English'),
(11, 'VISITS', 'Visits', 'Global', 'en', 'English'),
(12, 'FROM', 'From', 'Global', 'en', 'English'),
(13, 'BROWSE', 'Browse...', 'Global', 'en', 'English'),
(14, 'SEARCH', 'Search...', 'Global', 'en', 'English'),
(15, 'ALERT', 'Alert!', 'Global', 'en', 'English'),
(16, 'SUCCESS', 'Success!', 'Global', 'en', 'English'),
(17, 'ERROR', 'Error!', 'Global', 'en', 'English'),
(18, 'INFO', 'Info!', 'Global', 'en', 'English'),
(19, 'STATUS', 'Status', 'Global', 'en', 'English'),
(20, 'CREATED', 'Created', 'Global', 'en', 'English'),
(21, 'MODIFIED', 'Modified', 'Global', 'en', 'English'),
(22, 'ON', 'On', 'Global', 'en', 'English'),
(23, 'OFF', 'Off', 'Global', 'en', 'English'),
(24, 'PRINT', 'Print', 'Global', 'en', 'English'),
(25, 'GO', 'GO', 'Global', 'en', 'English'),
(26, 'FROM', 'From', 'Global', 'en', 'English'),
(27, 'TO', 'To', 'Global', 'en', 'English'),
(28, 'ALL', 'All', 'Global', 'en', 'English'),
(29, 'PHOTO', 'Photo', 'Global', 'en', 'English'),
(30, 'DESC', 'Description', 'Global', 'en', 'English'),
(31, 'LOCATIONS', 'Locations', 'Global', 'en', 'English'),
(32, 'ACTIONS', 'Actions', 'Global', 'en', 'English'),
(33, 'LISTINGS', 'Listings', 'Global', 'en', 'English'),
(34, 'FIND', 'Find', 'Global', 'en', 'English'),
(35, 'REMOVE', 'Remove', 'Global', 'en', 'English'),
(36, 'ADMIN', 'Admin', 'Global', 'en', 'English'),
(37, 'GUEST', 'Guest', 'Global', 'en', 'English'),
(38, 'NAME', 'Name', 'Global', 'en', 'English'),
(39, 'YOU', 'You', 'Global', 'en', 'English'),
(40, 'LOGIN', 'Login', 'Global', 'en', 'English'),
(41, 'LOGOUT', 'Logout', 'Global', 'en', 'English'),
(42, 'REGD', 'Registered', 'Global', 'en', 'English'),
(43, 'PUBLISHED', 'Published', 'Global', 'en', 'English'),
(44, 'ACTIVE', 'Active', 'Global', 'en', 'English'),
(45, 'INACTIVE', 'Inactive', 'Global', 'en', 'English'),
(46, 'FEATURED', 'Featured', 'Global', 'en', 'English'),
(47, 'CHARSET', 'A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z', 'Global', 'en', 'English'),
(48, 'USERNAME', 'Username', 'Global', 'en', 'English'),
(49, 'USERNAME_R1', 'Please Enter Valid Username', 'Global', 'en', 'English'),
(50, 'USERNAME_R2', 'Username Is Too Short (less Than 4 Characters Long).', 'Global', 'en', 'English'),
(51, 'USERNAME_R3', 'Invalid Characters Found In Username.', 'Global', 'en', 'English'),
(52, 'USERNAME_R4', 'Sorry, This Username Is Already Taken', 'Global', 'en', 'English'),
(53, 'USERNAME_R5', 'We are sorry, selected username does not exist in our database', 'Global', 'en', 'English'),
(54, 'USERNAME_AVAIL', 'Username Available', 'Global', 'en', 'English'),
(55, 'USERNAME_NOAVAIL', 'Username Not Available', 'Global', 'en', 'English'),
(56, 'PASSWORD', 'Password', 'Global', 'en', 'English'),
(57, 'PASSWORD_T', 'Leave it empty unless changing the password.', 'Global', 'en', 'English'),
(58, 'PASSWORD_R1', 'Please Enter Valid Password.', 'Global', 'en', 'English'),
(59, 'PASSWORD_R2', 'Password entered is not alphanumeric.', 'Global', 'en', 'English'),
(60, 'PASSWORD_R3', 'Your password did not match the confirmed password!', 'Front', 'en', 'English'),
(61, 'PASSWORD_T2', 'Password must be at least 6 characters long.', 'Global', 'en', 'English'),
(62, 'PASSWORD_L', 'forgot password', 'Global', 'en', 'English'),
(63, 'PASSWORD_RES', 'Password Reset', 'Global', 'en', 'English'),
(64, 'PASSWORD_RES_S', 'Password Reset From ', 'Global', 'en', 'English'),
(65, 'PASSWORD_RES_T', 'In order to reset your password, please enter the email address above, you used to register your account.', 'Global', 'en', 'English'),
(66, 'PASSWORD_RES_D', 'Password sent successfully. Please check your email', 'Global', 'en', 'English'),
(67, 'EMAIL', 'Email Address', 'Global', 'en', 'English'),
(68, 'EMAIL_R1', 'Please Enter Valid Email Address', 'Global', 'en', 'English'),
(69, 'EMAIL_R2', 'Entered Email Address Is Already In Use.', 'Global', 'en', 'English'),
(70, 'EMAIL_R3', 'Entered Email Address Is Not Valid.', 'Global', 'en', 'English'),
(71, 'EMAIL_R4', 'Entered Email Address Does Not Exist.', 'Global', 'en', 'English'),
(72, 'FNAME', 'First Name', 'Global', 'en', 'English'),
(73, 'LNAME', 'Last Name', 'Global', 'en', 'English'),
(74, 'LOGIN_R1', 'Login and/or password did not match to the database.', 'Global', 'en', 'English'),
(75, 'LOGIN_R2', 'Your account has been banned.', 'Global', 'en', 'English'),
(76, 'LOGIN_R3', 'Your account it&#039;s not activated.', 'Global', 'en', 'English'),
(77, 'LOGIN_R4', 'You need to verify your email address.', 'Global', 'en', 'English'),
(78, 'LOGIN_R5', 'Please enter valid username and password', 'Global', 'en', 'English'),
(79, 'BACKTOLOGIN', 'back to login', 'Global', 'en', 'English'),
(80, 'KM', 'Kilometers', 'Global', 'en', 'English'),
(81, 'MI', 'Miles', 'Global', 'en', 'English'),
(82, 'BACKTO', ' Back To Listings ', 'Global', 'en', 'English'),
(83, 'REQFIELD1', ' Fields marked ', 'Global', 'en', 'English'),
(84, 'REQFIELD2', ' are required.', 'Global', 'en', 'English'),
(85, 'DELCONFIRM', 'Are you sure you want to delete this record?', 'Global', 'en', 'English'),
(86, 'DELCONFIRM2', 'This action cannot be undone!!!', 'Global', 'en', 'English'),
(87, 'NOACCESS', 'Sorry don&#39;t have administrative privileges to access this page.', 'Global', 'en', 'English'),
(88, 'NOPROCCESS', 'Nothing to process', 'Global', 'en', 'English'),
(89, 'PROCCESS_ERR', 'Please complete the following required fields:', 'Global', 'en', 'English'),
(90, 'PROCCESS_ERR2', 'Please enter: [FIELDNAME]', 'Global', 'en', 'English'),
(91, 'PREV', 'Prev', 'Pagination', 'en', 'English'),
(92, 'NEXT', 'Next', 'Pagination', 'en', 'English'),
(93, 'GOTO', 'Go To', 'Pagination', 'en', 'English'),
(94, 'OF', ' of ', 'Pagination', 'en', 'English'),
(95, 'IPP', 'Items Per Page', 'Pagination', 'en', 'English'),
(96, 'CURPAGE', 'Current Page', 'Pagination', 'en', 'English'),
(97, 'ADM_HOME', 'Home', 'Navigation', 'en', 'English'),
(98, 'ADM_PAGES', 'Content Pages', 'Navigation', 'en', 'English'),
(99, 'ADM_MENUS', 'Content Menus', 'Navigation', 'en', 'English'),
(100, 'ADM_FAQ', 'Content F.A.Q.', 'Navigation', 'en', 'English'),
(101, 'ADM_ETPL', 'Email Templates', 'Navigation', 'en', 'English'),
(102, 'ADM_LOCS', 'Showrooms', 'Navigation', 'en', 'English'),
(103, 'ADM_CATS', 'Categories', 'Navigation', 'en', 'English'),
(104, 'ADM_COND', 'Conditions', 'Navigation', 'en', 'English'),
(105, 'ADM_FUEL', 'Fuel Types', 'Navigation', 'en', 'English'),
(106, 'ADM_TRANS', 'Transmissions', 'Navigation', 'en', 'English'),
(107, 'ADM_MAKES', 'Makes', 'Navigation', 'en', 'English'),
(108, 'ADM_MODELS', 'Models', 'Navigation', 'en', 'English'),
(109, 'ADM_FEATURES', 'Features', 'Navigation', 'en', 'English'),
(110, 'ADM_LISTINGS', 'Listings', 'Navigation', 'en', 'English'),
(111, 'CONF_TITLE', 'System Configuration', 'Configuration', 'en', 'English'),
(112, 'CONF_INFO', 'Changes made here will affect the settings of Car Dealer Pro.', 'Configuration', 'en', 'English'),
(113, 'CONF_SUB', 'Update System Configuration', 'Configuration', 'en', 'English'),
(114, 'CONF_SITE', 'Website Name', 'Configuration', 'en', 'English'),
(115, 'CONF_SITE_T', 'The name of your web site, which is displayed in various locations across your site.', 'Configuration', 'en', 'English'),
(116, 'CONF_COMPANY', 'Company Name', 'Configuration', 'en', 'English'),
(117, 'CONF_COMPANY_T', 'This is your website slogan which will appear near your website heading', 'Configuration', 'en', 'English'),
(118, 'CONF_URL', 'Website Url', 'Configuration', 'en', 'English'),
(119, 'CONF_URL_T', 'Insert full URL WITHOUT any trailing slash  (e.g. http://www.yourdomain.com)', 'Configuration', 'en', 'English'),
(120, 'CONF_EMAIL', 'Company Email', 'Configuration', 'en', 'English'),
(121, 'CONF_EMAIL_T', 'This is the main email notices will be sent to. It is also used as the from &#39;email&#39; when emailing other automatic emails.', 'Configuration', 'en', 'English'),
(122, 'CONF_DIR', 'Install Directory', 'Configuration', 'en', 'English'),
(123, 'CONF_DIR_T', 'Directory where CDP is installed', 'Configuration', 'en', 'English'),
(124, 'CONF_ADDRESS', 'Address', 'Configuration', 'en', 'English'),
(125, 'CONF_CITY', 'City', 'Configuration', 'en', 'English'),
(126, 'CONF_STATE', 'Province/State', 'Configuration', 'en', 'English'),
(127, 'CONF_ZIP', 'Postal Code/Zip', 'Configuration', 'en', 'English'),
(128, 'CONF_PHONE', 'Telephone', 'Configuration', 'en', 'English'),
(129, 'CONF_FAX', 'Fax', 'Configuration', 'en', 'English'),
(130, 'CONF_OFFLINE', 'Put Site Offline', 'Configuration', 'en', 'English'),
(131, 'CONF_OFFLINE_T', 'If site is inactive it will display Maintenance mode message. To access your site go to admin panel and login as admin. Now only you&#39;ll be able to browse your site.', 'Configuration', 'en', 'English'),
(132, 'CONF_OFFLINE_DATE', 'Offline Date', 'Configuration', 'en', 'English'),
(133, 'CONF_OFFLINE_TIME', 'Offline Time', 'Configuration', 'en', 'English'),
(134, 'CONF_OFFLINE_TIME_T', 'Select the time when the site should be back online', 'Configuration', 'en', 'English'),
(135, 'CONF_OFFLINE_INFO', 'Offline Message', 'Configuration', 'en', 'English'),
(136, 'CONF_OFFLINE_INFO_T', 'Enter a message that will be displayed to your visitors, once the site is in offline mode.', 'Configuration', 'en', 'English'),
(137, 'CONF_LOGO', 'Company Logo', 'Configuration', 'en', 'English'),
(138, 'CONF_LOGO_R', 'Illegal file type. Only jpg and png file types allowed.', 'Configuration', 'en', 'English'),
(139, 'CONF_LOGO_I', 'Logo Preview', 'Configuration', 'en', 'English'),
(140, 'CONF_DELLOGO', 'Delete Logo', 'Configuration', 'en', 'English'),
(141, 'CONF_DELLOGO_T', 'If no logo exists, Company Name will be used instead.', 'Configuration', 'en', 'English'),
(142, 'CONF_SDATE', 'Short Date', 'Configuration', 'en', 'English'),
(143, 'CONF_LDATE', 'Long Date', 'Configuration', 'en', 'English'),
(144, 'CONF_TZ', 'Default Time Zone', 'Configuration', 'en', 'English'),
(145, 'CONF_LOC', 'Default Locale', 'Configuration', 'en', 'English'),
(146, 'CONF_LOC_T', 'Locales are used for displaying dates in your own language format.', 'Configuration', 'en', 'English'),
(147, 'CONF_WEEK', 'Week Starts On', 'Configuration', 'en', 'English'),
(148, 'CONF_LANG', 'Default Language', 'Configuration', 'en', 'English'),
(149, 'CONF_IPP', 'Items Per Page', 'Configuration', 'en', 'English'),
(150, 'CONF_IPP_T', 'Default number of items used for pagination', 'Configuration', 'en', 'English'),
(151, 'CONF_FEATURED', 'Featured Items', 'Configuration', 'en', 'English'),
(152, 'CONF_FEATURED_T', 'Default number of featured items', 'Configuration', 'en', 'English'),
(153, 'CONF_SPEAD', 'Default Speed Unit', 'Configuration', 'en', 'English'),
(154, 'CONF_CURRENCY', 'Default Currency', 'Configuration', 'en', 'English'),
(155, 'CONF_CURRENCY_T', 'Enter your currency such as CAD, USD, EUR', 'Configuration', 'en', 'English'),
(156, 'CONF_CURRENCY_R', 'Please Enter Valid Default currency', 'Configuration', 'en', 'English'),
(157, 'CONF_CURSYMBOL', 'Currency Symbol', 'Configuration', 'en', 'English'),
(158, 'CONF_CURSYMBOL_T', 'Enter your currency symbol such as $, €, £', 'Configuration', 'en', 'English'),
(159, 'CONF_TSEP', 'Thousands Separator', 'Configuration', 'en', 'English'),
(160, 'CONF_DSEP', 'Decimal Separator', 'Configuration', 'en', 'English'),
(161, 'CONF_MAILER', 'Default Mailer', 'Configuration', 'en', 'English'),
(162, 'CONF_MAILER_T', 'Use PHP Mailer or SMTP protocol for sending emails', 'Configuration', 'en', 'English'),
(163, 'CONF_SMTP_HOST', 'SMTP Hostname', 'Configuration', 'en', 'English'),
(164, 'CONF_SMTP_HOST_T', 'Specify main SMTP server. E.g.:(mail.yourserver.com)', 'Configuration', 'en', 'English'),
(165, 'CONF_SMTP_HOST_R', 'Please Enter Valid SMTP Host', 'Configuration', 'en', 'English'),
(166, 'CONF_SMTP_USER', 'SMTP Username', 'Configuration', 'en', 'English'),
(167, 'CONF_SMTP_USER_R', 'Please Enter Valid SMTP Username!', 'Configuration', 'en', 'English'),
(168, 'CONF_SMTP_PASS', 'SMTP Password', 'Configuration', 'en', 'English'),
(169, 'CONF_SMTP_PORT', 'SMTP Port', 'Configuration', 'en', 'English'),
(170, 'CONF_SMTP_SSL', 'Requires SSL', 'Configuration', 'en', 'English'),
(171, 'CONF_SMTP_SSL_T', 'Choose Yes if your server requires SSL connection.', 'Configuration', 'en', 'English'),
(172, 'CONF_SMTP_PASS_R', 'Please Enter Valid SMTP Password!', 'Configuration', 'en', 'English'),
(173, 'CONF_SMTP_PORT_T', 'Mail server port ( Can be 25, 26. 456 for GMAIL. 587 for Yahoo ). Ask your host if uncertain.', 'Configuration', 'en', 'English'),
(174, 'CONF_SMTP_PORT_R', 'Please Enter Valid SMTP Port', 'Configuration', 'en', 'English'),
(175, 'CONF_SMAILPATH', 'Sendmail Path', 'Configuration', 'en', 'English'),
(176, 'CONF_SMAILPATH_T', 'Ask your hosting company for sandmail path if unsure. Usually: /usr/sbin/sendmail -t -i', 'Configuration', 'en', 'English'),
(177, 'CONF_SMAILPATH_R', 'Please enter valid sendmail path.', 'Configuration', 'en', 'English'),
(178, 'CONF_GA', 'Google Analytics', 'Configuration', 'en', 'English'),
(179, 'CONF_GA_T', 'Paste your code Google Analytics code here.', 'Configuration', 'en', 'English'),
(180, 'CONF_GA_I', 'To sign up for Google Analytics, visit http://www.google.com/analytics', 'Configuration', 'en', 'English'),
(181, 'CONF_METAKEY', 'Site wide Meta Keywords', 'Configuration', 'en', 'English'),
(182, 'CONF_METAKEY_T', 'Meta keywords are used to describe your website. These are used by some search engines to categorise your website.', 'Configuration', 'en', 'English'),
(183, 'CONF_METADESC', 'Site wide Meta Description', 'Configuration', 'en', 'English'),
(184, 'CONF_METADESC_T', 'A meta description is a brief summary of the current page. It may be used by search engines when they display search results containing your website.', 'Configuration', 'en', 'English'),
(185, 'CONF_UPDATE', 'Update Configuration', 'Configuration', 'en', 'English'),
(186, 'CONF_UPDATED', 'System Configuration updated successfully!', 'Configuration', 'en', 'English'),
(187, 'CONF_HELP', 'System Configuration Help', 'Configuration', 'en', 'English'),
(188, 'USR_TITLE', 'User Management', 'Users', 'en', 'English'),
(189, 'USR_INFO', 'Here you can update your users profile.', 'Users', 'en', 'English'),
(190, 'USR_SUB', 'Editing User &#8250; ', 'Users', 'en', 'English'),
(191, 'USR_EDIT', 'Edit User', 'Users', 'en', 'English'),
(192, 'USR_LEVEL', 'User Level', 'Users', 'en', 'English'),
(193, 'USR_USERS', 'Users', 'Users', 'en', 'English'),
(194, 'USR_ADMIN', 'Administrator', 'Users', 'en', 'English'),
(195, 'USR_EDITOR', 'Editor', 'Users', 'en', 'English'),
(196, 'USR_LEVEL_T', 'Administrator has full rights. Editor has assignable permissions.', 'Users', 'en', 'English'),
(197, 'USR_ACCESS', 'Access Level', 'Users', 'en', 'English'),
(198, 'USR_ACCESS_T', 'Select which locacions Editor will be able to access and add/modufy. Only applies to additional Editors. Administrators will have full access.', 'Users', 'en', 'English'),
(199, 'USR_LASTLOGIN', 'Last Login', 'Users', 'en', 'English'),
(200, 'USR_LOCATIONS_T', 'User will have listing access only to those locations assigned here. You can select one or more location.', 'Users', 'en', 'English'),
(201, 'USR_LASTIP', 'Last Login IP', 'Users', 'en', 'English'),
(202, 'USR_UPDATE', 'Update Profile', 'Users', 'en', 'English'),
(203, 'USR_INFO1', 'Here you can add new user.', 'Users', 'en', 'English'),
(204, 'USR_SUB1', 'Adding New User', 'Users', 'en', 'English'),
(205, 'USR_NOTIFY', 'Notify User', 'Users', 'en', 'English'),
(206, 'USR_NOTIFY_T', 'Send welcome email to this user.', 'Users', 'en', 'English'),
(207, 'USR_ADD', 'Add User', 'Users', 'en', 'English'),
(208, 'USR_INFO2', 'Here you can manage your users. You can email each user by clicking on username.', 'Users', 'en', 'English'),
(209, 'USR_SUB2', 'Viewing All Users', 'Users', 'en', 'English'),
(210, 'USR_FULLNAME', 'Full Name', 'Users', 'en', 'English'),
(211, 'USR_DELUSER', 'Delete User', 'Users', 'en', 'English'),
(212, 'USR_DELUSER_ERR1', 'You cannot delete main Administrator account!', 'Users', 'en', 'English'),
(213, 'USR_DELUSER_OK', 'User [USERNAME] deleted successfully!', 'Users', 'en', 'English'),
(214, 'USR_UPDATED', 'User updated successfully!', 'Users', 'en', 'English'),
(215, 'USR_ADDED', 'User added successfully!', 'Users', 'en', 'English'),
(216, 'USR_HELP', 'User Management Help', 'Users', 'en', 'English'),
(217, 'PAG_TITLE', 'Manage Content Pages', 'Pages', 'en', 'English'),
(218, 'PAG_INFO', 'Here you can update your content page.', 'Pages', 'en', 'English'),
(219, 'PAG_SUB', 'Editing Page &#8250; ', 'Pages', 'en', 'English'),
(220, 'PAG_INFO1', 'Here you can add new content page.', 'Pages', 'en', 'English'),
(221, 'PAG_SUB1', 'Adding New Content Page', 'Pages', 'en', 'English'),
(222, 'PAG_INFO2', 'Here you can manage your content pages.', 'Pages', 'en', 'English'),
(223, 'PAG_SUB2', 'Viewing All Pages', 'Pages', 'en', 'English'),
(224, 'PAG_EDIT', 'Edit Page', 'Pages', 'en', 'English'),
(225, 'PAG_NAME', 'Page Title', 'Pages', 'en', 'English'),
(226, 'PAG_SLUG', 'Page Slug', 'Pages', 'en', 'English'),
(227, 'PAG_SLUG_T', 'Title appearing in browser navigation bar. If left empty, it will be automatically generated baesd on page title.', 'Pages', 'en', 'English'),
(228, 'PAG_DATE', 'Date Created', 'Pages', 'en', 'English'),
(229, 'PAG_HOME', 'Home Page', 'Pages', 'en', 'English'),
(230, 'PAG_HOME_T', 'If Yes it will be default homepage menu.', 'Pages', 'en', 'English'),
(231, 'PAG_FAQPAGE', 'F.A.Q. Page', 'Pages', 'en', 'English'),
(232, 'PAG_FAQPAGE_T', 'If Yes, this page will be your default F.A.Q. page.', 'Pages', 'en', 'English'),
(233, 'PAG_CNPAGE', 'Contact Page', 'Pages', 'en', 'English'),
(234, 'PAG_CNPAGE_T', 'If Yes, this page will be your default contact page, with built in contact form.', 'Pages', 'en', 'English'),
(235, 'PAG_BODY', 'Page Content', 'Pages', 'en', 'English'),
(236, 'PAG_TYPE', 'Page Type', 'Pages', 'en', 'English'),
(237, 'PAG_NOPAGE', 'You don&#39;t have any pages yet. Please add...', 'Pages', 'en', 'English'),
(238, 'PAG_DELPAGE', 'Delete Page', 'Pages', 'en', 'English'),
(239, 'PAG_DELPAGE_OK', 'Page [PAGE] deleted successfully!', 'Pages', 'en', 'English'),
(240, 'PAG_DELPAGE_H', 'Default home page can not be deleted.', 'Pages', 'en', 'English'),
(241, 'PAG_UPDATE', 'Update Page', 'Pages', 'en', 'English'),
(242, 'PAG_UPDATED', 'Page updated successfully!', 'Pages', 'en', 'English'),
(243, 'PAG_ADD', 'Add Page', 'Pages', 'en', 'English'),
(244, 'PAG_ADDED', 'Page added successfully!', 'Pages', 'en', 'English'),
(245, 'PAG_HELP', 'Content Pages Help', 'Pages', 'en', 'English'),
(246, 'MENU_TITLE', 'Manage Content Menus', 'Menus', 'en', 'English'),
(247, 'MENU_INFO1', 'Use the form below to create a new menu (such as a navigation menu of web pages) which can then be displayed on your web site.', 'Menus', 'en', 'English'),
(248, 'MENU_INFO_T', 'Drag and drop items to change their positions on the tree. Click on a menu name to access edit options. Click on [DEL] to delete. Click on [SAVE] to save menu positions.', 'Menus', 'en', 'English'),
(249, 'MENU_OPT', 'Menu Options', 'Menus', 'en', 'English'),
(250, 'MENU_SUB1', 'Adding New Menu', 'Menus', 'en', 'English'),
(251, 'MENU_INFO', 'Here you can update your menu items.', 'Menus', 'en', 'English'),
(252, 'MENU_SUB', 'Editing Content Menu &#8250; ', 'Menus', 'en', 'English'),
(253, 'MENU_NAME', 'Menu Name', 'Menus', 'en', 'English'),
(254, 'MENU_NAME_T', 'The name of the menu will appear in navigation.', 'Menus', 'en', 'English'),
(255, 'MENU_LIST', 'Menu List', 'Menus', 'en', 'English'),
(256, 'MENU_TYPE', 'Content Type', 'Menus', 'en', 'English'),
(257, 'MENU_TYPE_SEL', '--- Select Content Type ---', 'Menus', 'en', 'English'),
(258, 'MENU_TYPE_T', 'This menu will link to Following: Content Page and External Link', 'Menus', 'en', 'English'),
(259, 'MENU_LINK', 'Content Link', 'Menus', 'en', 'English'),
(260, 'MENU_LINK_T', 'Enter full url starting with http://', 'Menus', 'en', 'English'),
(261, 'MENU_TARGET', 'Target', 'Menus', 'en', 'English'),
(262, 'MENU_TARGETL', 'Link Target', 'Menus', 'en', 'English'),
(263, 'MENU_TARGET_S', '_Self', 'Menus', 'en', 'English'),
(264, 'MENU_TARGET_B', '_Blank', 'Menus', 'en', 'English'),
(265, 'MENU_NONE', '--- none ---', 'Menus', 'en', 'English'),
(266, 'MENU_PUB', 'Menu Published', 'Menus', 'en', 'English'),
(267, 'MENU_ADD', 'Add Menu', 'Menus', 'en', 'English'),
(268, 'MENU_EDIT', 'Edit Menu', 'Menus', 'en', 'English'),
(269, 'MENU_SAVE', 'Save Order', 'Menus', 'en', 'English'),
(270, 'MENU_UPDATE', 'Update Menu', 'Menus', 'en', 'English'),
(271, 'MENU_SORTED', 'Menus sorted successfully!', 'Menus', 'en', 'English'),
(272, 'MENU_DELETE', 'Delete Menu', 'Menus', 'en', 'English'),
(273, 'MENU_DELMENU_OK', 'Menu [MENU] deleted successfully!', 'Menus', 'en', 'English'),
(274, 'MENU_UPDATED', 'Menu updated successfully!', 'Menus', 'en', 'English'),
(275, 'MENU_ADDED', 'Menu added successfully!', 'Menus', 'en', 'English'),
(276, 'MENU_HELP', 'Content Menu Help', 'Menus', 'en', 'English'),
(277, 'FAQ_TITLE', 'Manage Content F.A.Q.', 'FAQ', 'en', 'English'),
(278, 'FAQ_INFO', 'Here you can update your f.a.q..', 'FAQ', 'en', 'English'),
(279, 'FAQ_SUB', 'Editing F.A.Q. &#8250; ', 'FAQ', 'en', 'English'),
(280, 'FAQ_INFO1', 'Here you can add new f.a.q.', 'FAQ', 'en', 'English'),
(281, 'FAQ_SUB1', 'Adding New Content F.A.Q.', 'FAQ', 'en', 'English'),
(282, 'FAQ_INFO2', 'Here you can manage your f.a.q. To reorder questions click and drag question ID(#), position it where you want it, then click on Save Position button.', 'FAQ', 'en', 'English'),
(283, 'FAQ_SUB2', 'Viewing All F.A.Q.', 'FAQ', 'en', 'English'),
(284, 'FAQ_EDIT', 'Edit F.A.Q.', 'FAQ', 'en', 'English'),
(285, 'FAQ_NAME', 'Question', 'FAQ', 'en', 'English'),
(286, 'FAQ_POS', 'Position', 'FAQ', 'en', 'English'),
(287, 'FAQ_SAVE', 'Save Position', 'FAQ', 'en', 'English'),
(288, 'FAQ_BODY', 'Answer', 'FAQ', 'en', 'English'),
(289, 'FAQ_NOFAQ', 'You don&#39;t have any f.a.q. yet. Please add...', 'FAQ', 'en', 'English'),
(290, 'FAQ_DELFAQ', 'Delete F.A.Q.', 'FAQ', 'en', 'English'),
(291, 'FAQ_DELFAQ_OK', 'F.A.Q. [FAQ] deleted successfully!', 'FAQ', 'en', 'English'),
(292, 'FAQ_UPDATE', 'Update F.A.Q.', 'FAQ', 'en', 'English'),
(293, 'FAQ_UPDATED', 'F.A.Q. updated successfully!', 'FAQ', 'en', 'English'),
(294, 'FAQ_ADD', 'Add F.A.Q.', 'FAQ', 'en', 'English'),
(295, 'FAQ_ADDED', 'F.A.Q. added successfully!', 'FAQ', 'en', 'English'),
(296, 'FAQ_SORTED', 'F.A.Q. Order updated successfully!', 'FAQ', 'en', 'English'),
(297, 'FAQ_HELP', 'Content F.A.Q. Help', 'FAQ', 'en', 'English'),
(298, 'ETPL_TITLE', 'Manage Email Templates', 'Email', 'en', 'English'),
(299, 'ETPL_INFO', 'Here you can update your email template', 'Email', 'en', 'English'),
(300, 'ETPL_SUB', 'Editing Template &#8250; ', 'Email', 'en', 'English'),
(301, 'ETPL_INFO1', 'Here you can manage your email templates.', 'Email', 'en', 'English'),
(302, 'ETPL_SUB1', 'Viewing All Email Templates', 'Email', 'en', 'English'),
(303, 'ETPL_EDIT', 'Edit Template', 'Email', 'en', 'English'),
(304, 'ETPL_NAME', 'Template Name', 'Email', 'en', 'English'),
(305, 'ETPL_SUBJECT', 'Template Subject', 'Email', 'en', 'English'),
(306, 'ETPL_INFO', 'Template Info', 'Email', 'en', 'English'),
(307, 'ETPL_BODY', 'Template Content', 'Email', 'en', 'English'),
(308, 'ETPL_NOTPL', 'You are missing email templates. Please reinstall...', 'Email', 'en', 'English'),
(309, 'ETPL_UPDATE', 'Update Template', 'Email', 'en', 'English'),
(310, 'ETPL_UPDATED', 'Template updated successfully!', 'Email', 'en', 'English'),
(311, 'LST_TITLE', 'Manage Car Listings', 'Listings', 'en', 'English'),
(312, 'LST_INFO', 'Here you can update your car listings.', 'Listings', 'en', 'English'),
(313, 'LST_SUB', 'Editing Listing &#8250; ', 'Listings', 'en', 'English'),
(314, 'LST_INFO1', 'Here you can add a new listing.', 'Listings', 'en', 'English'),
(315, 'LST_SUB1', 'Adding Listing', 'Listings', 'en', 'English'),
(316, 'LST_INFO2', 'Here you can manage your car listings.', 'Listings', 'en', 'English'),
(317, 'LST_SUB2', 'Viewing All Car Listings', 'Listings', 'en', 'English'),
(318, 'LST_MGEN', 'General', 'Listings', 'en', 'English'),
(319, 'LST_MFET', 'Features', 'Listings', 'en', 'English'),
(320, 'LST_MDSC', 'Description', 'Listings', 'en', 'English'),
(321, 'LST_EDIT', 'Edit Listing', 'Listings', 'en', 'English'),
(322, 'LST_ROOM', 'Showroom', 'Listings', 'en', 'English'),
(323, 'LST_ROOM_S', 'Select Location', 'Listings', 'en', 'English'),
(324, 'LST_YEAR', 'Model Year', 'Listings', 'en', 'English'),
(325, 'LST_STOCK', 'Stock #', 'Listings', 'en', 'English'),
(326, 'LST_VIN', 'VIN', 'Listings', 'en', 'English'),
(327, 'LST_MAKE', 'Make', 'Listings', 'en', 'English'),
(328, 'LST_MAKE_S', 'Select Make Name', 'Listings', 'en', 'English'),
(329, 'LST_MODEL', 'Model', 'Listings', 'en', 'English'),
(330, 'LST_MODEL_S', 'Select Model Name', 'Listings', 'en', 'English'),
(331, 'LST_CAT', 'Category', 'Listings', 'en', 'English'),
(332, 'LST_CAT_S', 'Select Category Type', 'Listings', 'en', 'English'),
(333, 'LST_COND', 'Condition', 'Listings', 'en', 'English'),
(334, 'LST_COND_S', 'Select Condition Type', 'Listings', 'en', 'English'),
(335, 'LST_ODM', 'Odometer', 'Listings', 'en', 'English'),
(336, 'LST_TORQUE', 'Torque', 'Listings', 'en', 'English'),
(337, 'LST_EXTC', 'Exterior Color', 'Listings', 'en', 'English'),
(338, 'LST_INTC', 'Interior Color', 'Listings', 'en', 'English'),
(339, 'LST_ENGINE', 'Engine', 'Listings', 'en', 'English'),
(340, 'LST_TRAIN', 'Drive Train', 'Listings', 'en', 'English'),
(341, 'LST_DOORS', 'Doors', 'Listings', 'en', 'English'),
(342, 'LST_TRANS', 'Transmission', 'Listings', 'en', 'English'),
(343, 'LST_TRANS_S', 'Select Transmission Type', 'Listings', 'en', 'English'),
(344, 'LST_SPEED', 'Top Speed', 'Listings', 'en', 'English'),
(345, 'LST_FUEL', 'Fuel Type', 'Listings', 'en', 'English'),
(346, 'LST_FUEL_S', 'Select Fuel Type', 'Listings', 'en', 'English'),
(347, 'LST_POWER', 'Horse Power', 'Listings', 'en', 'English'),
(348, 'LST_TOWING', 'Towing Capacity', 'Listings', 'en', 'English'),
(349, 'LST_PRICE', 'Listing Price', 'Listings', 'en', 'English'),
(350, 'LST_DPRICE_S', 'Sale Price', 'Listings', 'en', 'English'),
(351, 'LST_FEATURED', 'Featured Listing', 'Listings', 'en', 'English'),
(352, 'LST_FEATURED_T', 'Featured Listings have better visual impact than normal listing', 'Listings', 'en', 'English'),
(353, 'LST_ACTIVE', 'Active Listing', 'Listings', 'en', 'English'),
(354, 'LST_ACTIVE_T', 'Only Active or Published listings will be visible on front page.', 'Listings', 'en', 'English'),
(355, 'LST_IMAGE', 'Main Image', 'Listings', 'en', 'English'),
(356, 'LST_IMAGE_P', 'Image Preview', 'Listings', 'en', 'English'),
(357, 'LST_IMAGE_ERR1', 'Illegal Image type. Only .jpg or .png allowed', 'Listings', 'en', 'English'),
(358, 'LST_IMAGE_ERR2', 'Illegal file type. It does not appear to be an image.', 'Listings', 'en', 'English'),
(359, 'LST_FEATURES', 'Car Features', 'Listings', 'en', 'English'),
(360, 'LST_SEL_ALL', 'Select/Unselect All ', 'Listings', 'en', 'English'),
(361, 'LST_LTITLE', 'Listing Title', 'Listings', 'en', 'English'),
(362, 'LST_LTITLE_T', 'If left empty, it will be automatically generated baesd on listing Make and Model.', 'Listings', 'en', 'English'),
(363, 'LST_SLUG', 'Listing Slug', 'Listings', 'en', 'English'),
(364, 'LST_SLUG_T', 'Title appearing in browser navigation bar. If left empty, it will be automatically generated baesd on listing Year-Make-Model', 'Listings', 'en', 'English'),
(365, 'LST_DESC', 'Listing Description', 'Listings', 'en', 'English'),
(366, 'LST_NOTES', 'Internal Notes', 'Listings', 'en', 'English'),
(367, 'LST_NOTES_T', 'This field is used for internal purposes only. Content entered here will be visible in this section only.', 'Listings', 'en', 'English'),
(368, 'LST_METAKEY', 'Meta Keywords', 'Listings', 'en', 'English'),
(369, 'LST_METAKEY_T', 'Specify unique Meta keywords, or leave it empty for a system generated keywords. Keywords will be automatically generated based on your listing description.', 'Listings', 'en', 'English'),
(370, 'LST_METADESC', 'Meta Description', 'Listings', 'en', 'English'),
(371, 'LST_METADESC_T', 'Specify unique Meta description, or leave it empty for a system generated description. A meta description is a brief summary of the current page. It may be used by search engines when they display search results containing your website.', 'Listings', 'en', 'English'),
(372, 'LST_NOLIST', 'You don&#39;t have any listings yet. Please add...', 'Listings', 'en', 'English'),
(373, 'LST_UPDATE', 'Update Listing', 'Listings', 'en', 'English'),
(374, 'LST_ADD', 'Add Listing', 'Listings', 'en', 'English'),
(375, 'LST_DELETE', 'Delete Listing', 'Listings', 'en', 'English'),
(376, 'LST_DELETES', 'Delete Selected', 'Listings', 'en', 'English'),
(377, 'LST_DEL_ERR1', 'Please select at least one listing.', 'Listings', 'en', 'English'),
(378, 'LST_DEL_OK1', 'Selected listing(s) have been deleted successfully.', 'Listings', 'en', 'English'),
(379, 'LST_DEL_OK', 'Listing [LISTING] deleted successfully!', 'Listings', 'en', 'English'),
(380, 'LST_UPDATED', 'Listing updated successfully!', 'Listings', 'en', 'English'),
(381, 'LST_ADDED', 'Listing added successfully!', 'Listings', 'en', 'English'),
(382, 'LST_HELP', 'Listing Management Help', 'Listings', 'en', 'English'),
(383, 'LOC_TITLE', 'Locations Management', 'Locations', 'en', 'English'),
(384, 'LOC_INFO', 'Here you can update your showroom location.', 'Locations', 'en', 'English'),
(385, 'LOC_SUB', 'Editing Location &#8250; ', 'Locations', 'en', 'English'),
(386, 'LOC_INFO1', 'Here you can add a new showroom location', 'Locations', 'en', 'English'),
(387, 'LOC_SUB1', 'Adding New Location', 'Locations', 'en', 'English'),
(388, 'LOC_INFO2', 'Here you can manage your dealership locations.', 'Locations', 'en', 'English'),
(389, 'LOC_SUB2', 'Viewing All Locations', 'Locations', 'en', 'English'),
(390, 'LOC_NOLOC', 'You don&#39;t have any locations yet. Please add...', 'Locations', 'en', 'English'),
(391, 'LOC_NAME', 'Dealership Name', 'Locations', 'en', 'English'),
(392, 'LOC_COUNTRY', 'Country Name', 'Locations', 'en', 'English'),
(393, 'LOC_EDIT', 'Edit Location', 'Locations', 'en', 'English'),
(394, 'LOC_UPDATE', 'Update Location', 'Locations', 'en', 'English'),
(395, 'LOC_ADD', 'Add Location', 'Locations', 'en', 'English'),
(396, 'LOC_UPDATED', 'Location updated successfully', 'Locations', 'en', 'English'),
(397, 'LOC_ADDED', 'Location added successfully', 'Locations', 'en', 'English'),
(398, 'LOC_DELOC_OK', 'Location [LOCATION] deleted successfully!', 'Locations', 'en', 'English'),
(399, 'LOC_HELP', 'Location Management Help', 'Locations', 'en', 'English'),
(400, 'LOC_SEARCH', 'Location Search', 'Locations', 'en', 'English'),
(401, 'LOC_SEARCH_T', 'Type your exact address into map search field. Once location is found, you can drag and move loaction pin to mark percise location of your showroom. Zoom level will also be saved along with your location on the map.', 'Locations', 'en', 'English'),
(402, 'LPR_TITLE', 'View Listing Summary', 'Preview', 'en', 'English'),
(403, 'LPR_INFO', 'Here you can view summary of the information available for this listing.', 'Preview', 'en', 'English'),
(404, 'LPR_SUB', 'Viewing Listing Summary For &#8250; ', 'Preview', 'en', 'English'),
(405, 'LPR_SUMMARY', 'Listing Summary', 'Preview', 'en', 'English'),
(406, 'GAL_TITLE', 'Listing Gallery', 'Gallery', 'en', 'English'),
(407, 'GAL_INFO', 'Here you can manage your listing image gallery. Click on image title to edit.', 'Gallery', 'en', 'English'),
(408, 'GAL_SUB', 'Viewing Photos For ›', 'Gallery', 'en', 'English'),
(409, 'GAL_NOGAL', 'You don&#39;t have any images yet. Please upload.', 'Gallery', 'en', 'English'),
(410, 'GAL_UPLOAD', 'Upload Images', 'Gallery', 'en', 'English'),
(411, 'FM_DROP', 'Drop Images Here', 'Gallery', 'en', 'English'),
(412, 'FM_FILE_ERR', 'This file type is not allowed.', 'Gallery', 'en', 'English'),
(413, 'FM_FILE_ERR1', 'File with the same name already exists.', 'Gallery', 'en', 'English'),
(414, 'FM_FILE_ERR2', 'Selected directory is not writable.', 'Gallery', 'en', 'English'),
(415, 'FM_FILE_ERR3', 'File is larger than the [LIMIT] limit.', 'Gallery', 'en', 'English'),
(416, 'FM_FILE_ERR4', 'Specified directory does not exists.', 'Gallery', 'en', 'English'),
(417, 'FM_FILE_ERR5', 'This file type [EXT] is not allowed.', 'Gallery', 'en', 'English'),
(418, 'GAL_DELOK', 'Photo [PHOTO] deleted successfully!', 'Gallery', 'en', 'English'),
(419, 'CAT_TITLE', 'Manage Categories', 'Categories', 'en', 'English'),
(420, 'CAT_INFO', 'Here you can manage your categories. Click on category title to edit.', 'Categories', 'en', 'English'),
(421, 'CAT_SUB', 'Viewing All Categories', 'Categories', 'en', 'English'),
(422, 'CAT_NAME', 'Category Name', 'Categories', 'en', 'English'),
(423, 'CAT_ADDNEW', 'Adding New Category', 'Categories', 'en', 'English'),
(424, 'CAT_ADD', 'Add Category', 'Categories', 'en', 'English'),
(425, 'CAT_ADDED', 'Category [CATEGORY] added successfully!', 'Categories', 'en', 'English'),
(426, 'CAT_NOCAT', 'You don&#39;t have any categories yet. Please add...', 'Categories', 'en', 'English'),
(427, 'CAT_DEL', 'Delete Category', 'Categories', 'en', 'English'),
(428, 'CAT_DELOC_OK', 'Category [CATEGORY] deleted successfully!', 'Categories', 'en', 'English'),
(429, 'MAKE_TITLE', 'Manage Car Makes', 'Makes', 'en', 'English'),
(430, 'MAKE_INFO', 'Here you can manage your car makes. Click on model title to edit. Note: Deleting Car Make will also delete all models assigned under the same.', 'Makes', 'en', 'English'),
(431, 'MAKE_SUB', 'Viewing All Makes', 'Makes', 'en', 'English'),
(432, 'MAKE_NAME', 'Make Name', 'Makes', 'en', 'English'),
(433, 'MAKE_NAME_R', 'Please select make name from the list', 'Makes', 'en', 'English'),
(434, 'MAKE_ADDNEW', 'Adding New Make', 'Makes', 'en', 'English'),
(435, 'MAKE_ADD', 'Add Make', 'Makes', 'en', 'English'),
(436, 'MAKE_ADDED', 'Make [MAKE] added successfully!', 'Makes', 'en', 'English'),
(437, 'MAKE_NOMAKE', 'You don&#39;t have any makes yet. Please add...', 'Makes', 'en', 'English'),
(438, 'MAKE_DEL', 'Delete Make', 'Makes', 'en', 'English'),
(439, 'MAKE_DELOF_OK', 'Make [MAKE] deleted successfully!', 'Makes', 'en', 'English'),
(440, 'MODL_TITLE', 'Manage Car Models', 'Models', 'en', 'English'),
(441, 'MODL_INFO', 'Here you can manage your car models. Click on model name to edit. To add more models, first select Car Make from Car Make List, then click on add button.', 'Models', 'en', 'English'),
(442, 'MODL_SUB', 'Viewing All Models', 'Models', 'en', 'English'),
(443, 'MODL_NAME', 'Model Name', 'Models', 'en', 'English'),
(444, 'MODL_NAME_R', 'Please enter at least one Model Name', 'Models', 'en', 'English'),
(445, 'MODL_ADDNEW', 'Adding New Model', 'Models', 'en', 'English'),
(446, 'MODL_SEARCH', 'search model...', 'Models', 'en', 'English'),
(447, 'MODL_ADD', 'Add Model', 'Models', 'en', 'English'),
(448, 'MODL_RESET', 'Reset Car Makes List', 'Models', 'en', 'English'),
(449, 'MODL_ADDED', 'Model(s) added successfully!', 'Models', 'en', 'English'),
(450, 'MODL_NOMODEL', 'You don&#39;t have any models yet. Please add...', 'Models', 'en', 'English'),
(451, 'MODL_DEL', 'Delete Model', 'Models', 'en', 'English'),
(452, 'MODL_DELOF_OK', 'Model [MODEL] deleted successfully!', 'Models', 'en', 'English'),
(453, 'COND_TITLE', 'Manage Conditions', 'Conditions', 'en', 'English'),
(454, 'COND_INFO', 'Here you can manage your car conditions. Click on conditions title to edit.', 'Conditions', 'en', 'English'),

(455, 'COND_SUB', 'Viewing All Conditions', 'Conditions', 'en', 'English'),
(456, 'COND_NAME', 'Condition Name', 'Conditions', 'en', 'English'),
(457, 'COND_ADDNEW', 'Adding New Condition', 'Conditions', 'en', 'English'),
(458, 'COND_ADD', 'Add Condition', 'Conditions', 'en', 'English'),
(459, 'COND_ADDED', 'Condition [COND] added successfully!', 'Conditions', 'en', 'English'),
(460, 'COND_NOCON', 'You don&#39;t have any condition types yet. Please add...', 'Conditions', 'en', 'English'),
(461, 'COND_DEL', 'Delete Condition Type', 'Conditions', 'en', 'English'),
(462, 'COND_DELOF_OK', 'Condition [COND] deleted successfully!', 'Conditions', 'en', 'English'),
(463, 'FEAT_TITLE', 'Manage Features', 'Features', 'en', 'English'),
(464, 'FEAT_INFO', 'Here you can manage your car features. Click on feature title to edit.', 'Features', 'en', 'English'),
(465, 'FEAT_SUB', 'Viewing All Features', 'Features', 'en', 'English'),
(466, 'FEAT_NAME', 'Feature Name', 'Features', 'en', 'English'),
(467, 'FEAT_ADDNEW', 'Adding Feature', 'Features', 'en', 'English'),
(468, 'FEAT_ADD', 'Add Feature', 'Features', 'en', 'English'),
(469, 'FEAT_ADDED', 'Feature [FEATURE] added successfully!', 'Features', 'en', 'English'),
(470, 'FEAT_NOFEATURE', 'You don&#39;t have any features yet. Please add...', 'Features', 'en', 'English'),
(471, 'FEAT_DEL', 'Delete Feature', 'Features', 'en', 'English'),
(472, 'FEAT_DELOF_OK', 'Feature [FEATURE] deleted successfully!', 'Features', 'en', 'English'),
(473, 'TRNS_TITLE', 'Manage Transmissions Types', 'Transmissions', 'en', 'English'),
(474, 'TRNS_INFO', 'Here you can manage your transmission types. Click on transmissions title to edit.', 'Transmissions', 'en', 'English'),
(475, 'TRNS_SUB', 'Viewing All Transmissions', 'Transmissions', 'en', 'English'),
(476, 'TRNS_NAME', 'Transmission Type Name', 'Transmissions', 'en', 'English'),
(477, 'TRNS_ADDNEW', 'Adding New Transmissions Type', 'Transmissions', 'en', 'English'),
(478, 'TRNS_ADD', 'Add Transmission Type', 'Transmissions', 'en', 'English'),
(479, 'TRNS_ADDED', 'Transmission [TRANS] added successfully!', 'Transmissions', 'en', 'English'),
(480, 'TRNS_NOTRANS', 'You don&#39;t have any transmission types yet. Please add...', 'Transmissions', 'en', 'English'),
(481, 'TRNS_DEL', 'Delete Transmission Type', 'Transmissions', 'en', 'English'),
(482, 'TRNS_DELOF_OK', 'Transmission [TRANS] deleted successfully!', 'Transmissions', 'en', 'English'),
(483, 'FUEL_TITLE', 'Manage Fuel Types', 'Fuel', 'en', 'English'),
(484, 'FUEL_INFO', 'Here you can manage fuel  types. Click on fuel type title to edit.', 'Fuel', 'en', 'English'),
(485, 'FUEL_SUB', 'Viewing All Fuel Types', 'Fuel', 'en', 'English'),
(486, 'FUEL_NAME', 'Fuel Type Name', 'Fuel', 'en', 'English'),
(487, 'FUEL_ADDNEW', 'Adding New Fuel Type', 'Fuel', 'en', 'English'),
(488, 'FUEL_ADD', 'Add Fuel Type', 'Fuel', 'en', 'English'),
(489, 'FUEL_ADDED', 'Fuel Type [FUEL] added successfully!', 'Fuel', 'en', 'English'),
(490, 'FUEL_NOFUEL', 'You don&#39;t have any fuel types yet. Please add...', 'Fuel', 'en', 'English'),
(491, 'FUEL_DEL', 'Delete Fuel Type', 'Fuel', 'en', 'English'),
(492, 'FUEL_DELOF_OK', 'Fuel Type [FUEL] deleted successfully!', 'Fuel', 'en', 'English'),
(493, 'WELCOME', 'Welcome', 'Global', 'en', 'English'),
(494, 'ADM_CONTENT', 'Content', 'Navigation', 'en', 'English'),
(495, 'ADM_CONFIG', 'Configuration', 'Navigation', 'en', 'English'),
(496, 'ADM_USERS', 'Users', 'Navigation', 'en', 'English'),
(497, 'ADM_INVENTORY', 'Inventory', 'Navigation', 'en', 'English'),
(498, 'ADM_LANG', 'Language Manager', 'Navigation', 'en', 'English'),
(499, 'ADM_SYSTEM', 'System Info', 'Navigation', 'en', 'English'),
(500, 'ADM_BACKUP', 'Database Backup', 'Navigation', 'en', 'English'),
(501, 'ADM_SITEMAP', 'Sitemap Manager', 'Navigation', 'en', 'English'),
(502, 'LNG_TITLE', 'Language Manager', 'Language', 'en', 'English'),
(503, 'GLOBAL', 'Global', 'Global', 'en', 'English'),
(504, 'PAGINATION', 'Pagination', 'Global', 'en', 'English'),
(505, 'ADM_NAV', 'Navigation', 'Navigation', 'en', 'English'),
(506, 'LNG_RESET', 'Reset Language Group Filter', 'Language', 'en', 'English'),
(507, 'LNG_SUB', 'Viewing All Language Phrases', 'Language', 'en', 'English'),
(508, 'LNG_INFO', 'Hre you can update ypur language phrases. Note: Do not replace variables between [ ]', 'Language', 'en', 'English'),
(509, 'LNG_ADD', 'Add Language', 'Language', 'en', 'English'),
(510, 'LNG_INFO1', 'Here you can add new language.', 'Language', 'en', 'English'),
(511, 'LNG_SUB1', 'Adding New Language', 'Language', 'en', 'English'),
(512, 'LNG_NAME', 'Language Name', 'Language', 'en', 'English'),
(513, 'LNG_ABBR', 'Language Abbrivation', 'Language', 'en', 'English'),
(514, 'LNG_HELP', 'Language Manager Help', 'Language', 'en', 'English'),
(515, 'LNG_NAME_T', 'Enter your language name such as Français, Deutsch etc...', 'Language', 'en', 'English'),
(516, 'LNG_ABBR_T', 'Language abbrivation based on language name such as fr, de, es, pt etc...', 'Language', 'en', 'English'),
(517, 'LNG_ADDED', 'Language addedd successfully. You can switch it from admin configuration.', 'Language', 'en', 'English'),
(518, 'LNG_NEW', 'New Language', 'Language', 'en', 'English'),
(519, 'LNG_NEW_T', 'New language will be based on existing English phrases.', 'Language', 'en', 'English'),
(520, 'BAC_TITLE', 'Backup Manager', 'Backup', 'en', 'English'),
(521, 'SYS_TITLE', 'System Information', 'System', 'en', 'English'),
(522, 'MAP_TITLE', 'Sitemap Manager', 'Sitemap', 'en', 'English'),
(523, 'SYS_CMS_INF', 'CDP Info', 'System', 'en', 'English'),
(524, 'SYS_CMS_VER', 'CDP Version', 'System', 'en', 'English'),
(525, 'SYS_SITE_URL', 'Site Url', 'System', 'en', 'English'),
(526, 'SYS_ROOT_PATH', 'Root Path', 'System', 'en', 'English'),
(527, 'SYS_SITE_DIR', 'Site Directory', 'System', 'en', 'English'),
(528, 'SYS_UPL_URL', 'Uploads Url', 'System', 'en', 'English'),
(529, 'SYS_UPL_PATH', 'Uploads Path', 'System', 'en', 'English'),
(530, 'SYS_DEF_LANG', 'Default Language', 'System', 'en', 'English'),
(531, 'SYS_PHP_INF', 'PHP Info', 'System', 'en', 'English'),
(532, 'SYS_PHP_VER', 'Current PHP Version', 'System', 'en', 'English'),
(533, 'SYS_GD_VER', 'GD Version', 'System', 'en', 'English'),
(534, 'SYS_MQR', 'Magic quotes runtime', 'System', 'en', 'English'),
(535, 'SYS_LOG_ERR', 'Log Errors', 'System', 'en', 'English'),
(536, 'SYS_MEM_LIM', 'Memory Limit', 'System', 'en', 'English'),
(537, 'SYS_RG', 'Register Globals', 'System', 'en', 'English'),
(538, 'SYS_SM', 'Safe Mode', 'System', 'en', 'English'),
(539, 'SYS_UMF', 'Upload Max. filesize', 'System', 'en', 'English'),
(540, 'SYS_SSP', 'Session Save Path', 'System', 'en', 'English'),
(541, 'SYS_SER_INF', 'Server Info', 'System', 'en', 'English'),
(542, 'SYS_SER_OS', 'Server OS', 'System', 'en', 'English'),
(543, 'SYS_SER_API', 'Server API', 'System', 'en', 'English'),
(544, 'SYS_SER_MR', 'Apache Mod Rewrite', 'System', 'en', 'English'),
(545, 'SYS_SER_DB', 'Server Database', 'System', 'en', 'English'),
(546, 'SYS_DBV', 'Server Database Version', 'System', 'en', 'English'),
(547, 'SYS_MEMALO', 'Maximum Allocated Memory', 'System', 'en', 'English'),
(548, 'SYS_STS', 'Server Total Space', 'System', 'en', 'English'),
(549, 'SYS_SUB', 'Default System Info', 'System', 'en', 'English'),
(550, 'SYS_INFO', 'The information displayed below is collected from a variety of locations, and summarized here so that you may be able to conveniently find some of the information required when trying to diagnose a problem or request help with your CDP installation.', 'System', 'en', 'English'),
(551, 'BAC_INFO', 'Make sure your database is backed up frequently. Click on Create backup to manually backup your database. The backups are stored in the [/admin/backups/] folder and can be downloaded from the list below. Your most recent backup is highlighted. Make sure you download your most recent backup, and delete the rest.', 'Backup', 'en', 'English'),
(552, 'BAC_SUB', 'Database Functions', 'Backup', 'en', 'English'),
(553, 'BAC_OPTIMIZE', 'Optimize Database', 'Backup', 'en', 'English'),
(554, 'BAC_REPAIRING', 'Repairing...', 'Backup', 'en', 'English'),
(555, 'BAC_OPTIMIZING', 'Optimizing...', 'Backup', 'en', 'English'),
(556, 'BAC_ADD', 'Create Backup', 'Backup', 'en', 'English'),
(557, 'BAC_CREATED', 'Backup created successfully!', 'Backup', 'en', 'English'),
(558, 'BAC_RESTORE', 'Restore Database', 'Backup', 'en', 'English'),
(559, 'BAC_REPAIRED', 'Repaired', 'Backup', 'en', 'English'),
(560, 'BAC_OPTIMIZED', 'Optimized', 'Backup', 'en', 'English'),
(561, 'BAC_STATUS', 'Status', 'Backup', 'en', 'English'),
(562, 'BAC_TABLE', 'Table', 'Backup', 'en', 'English'),
(563, 'DOWNLOAD', 'Download', 'Global', 'en', 'English'),
(564, 'BAC_DELETE_OK', 'Backup [DBNAME] deleted successfully!', 'Backup', 'en', 'English'),
(565, 'BAC_DORESTORE1', 'Are you sure you want to restore this backup?', 'Backup', 'en', 'English'),
(566, 'BAC_DORESTORE2', 'This action cannot be undone.', 'Backup', 'en', 'English'),
(567, 'BAC_DELETE', 'Delete Database', 'Backup', 'en', 'English'),
(568, 'MAP_SUB', 'Sitemap Generator', 'Sitemap', 'en', 'English'),
(569, 'MAP_INFO', 'Here you can create site map in xml format, that you can submit to your search engine for better ranking. We recommend you regularly update your sitemap.', 'Sitemap', 'en', 'English'),
(570, 'MAP_CREATE', 'Generate Sitemap', 'Sitemap', 'en', 'English'),
(571, 'MAP_CREATED', 'The sitemap was created successfully!', 'Sitemap', 'en', 'English'),
(572, 'MAP_ERROR', 'There was an error creating sitemap.xml. Make sure filename [FILENAME] exists and is writable!', 'Sitemap', 'en', 'English'),
(573, 'DASH_TITLE', 'Welcome to Admin Panel', 'Dashboard', 'en', 'English'),
(574, 'DASH_INFO', 'Here you can view your visitors latest statisticsas well as most popular items based on number of visits.', 'Dashboard', 'en', 'English'),
(575, 'DASH_SUB', 'Admin Dashboard', 'Dashboard', 'en', 'English'),
(576, 'DASH_NAME', 'Dashboard', 'Dashboard', 'en', 'English'),
(577, 'DASH_RANGE', 'Select Range', 'Dashboard', 'en', 'English'),
(578, 'DASH_RANGE_T', 'Today', 'Dashboard', 'en', 'English'),
(579, 'DASH_RANGE_W', 'This Week', 'Dashboard', 'en', 'English'),
(580, 'DASH_RANGE_M', 'This Month', 'Dashboard', 'en', 'English'),
(581, 'DASH_RANGE_Y', 'This Year', 'Dashboard', 'en', 'English'),
(582, 'DASH_SUB1', 'Viewing Visitor Stats', 'Dashboard', 'en', 'English'),
(583, 'DASH_HITS', 'Total Hits', 'Dashboard', 'en', 'English'),
(584, 'DASH_VISITS', 'Unique Visits', 'Dashboard', 'en', 'English'),
(585, 'DASH_TOP', 'Top 5 Visited Products', 'Dashboard', 'en', 'English'),
(586, 'PRICE_RANGE', 'Price Range', 'Front', 'en', 'English'),
(587, 'HOME_SEARCH', 'Vehicle Search', 'Front', 'en', 'English'),
(588, 'MILEAGE', 'Mileage', 'Global', 'en', 'English'),
(589, 'HEAD_CHOOSE', 'Choose from a wide variety of vehicles', 'Front', 'en', 'English'),
(590, 'TWITTER', 'Twitter', 'Global', 'en', 'English'),
(591, 'FB', 'Facebook', 'Global', 'en', 'English'),
(592, 'TITLE', 'Title', 'Front', 'en', 'English'),
(593, 'YEAR', 'Year', 'Front', 'en', 'English'),
(594, 'PRICE', 'Price', 'Front', 'en', 'English'),
(595, 'DATE', 'Date', 'Front', 'en', 'English'),
(596, 'ACS', 'Asc', 'Global', 'en', 'English'),
(597, 'DESC', 'Desc', 'Global', 'en', 'English'),
(598, 'GRID', 'Grid', 'Global', 'en', 'English'),
(599, 'LIST', 'List', 'Global', 'en', 'English'),
(600, 'SORT_BY', 'Sort By', 'Front', 'en', 'English'),
(601, 'CAT_IMG', 'Image', 'Categories', 'en', 'English'),
(602, 'NO_LIST', 'Sorry, currently there are no listing under this criteria.', 'Front', 'en', 'English'),
(603, 'WDG_CF_NAME', 'Your Name', 'Front', 'en', 'English'),
(604, 'WDG_CF_EMAIL', 'Your Email', 'Front', 'en', 'English'),
(605, 'WDG_CF_MSG', 'Your Message', 'Front', 'en', 'English'),
(606, 'WDG_CF_SEND', 'Submit Inquiry', 'Contact', 'en', 'English'),
(607, 'WDG_CF_SUB', 'Email Subject', 'Contact', 'en', 'English'),
(608, 'WDG_OTHER', 'Our Other Locations', 'Contact', 'en', 'English'),
(609, 'EXPAND', 'Expand All', 'Global', 'en', 'English'),
(610, 'COLLAPSE', 'Collapse All', 'Global', 'en', 'English'),
(611, 'FRT_LIST', 'Listing', 'Front', 'en', 'English'),
(612, 'WDG_CF_ADDRESS', 'Our Address', 'Contact', 'en', 'English'),
(613, 'WDG_CF_SHARE', 'Share On', 'Contact', 'en', 'English'),
(614, 'TAB_OVERVIEW', 'Overview', 'Front', 'en', 'English'),
(615, 'TAB_DEC', 'Description', 'Front', 'en', 'English'),
(616, 'TAB_CONTACT', 'Contact', 'Front', 'en', 'English'),
(617, 'WDG_CF_S_TITLE', 'Your Title', 'Front', 'en', 'English'),
(618, 'WDG_CF_COMPANY', 'Company', 'Front', 'en', 'English'),
(619, 'FRONT_SEARCH', 'Search Results', 'Front', 'en', 'English'),
(620, 'TOTAL', 'Total', 'Global', 'en', 'English'),
(621, 'KM_RANGE', 'Mileage Range', 'Front', 'en', 'English'),
(622, 'SR_COLOUR', 'Car Colour', 'Front', 'en', 'English'),
(623, 'WDG_CF_ERROR', 'Email could not be sent due to the following error(s):', 'Contact', 'en', 'English'),
(624, 'WDG_CF_OK', 'Your message has been sent successfully.', 'Contact', 'en', 'English'),
(625, 'ER_404', 'Oops! Sorry, couldn&#39;t find that page.', 'Front', 'en', 'English'),
(626, 'ER_404_1', 'Looks like the page you&#39;re looking for was moved or never existed. Make sure you typed the correct URL or followed a valid link. Use the menu navigation to find other content.', 'Front', 'en', 'English'),
(627, 'FRONT', 'Front', 'Global', 'en', 'English'),
(628, 'M_H1', 'UNDER CONSTRUCTION', 'Front', 'en', 'English'),
(629, 'M_H2', 'Stay tuned for news and updates', 'Front', 'en', 'English'),
(630, 'M_WEEKS', 'Weeks', 'Front', 'en', 'English'),
(631, 'M_DAYS', 'Days', 'Front', 'en', 'English'),
(632, 'M_HOURS', 'Hours', 'Front', 'en', 'English'),
(633, 'M_MINUTES', 'Minutes', 'Front', 'en', 'English'),
(634, 'SUBSCRIBE', 'Subscribe', 'Front', 'en', 'English'),
(635, 'UNSUBSCRIBE', 'Unubscribe', 'Front', 'en', 'English'),
(636, 'STAY_TUNED', 'Stay Tuned', 'Front', 'en', 'English'),
(637, 'SUBSC_ERR1', 'You are already subscribed to our newsletter.', 'Front', 'en', 'English'),
(638, 'SUBSC_ERR2', 'Please select an action.', 'Front', 'en', 'English'),
(639, 'SUBSC_MSG1', 'Thank you. You are now subscribed to our newsletter.', 'Front', 'en', 'English'),
(640, 'SUBSC_MSG2', 'You are now unsubscribed from our newsletter.', 'Front', 'en', 'English'),
(641, 'SUBSC_ERR3', 'Sorry, this email address does not exist.', 'Front', 'en', 'English'),
(642, 'ADM_NLETTER', 'Newsletter', 'Navigation', 'en', 'English'),
(643, 'NLT_TITLE', 'Newsletter Manager', 'Newsletter', 'en', 'English'),
(644, 'NLT_SUB', 'Send Newsletter', 'Newsletter', 'en', 'English'),
(645, 'NLT_INFO', 'Here you can send newsletter to newsletter subscribers, or email to individual users.', 'Newsletter', 'en', 'English'),
(646, 'EXPORT', 'Export', 'Global', 'en', 'English');
INSERT INTO `language` (`id`, `lang_key`, `lang_value`, `lang_type`, `abbr`, `name`) VALUES
(647, 'NLT_EXPORT', 'Export Emails', 'Newsletter', 'en', 'English'),
(648, 'NLT_SUB1', 'Emailing User', 'Newsletter', 'en', 'English'),
(649, 'NLT_REC', 'Recipient', 'Newsletter', 'en', 'English'),
(650, 'NLT_SUBJECT', 'Email Subject', 'Newsletter', 'en', 'English'),
(651, 'NLT_BODY', 'Newsletter Content', 'Newsletter', 'en', 'English'),
(652, 'NLT_SEND', 'Send Mail', 'Newsletter', 'en', 'English'),
(653, 'NLT_SEND_OK', 'Email(s) have been sent successfully.', 'Newsletter', 'en', 'English'),
(654, 'NLT_SEND_ERR', 'Some of the emails could not be reached!', 'Newsletter', 'en', 'English'),
(655, 'NLT_LIST', 'Newsletter List', 'Newsletter', 'en', 'English');

--
-- Table structure for table `listings`
--

DROP TABLE IF EXISTS `listings`;
CREATE TABLE IF NOT EXISTS `listings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `idx` int(6) NOT NULL DEFAULT '0',
  `title` varchar(120) DEFAULT NULL,
  `slug` varchar(120) DEFAULT NULL,
  `location` int(2) NOT NULL,
  `stock_id` varchar(150) NOT NULL,
  `vin` varchar(150) NOT NULL,
  `make_id` int(11) NOT NULL DEFAULT '0',
  `model_id` int(11) NOT NULL DEFAULT '0',
  `year` year(4) NOT NULL,
  `condition` int(11) NOT NULL,
  `category` int(11) NOT NULL DEFAULT '0',
  `milege` mediumint(6) NOT NULL DEFAULT '0',
  `torque` varchar(150) NOT NULL,
  `thumb` varchar(60) DEFAULT NULL,
  `price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `price_sale` decimal(12,2) NOT NULL DEFAULT '0.00',
  `color_e` varchar(40) NOT NULL,
  `color_i` varchar(40) NOT NULL,
  `doors` varchar(10) NOT NULL,
  `fuel` tinyint(1) NOT NULL DEFAULT '0',
  `drive_train` varchar(60) NOT NULL,
  `engine` varchar(60) NOT NULL,
  `transmission` int(11) NOT NULL DEFAULT '0',
  `top_speed` varchar(40) NOT NULL,
  `horse_power` varchar(40) NOT NULL,
  `towing_capacity` varchar(40) NOT NULL,
  `features` varchar(250) NOT NULL,
  `body` text NOT NULL,
  `notes` text,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `hits` int(8) NOT NULL DEFAULT '0',
  `metakey` text,
  `metadesc` text,
  `modified` datetime DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_slug` (`slug`),
  KEY `idx_models` (`make_id`,`model_id`,`location`,`condition`,`category`,`fuel`,`transmission`),
  FULLTEXT KEY `idx_body` (`body`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `listings_info`
--

DROP TABLE IF EXISTS `listings_info`;
CREATE TABLE IF NOT EXISTS `listings_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `listing_id` int(11) NOT NULL DEFAULT '0',
  `make_name` varchar(100) DEFAULT NULL,
  `model_name` varchar(100) DEFAULT NULL,
  `location_name` varchar(100) DEFAULT NULL,
  `condition_name` varchar(50) DEFAULT NULL,
  `category_name` varchar(100) DEFAULT NULL,
  `fuel_name` varchar(50) DEFAULT NULL,
  `trans_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_listing_id` (`listing_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
CREATE TABLE IF NOT EXISTS `locations` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `zip` varchar(20) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `fax` varchar(20) DEFAULT NULL,
  `zoom` tinyint(1) NOT NULL DEFAULT '14',
  `lat` decimal(9,6) NOT NULL DEFAULT '0.000000',
  `lng` float(9,6) NOT NULL DEFAULT '0.000000',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `makes`
--

DROP TABLE IF EXISTS `makes`;
CREATE TABLE IF NOT EXISTS `makes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
CREATE TABLE IF NOT EXISTS `menus` (
  `id` tinyint(2) NOT NULL AUTO_INCREMENT,
  `page_id` tinyint(2) NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL,
  `content_type` varchar(20) NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `target` enum('_self','_blank') NOT NULL DEFAULT '_blank',
  `position` tinyint(2) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `content_id` (`active`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `models`
--

DROP TABLE IF EXISTS `models`;
CREATE TABLE IF NOT EXISTS `models` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `make_id` int(11) DEFAULT '0',
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `newsletter`
--

DROP TABLE IF EXISTS `newsletter`;
CREATE TABLE IF NOT EXISTS `newsletter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `body` longtext,
  `created` date NOT NULL,
  `contact` tinyint(1) NOT NULL DEFAULT '0',
  `faq` tinyint(1) NOT NULL DEFAULT '0',
  `home_page` tinyint(1) NOT NULL DEFAULT '0',
  `active` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `site_name` varchar(100) NOT NULL,
  `company` varchar(100) NOT NULL,
  `site_url` varchar(100) NOT NULL,
  `site_dir` varchar(60) DEFAULT NULL,
  `site_email` varchar(100) NOT NULL,
  `address` varchar(150) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `zip` varchar(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `fax` varchar(20) DEFAULT NULL,
  `fb` varchar(150) DEFAULT NULL,
  `twitter` varchar(150) DEFAULT NULL,
  `logo` varchar(60) DEFAULT NULL,
  `ipp` tinyint(3) NOT NULL DEFAULT '10',
  `featured` tinyint(2) NOT NULL DEFAULT '0',
  `theme` varchar(30) DEFAULT NULL,
  `odometer` varchar(3) NOT NULL DEFAULT 'km',
  `notify_admin` tinyint(1) NOT NULL DEFAULT '0',
  `offline` tinyint(1) NOT NULL DEFAULT '1',
  `offline_d` date DEFAULT NULL,
  `offline_t` time DEFAULT NULL,
  `offline_msg` text,
  `dtz` varchar(120) DEFAULT NULL,
  `locale` varchar(150) DEFAULT NULL,
  `short_date` varchar(20) DEFAULT NULL,
  `long_date` varchar(20) DEFAULT NULL,
  `lang` varchar(2) NOT NULL DEFAULT 'en',
  `currency` varchar(4) NOT NULL,
  `cur_symbol` varchar(8) NOT NULL,
  `tsep` varchar(1) NOT NULL DEFAULT ',',
  `dsep` varchar(1) NOT NULL DEFAULT '.',
  `dbbackup` varchar(50) DEFAULT NULL,
  `thumb_w` varchar(5) NOT NULL,
  `mailer` enum('PHP','SMTP','SMAIL') DEFAULT 'PHP',
  `sendmail` varchar(60) DEFAULT NULL,
  `smtp_host` varchar(100) DEFAULT NULL,
  `smtp_user` varchar(100) DEFAULT NULL,
  `smtp_pass` varchar(100) DEFAULT NULL,
  `smtp_port` int(3) DEFAULT NULL,
  `is_ssl` tinyint(1) DEFAULT NULL,
  `analytics` text,
  `metakeys` text NOT NULL,
  `metadesc` text NOT NULL,
  `minprice` decimal(9,2) DEFAULT NULL,
  `maxprice` decimal(9,2) DEFAULT NULL,
  `minsprice` decimal(9,2) DEFAULT NULL,
  `maxsprice` decimal(9,2) DEFAULT NULL,
  `minyear` year(4) DEFAULT NULL,
  `maxyear` year(4) DEFAULT NULL,
  `minkm` int(4) DEFAULT '0',
  `maxkm` int(4) DEFAULT '0',
  `colour` varchar(250) DEFAULT NULL,
  `ver` varchar(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`site_name`, `company`, `site_url`, `site_dir`, `site_email`, `address`, `city`, `state`, `zip`, `phone`, `fax`, `fb`, `twitter`, `logo`, `ipp`, `featured`, `theme`, `odometer`, `notify_admin`, `offline`, `offline_d`, `offline_t`, `offline_msg`, `dtz`, `locale`, `short_date`, `long_date`, `lang`, `currency`, `cur_symbol`, `tsep`, `dsep`, `dbbackup`, `thumb_w`, `mailer`, `sendmail`, `smtp_host`, `smtp_user`, `smtp_pass`, `smtp_port`, `is_ssl`, `analytics`, `metakeys`, `metadesc`, `minprice`, `maxprice`, `minsprice`, `maxsprice`, `minyear`, `maxyear`, `minkm`, `maxkm`, `colour`, `ver`) VALUES
('', '', '', '', '', '25 Savoy Ave', 'Toronto', 'ON', 'M4C 1Z5', '+1 (800) 432-5698', '', NULL, NULL, 'logo.png', 20, 10, 'master', 'km', 0, 0, '2014-03-22', '12:30:00', '&lt;p&gt;Lorem ipsum...&lt;/p&gt;', 'America/Toronto', 'en_us_utf8,English (US)', '%d %b %Y', '%d %B %Y %I:%M %p', 'en', 'CAD', '$', ',', '.', '12-Mar-2014_20-14-44.sql', '100', 'PHP', '', '', '', '', 0, 0, '', 'car', 'car listings', '7500.00', '35750.00', '7500.00', '35000.00', 2006, 2013, 75220, 152000, 'Beige,Black,Blue,Red,Silver,White', '1.00');


--
-- Table structure for table `stats`
--

DROP TABLE IF EXISTS `stats`;
CREATE TABLE IF NOT EXISTS `stats` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `day` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pageviews` int(10) NOT NULL DEFAULT '0',
  `uniquevisitors` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `transmissions`
--

DROP TABLE IF EXISTS `transmissions`;
CREATE TABLE IF NOT EXISTS `transmissions` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `fname` varchar(32) NOT NULL,
  `lname` varchar(32) NOT NULL,
  `userlevel` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime DEFAULT '0000-00-00 00:00:00',
  `lastlogin` datetime DEFAULT '0000-00-00 00:00:00',
  `lastip` varchar(16) DEFAULT '0',
  `access` varchar(20) DEFAULT '0',
  `active` enum('y','n') NOT NULL DEFAULT 'n',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;